
import { AppSettings, Todo, Department } from '../types';
import { getAllData, importAllData, getUserProfile, sanitizeFilename } from './storageService';

// Basic Auth header generator
const getAuthHeader = (settings: AppSettings) => {
  const { username, password } = settings.webDav;
  return 'Basic ' + btoa(`${username}:${password}`);
};

// Helper to determine filename based on active organization and user ID
const getSyncFileName = (): string => {
    const profile = getUserProfile();
    // Append userId (first 6 chars) to filename to prevent collisions on shared drives
    const userSuffix = profile?.userId ? `_${profile.userId.substring(0,6)}` : '';
    const orgSuffix = profile?.organization ? `_${sanitizeFilename(profile.organization)}` : '_default';
    return `eurasia_data${orgSuffix}${userSuffix}.json`;
};

export const syncToWebDav = async (settings: AppSettings, silent = false): Promise<{ success: boolean; message: string }> => {
  if (!settings.webDav.enabled || !settings.webDav.url) {
    return { success: false, message: 'WebDAV 未配置或未启用' };
  }

  const data = getAllData();
  const fileName = getSyncFileName();
  const fileUrl = settings.webDav.url.endsWith('/') 
    ? settings.webDav.url + fileName 
    : settings.webDav.url + '/' + fileName;

  try {
    const response = await fetch(fileUrl, {
      method: 'PUT',
      headers: {
        'Authorization': getAuthHeader(settings),
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (response.ok || response.status === 201 || response.status === 204) {
      return { success: true, message: '云端同步成功' };
    } else {
      return { success: false, message: `同步失败: ${response.status} ${response.statusText}` };
    }
  } catch (error: any) {
    return { success: false, message: `网络错误: ${error.message}` };
  }
};

export const syncFromWebDav = async (settings: AppSettings): Promise<{ success: boolean; message: string }> => {
  if (!settings.webDav.enabled || !settings.webDav.url) {
    return { success: false, message: 'WebDAV 未配置或未启用' };
  }

  const fileName = getSyncFileName();
  const fileUrl = settings.webDav.url.endsWith('/') 
    ? settings.webDav.url + fileName 
    : settings.webDav.url + '/' + fileName;

  try {
    const response = await fetch(fileUrl, {
      method: 'GET',
      headers: {
        'Authorization': getAuthHeader(settings),
        'Accept': 'application/json',
      },
    });

    if (response.ok) {
      const data = await response.json();
      importAllData(data);
      return { success: true, message: '数据已恢复' };
    } else {
      return { success: false, message: `下载失败: ${response.status}` };
    }
  } catch (error: any) {
    return { success: false, message: `网络错误: ${error.message}` };
  }
};
