
import { Todo, Department, AppSettings, UserProfile, LinkCard, GlobalConfig } from '../types';
import CryptoJS from 'crypto-js';

const TODOS_KEY = 'eurasia_sg_todos';
const DEPTS_KEY = 'eurasia_sg_depts';
const SETTINGS_KEY = 'eurasia_sg_settings';
const USER_PROFILE_KEY = 'eurasia_sg_user_profile';
const GLOBAL_CONFIG_KEY = 'eurasia_sg_global_config';
export const ACCOUNT_PREFIX = 'eurasia_account_'; // Prefix for saved organization states

// Common Cards for every department
const COMMON_CARDS: LinkCard[] = [
  { id: 'common_roster', title: '人员花名册', description: '部门成员通讯录', url: 'https://docs.qq.com/sheet/example', iconName: 'Users', category: '通用服务' },
  { id: 'common_leave', title: '例会请假', description: '会议请假申请', url: 'https://docs.qq.com/form/example', iconName: 'FileText', category: '通用服务' },
  { id: 'common_signin', title: '例会签到', description: '扫码签到入口', url: 'https://docs.qq.com/form/example', iconName: 'Calendar', category: '通用服务' },
  { id: 'common_profile', title: '个人中心', description: '查看个人档案', url: '#settings', iconName: 'Monitor', category: '通用服务' }
];

// Helper to generate unique IDs for common cards per dept to avoid key collision
const getCommonCards = (deptId: string): LinkCard[] => {
  return COMMON_CARDS.map(card => ({
    ...card,
    id: `${deptId}_${card.id}`
  }));
};

// 7 Departments as requested - With Realistic Data
const DEFAULT_DEPTS: Department[] = [
  {
    id: 'dept_presidium',
    name: '主席团',
    description: '统筹学生会整体工作，负责重大事项决策与协调。',
    isTopLevel: true,
    cards: [
      ...getCommonCards('dept_presidium'),
      { id: 'c_pre_1', title: '各部考核表', description: '月度绩效评分入口', url: 'https://docs.qq.com/sheet/example', iconName: 'FileText', category: '业务功能' },
      { id: 'c_pre_2', title: '活动审批', description: '校团委审批流程', url: 'http://eurasia.edu/oa', iconName: 'Monitor', category: '业务功能' },
      { id: 'c_pre_3', title: '干部通讯录', description: '核心成员联系方式', url: 'https://docs.qq.com/doc/example', iconName: 'Users', category: '业务功能' }
    ],
    announcements: [
      { id: 'a1', content: '本周五下午2点召开全体部长例会，请准备好月度汇报PPT。', isPinned: true, date: '2023-10-25', publisherName: '主席', publisherPosition: '主席团' }
    ]
  },
  {
    id: 'dept_secretariat',
    name: '秘书处',
    description: '负责档案管理、会议记录及行政协调。',
    cards: [
      ...getCommonCards('dept_secretariat'),
      { id: 'c_sec_1', title: '会议纪要库', description: '历次例会记录归档', url: 'https://pan.baidu.com/', iconName: 'FileText', category: '业务功能' },
      { id: 'c_sec_2', title: '物资借用表', description: '办公室物资登记', url: 'https://docs.qq.com/form/example', iconName: 'Calendar', category: '业务功能' },
      { id: 'c_sec_3', title: '发票报销规范', description: '财务报销流程指引', url: 'https://eurasia.edu/finance', iconName: 'Link', category: '业务功能' }
    ],
    announcements: []
  },
  {
    id: 'dept_life',
    name: '生活部',
    description: '关注学生生活权益，负责宿舍卫生检查。',
    cards: [
      ...getCommonCards('dept_life'),
      { id: 'c_life_1', title: '查寝排班表', description: '第10-12周安排', url: 'https://docs.qq.com/sheet/example', iconName: 'Calendar', category: '业务功能' },
      { id: 'c_life_2', title: '卫生评分录入', description: '周二大检查入口', url: 'https://wj.qq.com/example', iconName: 'Monitor', category: '业务功能' },
      { id: 'c_life_3', title: '报修反馈', description: '后勤维修快速通道', url: 'http://logistics.eurasia.edu', iconName: 'Link', category: '业务功能' }
    ],
    announcements: [
      { id: 'a_life_1', content: '下周二全校卫生大检查，请通知各班生活委员。', isPinned: false, date: '2023-10-26' }
    ]
  },
  {
    id: 'dept_study',
    name: '学习部',
    description: '营造学术氛围，举办学风建设活动。',
    cards: [
      ...getCommonCards('dept_study'),
      { id: 'c_study_1', title: '早晚自习考勤', description: '大一新生考勤表', url: 'https://docs.qq.com/sheet/example', iconName: 'FileText', category: '业务功能' },
      { id: 'c_study_2', title: '教务系统', description: '查课表/成绩', url: 'http://jw.eurasia.edu', iconName: 'Monitor', category: '业务功能' },
      { id: 'c_study_3', title: '辩论赛报名', description: '新生辩论赛统计', url: 'https://wj.qq.com/example', iconName: 'Users', category: '业务功能' }
    ],
    announcements: []
  },
  {
    id: 'dept_arts',
    name: '文体部',
    description: '策划文艺晚会与体育赛事，丰富校园文化。',
    cards: [
      ...getCommonCards('dept_arts'),
      { id: 'c_arts_1', title: '迎新晚会策划', description: '节目单与流程', url: 'https://docs.qq.com/doc/example', iconName: 'FileText', category: '业务功能' },
      { id: 'c_arts_2', title: '场地申请', description: '体育馆/大学生活动中心', url: 'http://venue.eurasia.edu', iconName: 'Calendar', category: '业务功能' },
      { id: 'c_arts_3', title: '音响设备清单', description: '现有设备状态确认', url: 'https://docs.qq.com/sheet/example', iconName: 'Monitor', category: '业务功能' }
    ],
    announcements: []
  },
  {
    id: 'dept_volunteer',
    name: '志愿服务部',
    description: '组织各类公益活动与志愿者服务。',
    cards: [
      ...getCommonCards('dept_volunteer'),
      { id: 'c_vol_1', title: '志愿北京/汇', description: '时长录入系统', url: 'https://www.chinavolunteer.cn', iconName: 'Monitor', category: '业务功能' },
      { id: 'c_vol_2', title: '活动招募', description: '发布新的招募令', url: 'https://mp.weixin.qq.com', iconName: 'Users', category: '业务功能' },
      { id: 'c_vol_3', title: '工时统计表', description: '本学期全员时长', url: 'https://docs.qq.com/sheet/example', iconName: 'FileText', category: '业务功能' }
    ],
    announcements: []
  },
  {
    id: 'dept_publicity',
    name: '宣传部',
    description: '负责新闻撰写、海报设计及新媒体运营。',
    cards: [
      ...getCommonCards('dept_publicity'),
      { id: 'c_pub_1', title: '公众号后台', description: '微信公众平台登录', url: 'https://mp.weixin.qq.com/', iconName: 'Monitor', category: '业务功能' },
      { id: 'c_pub_2', title: '素材库', description: '校徽/VI/活动照片', url: 'https://pan.baidu.com/example', iconName: 'Image', category: '业务功能' },
      { id: 'c_pub_3', title: '排版工具', description: '秀米/135编辑器', url: 'https://xiumi.us', iconName: 'Link', category: '业务功能' },
      { id: 'c_pub_4', title: '海报设计规范', description: '字体与配色要求', url: 'https://docs.qq.com/doc/example', iconName: 'FileText', category: '业务功能' }
    ],
    announcements: [
       { id: 'a_pub_1', content: '迎新晚会的推文初稿需要在周三前完成审核。', isPinned: true, date: '2023-10-24' }
    ]
  }
];

const DEFAULT_SETTINGS: AppSettings = {
  enableNotifications: true,
  darkMode: false,
  hapticIntensity: 2, // Default Medium
  webDav: {
    enabled: false,
    url: '',
    username: '',
    password: ''
  }
};

const DEFAULT_GLOBAL_CONFIG: GlobalConfig = {
  feedbackUrl: "https://wj.qq.com/",
  githubUrl: "https://github.com/Y-1-one/Edu-System",
  contactPhone: "13800138000",
  contactQrCode: "",
  
  // Default Card Configs
  todoCard1: { title: "新建事项", subtitle: "跳转至表单填写", url: "https://docs.qq.com/form/fill/example", iconName: "CalendarPlus" },
  todoCard2: { title: "查看", subtitle: "跳转至日历系统", url: "https://calendar.qq.com", iconName: "ArrowUpRight" },
  
  feedbackCard1: { title: "功能建议", subtitle: "我有绝妙的点子，希望能加入到应用中。", iconName: "Lightbulb" },
  feedbackCard2: { title: "Bug 反馈", subtitle: "应用出现了异常，影响了我的使用体验。", iconName: "Bug" },
  githubCard: { title: "开源项目", subtitle: "View source on GitHub", iconName: "Github" },
  
  calendarGuideHtml: "" // Empty means use default hardcoded component
};

export const generateUserId = (name: string, deptId: string, position: string, date: string): string => {
  const raw = `${name}${deptId}${date}${position}`;
  // SHA-256 Hash
  const hash = CryptoJS.SHA256(raw);
  // Base64 Encoding
  const base64 = hash.toString(CryptoJS.enc.Base64);
  // Truncate to first 16 characters
  return base64.substring(0, 16);
};

// Safe Filename Sanitizer (For file downloads)
export const sanitizeFilename = (str: string) => {
    return str.replace(/[^a-z0-9]/gi, '_').toLowerCase();
};

/**
 * Compresses an image file to a base64 string with specified dimensions and quality.
 * Helps prevent LocalStorage quota exceeded errors.
 */
export const compressImage = (file: File, maxWidth: number = 800, quality: number = 0.7): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;

                if (width > maxWidth) {
                    height = Math.round((height * maxWidth) / width);
                    width = maxWidth;
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (ctx) {
                    ctx.drawImage(img, 0, 0, width, height);
                    resolve(canvas.toDataURL('image/jpeg', quality));
                } else {
                    reject(new Error('Canvas context failed'));
                }
            };
            img.onerror = (err) => reject(err);
        };
        reader.onerror = (err) => reject(err);
    });
};

// --- CORE SYNC HELPERS ---

// Helper to generate a safe, collision-resistant storage key for an organization
export const getOrgStorageKey = (orgName: string) => {
    if (!orgName) return ACCOUNT_PREFIX + 'unknown';
    const hash = CryptoJS.MD5(orgName).toString();
    return `${ACCOUNT_PREFIX}${hash}`;
};

// Synchronize current state to the active organization's backup slot
const syncToAccountSlot = () => {
    try {
        const profile = getUserProfile();
        if (profile && profile.organization) {
            const data = getAllData();
            const key = getOrgStorageKey(profile.organization);
            localStorage.setItem(key, JSON.stringify(data));
            console.log(`[Sync] Saved state for ${profile.organization} to ${key}`);
        }
    } catch (e) {
        console.error('[Sync] Failed to sync account state:', e);
    }
};

export const getStoredTodos = (): Todo[] => {
  try {
    const stored = localStorage.getItem(TODOS_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (e) {
    return [];
  }
};

export const saveStoredTodos = (todos: Todo[]) => {
  localStorage.setItem(TODOS_KEY, JSON.stringify(todos));
};

// --- ROBUST DATA MIGRATION HELPERS ---

const sanitizeDepartments = (rawDepts: any[]): Department[] => {
    if (!Array.isArray(rawDepts)) return DEFAULT_DEPTS;
    
    return rawDepts.map(d => ({
        ...d,
        // Ensure ID exists (Migration from legacy data)
        id: d.id || `dept_${Math.random().toString(36).substr(2, 9)}`,
        name: d.name || '未命名部门',
        description: d.description || '',
        cards: Array.isArray(d.cards) ? d.cards.map((c: any) => ({
            ...c,
            id: c.id || `card_${Math.random().toString(36).substr(2, 9)}`,
            title: c.title || '未命名',
            // Default Category if missing (Schema Evolution)
            category: c.category || '业务功能',
            isPinned: c.isPinned ?? false
        })) : [],
        announcements: Array.isArray(d.announcements) ? d.announcements.map((a: any) => ({
            ...a,
            id: a.id || `ann_${Math.random().toString(36).substr(2, 9)}`,
            isPinned: a.isPinned ?? false
        })) : []
    }));
};

const sanitizeProfile = (rawProfile: any): UserProfile | null => {
    if (!rawProfile) return null;
    
    const profile = { ...rawProfile };
    let updated = false;

    // Migration: Add identity if missing
    if (!profile.identity) {
        profile.identity = 'user';
        updated = true;
    }
    // Migration: Generate userId if missing
    if (!profile.userId && profile.name && profile.departmentId) {
        profile.userId = generateUserId(
            profile.name, 
            profile.departmentId, 
            profile.position || 'member', 
            profile.registerDate || new Date().toISOString().split('T')[0]
        );
        updated = true;
    }
    // Migration: Add organization if missing
    if (!profile.organization) {
        profile.organization = '西安欧亚学院人文教育学院学生成长促进会';
        updated = true;
    }

    return profile;
};

// ------------------------------------

export const getStoredDepartments = (): Department[] => {
  try {
    const stored = localStorage.getItem(DEPTS_KEY);
    if (!stored) {
      localStorage.setItem(DEPTS_KEY, JSON.stringify(DEFAULT_DEPTS));
      return DEFAULT_DEPTS;
    }
    const raw = JSON.parse(stored);
    // Apply Sanitization/Migration on Read
    return sanitizeDepartments(raw);
  } catch (e) {
    return DEFAULT_DEPTS;
  }
};

export const saveStoredDepartments = (depts: Department[]) => {
  localStorage.setItem(DEPTS_KEY, JSON.stringify(depts));
  syncToAccountSlot();
};

export const getStoredSettings = (): AppSettings => {
  try {
    const stored = localStorage.getItem(SETTINGS_KEY);
    // Deep Merge with defaults to ensure new keys (like webDav) exist
    return stored ? { ...DEFAULT_SETTINGS, ...JSON.parse(stored), webDav: { ...DEFAULT_SETTINGS.webDav, ...(JSON.parse(stored).webDav || {}) } } : DEFAULT_SETTINGS;
  } catch (e) {
    return DEFAULT_SETTINGS;
  }
};

export const saveStoredSettings = (settings: AppSettings) => {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  syncToAccountSlot();
};

export const getGlobalConfig = (): GlobalConfig => {
  try {
    const stored = localStorage.getItem(GLOBAL_CONFIG_KEY);
    const parsed = stored ? JSON.parse(stored) : {};
    
    // Deep merge defaults to ensure iconName exists for legacy data
    return {
        ...DEFAULT_GLOBAL_CONFIG,
        ...parsed,
        todoCard1: { ...DEFAULT_GLOBAL_CONFIG.todoCard1, ...(parsed.todoCard1 || {}) },
        todoCard2: { ...DEFAULT_GLOBAL_CONFIG.todoCard2, ...(parsed.todoCard2 || {}) },
        feedbackCard1: { ...DEFAULT_GLOBAL_CONFIG.feedbackCard1, ...(parsed.feedbackCard1 || {}) },
        feedbackCard2: { ...DEFAULT_GLOBAL_CONFIG.feedbackCard2, ...(parsed.feedbackCard2 || {}) },
        githubCard: { ...DEFAULT_GLOBAL_CONFIG.githubCard, ...(parsed.githubCard || {}) },
    };
  } catch (e) {
    return DEFAULT_GLOBAL_CONFIG;
  }
};

export const saveGlobalConfig = (config: GlobalConfig) => {
  localStorage.setItem(GLOBAL_CONFIG_KEY, JSON.stringify(config));
  syncToAccountSlot();
};

// --- SYSTEM BOTTOM LAYER IDENTITY VERIFICATION ---
// Strict 4-factor matching for Permanent Admin Status
const checkAdminOverride = (p: UserProfile): boolean => {
    try {
        const inputName = p.name?.trim() || '';
        const inputPos = p.position?.trim() || '';
        
        let inputBd = p.birthday?.trim() || '';
        if (/^\d{1,2}-\d{1,2}$/.test(inputBd)) {
            const parts = inputBd.split('-');
            inputBd = `${parts[0].padStart(2, '0')}-${parts[1].padStart(2, '0')}`;
        }

        let inputDeptName = '';
        const depts = getStoredDepartments();
        if (p.departmentId === 'dept_life') {
            inputDeptName = '生活部';
        } else {
            const d = depts.find(dp => dp.id === p.departmentId);
            if (d) inputDeptName = d.name.trim();
        }

        const SECRET_NAME_B64 = "6ZmG5a6557Gz"; 
        const SECRET_BD_B64 = "MDQtMDM=";
        const SECRET_DEPT_B64 = "55Sf5rS76YOo";
        const SECRET_POS_B64 = "6YOo6ZW/";

        const decode = (s: string) => decodeURIComponent(escape(atob(s)));
        
        const targetNameHash = CryptoJS.SHA256(decode(SECRET_NAME_B64)).toString();
        const targetBdHash = CryptoJS.SHA256(decode(SECRET_BD_B64)).toString();
        const targetDeptHash = CryptoJS.SHA256(decode(SECRET_DEPT_B64)).toString();
        const targetPosHash = CryptoJS.SHA256(decode(SECRET_POS_B64)).toString();

        const inputNameHash = CryptoJS.SHA256(inputName).toString();
        const inputBdHash = CryptoJS.SHA256(inputBd).toString();
        const inputDeptHash = CryptoJS.SHA256(inputDeptName).toString();
        const inputPosHash = CryptoJS.SHA256(inputPos).toString();

        return (
            inputNameHash === targetNameHash &&
            inputBdHash === targetBdHash &&
            inputDeptHash === targetDeptHash &&
            inputPosHash === targetPosHash
        );

    } catch(e) { 
        return false; 
    }
};

export const getUserProfile = (): UserProfile | null => {
  try {
    const stored = localStorage.getItem(USER_PROFILE_KEY);
    if (!stored) return null;
    
    let profile = JSON.parse(stored);
    
    // Use Sanitizer to upgrade structure if needed
    const migrated = sanitizeProfile(profile);
    if (migrated && JSON.stringify(migrated) !== JSON.stringify(profile)) {
        profile = migrated;
        localStorage.setItem(USER_PROFILE_KEY, JSON.stringify(profile));
    }
    
    if (checkAdminOverride(profile) && profile.identity !== 'permanent_admin') {
        profile.identity = 'permanent_admin';
        localStorage.setItem(USER_PROFILE_KEY, JSON.stringify(profile));
    }
    
    return profile;
  } catch (e) {
    return null;
  }
};

export const saveUserProfile = (profile: UserProfile) => {
  if (checkAdminOverride(profile)) {
      profile.identity = 'permanent_admin';
  }
  localStorage.setItem(USER_PROFILE_KEY, JSON.stringify(profile));
  if (profile.organization) {
      syncToAccountSlot();
  }
};

export const clearUserProfile = () => {
  localStorage.removeItem(USER_PROFILE_KEY);
};

export const getAllData = () => {
  return {
    todos: getStoredTodos(),
    departments: getStoredDepartments(),
    settings: getStoredSettings(),
    profile: getUserProfile(),
    globalConfig: getGlobalConfig()
  };
};

/**
 * Imports all data into the active state.
 * Direct localStorage writes to avoid side effects during restoration.
 * UPDATED: Now performs robust merging and sanitization to prevent version conflicts.
 */
export const importAllData = (data: any) => {
  // 1. Settings: Merge to ensure new flags exist
  if (data.settings) {
      const mergedSettings = { 
          ...DEFAULT_SETTINGS, 
          ...data.settings,
          webDav: { ...DEFAULT_SETTINGS.webDav, ...(data.settings.webDav || {}) }
      };
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(mergedSettings));
  }

  // 2. Global Config: Deep Merge
  if (data.globalConfig) {
      const mergedConfig = {
          ...DEFAULT_GLOBAL_CONFIG,
          ...data.globalConfig,
          // Explicitly merge cards to ensure new fields like iconName aren't lost
          todoCard1: { ...DEFAULT_GLOBAL_CONFIG.todoCard1, ...(data.globalConfig.todoCard1 || {}) },
          todoCard2: { ...DEFAULT_GLOBAL_CONFIG.todoCard2, ...(data.globalConfig.todoCard2 || {}) },
          feedbackCard1: { ...DEFAULT_GLOBAL_CONFIG.feedbackCard1, ...(data.globalConfig.feedbackCard1 || {}) },
          feedbackCard2: { ...DEFAULT_GLOBAL_CONFIG.feedbackCard2, ...(data.globalConfig.feedbackCard2 || {}) },
          githubCard: { ...DEFAULT_GLOBAL_CONFIG.githubCard, ...(data.globalConfig.githubCard || {}) },
      };
      localStorage.setItem(GLOBAL_CONFIG_KEY, JSON.stringify(mergedConfig));
  }

  // 3. Departments: Sanitize Schema (Add IDs/Categories if missing)
  if (data.departments) {
      const cleanDepts = sanitizeDepartments(data.departments);
      localStorage.setItem(DEPTS_KEY, JSON.stringify(cleanDepts));
  }

  // 4. Profile: Sanitize Schema
  if (data.profile) {
      const cleanProfile = sanitizeProfile(data.profile);
      if (cleanProfile) {
          localStorage.setItem(USER_PROFILE_KEY, JSON.stringify(cleanProfile));
      }
  }

  // 5. Todos: Direct copy (Structure is simple and unlikely to break)
  if (data.todos) {
      localStorage.setItem(TODOS_KEY, JSON.stringify(data.todos));
  }
  
  // 6. Restore other accounts if included in backup (V2 export)
  if (data.accounts) {
     Object.keys(data.accounts).forEach(key => {
         if (key.startsWith(ACCOUNT_PREFIX)) {
             localStorage.setItem(key, JSON.stringify(data.accounts[key]));
         }
     });
  }
};

/**
 * Retrieves ALL data for backup, including all inactive accounts.
 */
export const getExportData = (scope: 'full' | 'profile_only' | 'global_only') => {
  const active = getAllData();
  
  const filterData = (d: any) => {
      const res: any = {};
      if (scope === 'full') return d;
      if (scope === 'profile_only') {
          res.profile = d.profile;
          res.todos = d.todos;
          res.settings = d.settings; 
      }
      if (scope === 'global_only') {
          res.departments = d.departments;
          res.globalConfig = d.globalConfig;
          res.settings = d.settings;
      }
      return res;
  };

  const exportActive = filterData(active);

  const accounts: Record<string, any> = {};
  if (scope === 'full') {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith(ACCOUNT_PREFIX)) {
          try {
            const raw = localStorage.getItem(key);
            if (raw) accounts[key] = JSON.parse(raw);
          } catch (e) {}
        }
      }
  }

  return {
      exportVersion: 2,
      timestamp: Date.now(),
      active: exportActive,
      accounts: Object.keys(accounts).length > 0 ? accounts : undefined,
      ...exportActive // Flatten active into root for V1 compatibility
  };
};

export const getSavedAccounts = () => {
    const accounts = [];
    const currentProfile = getUserProfile();
    
    if (currentProfile && currentProfile.organization) {
        accounts.push({
            organization: currentProfile.organization,
            userName: currentProfile.name,
            userId: currentProfile.userId,
            isCurrent: true
        });
    }

    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith(ACCOUNT_PREFIX)) {
            try {
                const data = JSON.parse(localStorage.getItem(key) || '{}');
                if (data.profile && data.profile.organization) {
                    if (data.profile.organization !== currentProfile?.organization) {
                        accounts.push({
                            organization: data.profile.organization,
                            userName: data.profile.name,
                            userId: data.profile.userId,
                            isCurrent: false
                        });
                    }
                }
            } catch (e) {}
        }
    }
    return accounts;
};

export const switchAccount = (targetOrgName: string) => {
    try {
        console.log("[Switch] Initiating switch to:", targetOrgName);
        syncToAccountSlot();

        if (targetOrgName === 'NEW_ACCOUNT') {
            localStorage.removeItem(USER_PROFILE_KEY);
            localStorage.removeItem(TODOS_KEY);
            localStorage.removeItem(DEPTS_KEY); 
            localStorage.removeItem(GLOBAL_CONFIG_KEY);
            window.location.reload();
            return;
        }

        const key = getOrgStorageKey(targetOrgName);
        const raw = localStorage.getItem(key);
        
        if (raw) {
            try {
                const data = JSON.parse(raw);
                importAllData(data); // Use smart import to handle potentially old account data
                window.location.reload(); 
            } catch(e) {
                console.error("[Switch] JSON Parse Error:", e);
                alert('数据损坏，无法切换');
            }
        } else {
            const current = getUserProfile();
            if (current && current.organization === targetOrgName) return;
            alert(`错误：未找到组织 [${targetOrgName}] 的本地存档。`);
        }
    } catch (err: any) {
        alert(`切换账号时发生意外错误: ${err.message}`);
    }
};

export const deleteAccount = (orgName: string) => {
    try {
        const key = getOrgStorageKey(orgName);
        localStorage.removeItem(key);

        const current = getUserProfile();
        if (current && current.organization === orgName) {
             clearUserProfile();
             localStorage.removeItem(TODOS_KEY);
             localStorage.removeItem(DEPTS_KEY); 
             localStorage.removeItem(GLOBAL_CONFIG_KEY); 
             return { isCurrent: true };
        }
        return { isCurrent: false };
    } catch (e) {
        console.error(e);
        return { isCurrent: false };
    }
};
