
import CryptoJS from 'crypto-js';

// --- Configuration ---
// 8-Color Palette (3 bits) for High Contrast Encoding
const PALETTE_COLORS = [
  '#000000', // 000: Black
  '#FF0000', // 001: Red
  '#00FF00', // 010: Green
  '#0000FF', // 011: Blue
  '#00FFFF', // 100: Cyan
  '#FF00FF', // 101: Magenta
  '#FFFF00', // 110: Yellow
  '#FFFFFF'  // 111: White
];

// Base64 Charset for mapping
const B64_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

interface EncryptedPayload {
  h: string; // Hash (MD5)
  e: boolean; // Is Encrypted
  d: string; // Data (Base64 or Ciphertext)
  t: number; // Timestamp
}

/**
 * Encrypts or Packages data securely.
 */
export const packageData = (data: any, password?: string): string => {
  const jsonString = JSON.stringify(data);
  const hash = CryptoJS.MD5(jsonString).toString();
  
  let finalData = jsonString;
  let isEncrypted = false;

  if (password) {
    // Encrypt using AES
    finalData = CryptoJS.AES.encrypt(jsonString, password).toString();
    isEncrypted = true;
  } 

  const payload: EncryptedPayload = {
    h: hash,
    e: isEncrypted,
    d: isEncrypted ? finalData : btoa(unescape(encodeURIComponent(jsonString))), // Standard Base64 if not encrypted
    t: Date.now()
  };

  return JSON.stringify(payload);
};

/**
 * Unpackages and Decrypts data.
 */
export const unpackageData = (payloadJson: string, password?: string): any => {
  const payload: EncryptedPayload = JSON.parse(payloadJson);
  
  let jsonString = '';

  if (payload.e) {
    if (!password) throw new Error('PASSWORD_REQUIRED');
    try {
      const bytes = CryptoJS.AES.decrypt(payload.d, password);
      jsonString = bytes.toString(CryptoJS.enc.Utf8);
    } catch (e) {
      throw new Error('DECRYPTION_FAILED');
    }
  } else {
    try {
        // Handle standard Base64 decoding with UTF8 support
        jsonString = decodeURIComponent(escape(atob(payload.d)));
    } catch(e) {
        // Fallback for raw strings
        jsonString = atob(payload.d);
    }
  }

  if (!jsonString) throw new Error('INVALID_DATA');

  // Verify Integrity
  const calculatedHash = CryptoJS.MD5(jsonString).toString();
  if (calculatedHash !== payload.h) {
    throw new Error('INTEGRITY_CHECK_FAILED');
  }

  return JSON.parse(jsonString);
};

/**
 * Generates a CIMBAR-style Color Matrix Image.
 * Encoding: 
 * 1. Base64 the payload.
 * 2. Strip padding.
 * 3. Encode Length (24 bits / 8 tiles).
 * 4. Encode Data (6 bits / 2 tiles per char).
 */
export const generateColorCode = async (dataString: string): Promise<string> => {
  // 1. Prepare Data
  // Encode URI -> unescape -> btoa handles UTF8 characters correctly
  const rawB64 = btoa(unescape(encodeURIComponent(dataString)));
  // Strip '=' padding to strictly match our 64-char map
  const b64 = rawB64.replace(/=/g, '');
  
  const dataLen = b64.length;
  
  // Calculate Grid Size
  // Header: 8 tiles (24 bits) for Length
  // Body: dataLen * 2 tiles
  const totalTiles = 8 + (dataLen * 2);
  
  const cols = Math.ceil(Math.sqrt(totalTiles));
  const rows = Math.ceil(totalTiles / cols);
  
  const TILE_SIZE = 16; // Pixel size per tile
  const width = cols * TILE_SIZE;
  const height = rows * TILE_SIZE;

  // 3. Draw
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas context failed');

  // Fill background white
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, width, height);

  let tileIdx = 0;

  const drawTile = (colorIdx: number) => {
      const x = (tileIdx % cols) * TILE_SIZE;
      const y = Math.floor(tileIdx / cols) * TILE_SIZE;
      ctx.fillStyle = PALETTE_COLORS[colorIdx];
      ctx.fillRect(x, y, TILE_SIZE, TILE_SIZE);
      tileIdx++;
  };

  // --- HEADER: Encode Length (24 bits) ---
  for (let k = 0; k < 8; k++) {
      // 8 tiles * 3 bits = 24 bits
      // Shift: 21, 18, 15... 0
      const shift = 21 - (k * 3);
      const val = (dataLen >> shift) & 0x7;
      drawTile(val);
  }

  // --- BODY: Encode Data ---
  for (let i = 0; i < dataLen; i++) {
    const char = b64[i];
    const val = B64_CHARS.indexOf(char);
    if (val === -1) continue;

    // Split 6 bits into two 3-bit parts
    const high3 = (val >> 3) & 0x7; 
    const low3 = val & 0x7;

    drawTile(high3);
    drawTile(low3);
  }

  return canvas.toDataURL('image/png');
};

/**
 * Decodes a Color Matrix Image back to Data.
 */
export const parseColorCode = (image: HTMLImageElement): Promise<string> => {
    return new Promise((resolve, reject) => {
        const canvas = document.createElement('canvas');
        canvas.width = image.width;
        canvas.height = image.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) return reject('CTX_ERR');

        ctx.drawImage(image, 0, 0);
        
        const TILE_SIZE = 16;
        const cols = Math.floor(canvas.width / TILE_SIZE);
        
        let tileIdx = 0;

        const readTile = (): number => {
            const x = (tileIdx % cols) * TILE_SIZE + (TILE_SIZE / 2);
            const y = Math.floor(tileIdx / cols) * TILE_SIZE + (TILE_SIZE / 2);
            
            // Out of bounds check
            if (x >= canvas.width || y >= canvas.height) return 7; // Return White

            const p = ctx.getImageData(x, y, 1, 1).data;
            tileIdx++;
            return snapToPalette(p[0], p[1], p[2]);
        };

        // 1. Read Header (Length) - 8 tiles
        let dataLen = 0;
        for (let k = 0; k < 8; k++) {
            const val = readTile();
            dataLen = (dataLen << 3) | val;
        }

        // Safety limit: 5MB
        if (dataLen < 0 || dataLen > 5000000) {
            return reject('INVALID_HEADER_LENGTH');
        }

        // 2. Read Body
        const chunks: string[] = [];
        // Batch string concat for performance
        let currentChunk = "";
        
        for (let i = 0; i < dataLen; i++) {
            const h = readTile();
            const l = readTile();
            const charCode = (h << 3) | l;
            
            if (charCode < 64) {
                currentChunk += B64_CHARS[charCode];
            }

            // Flush chunk every 1024 chars
            if (currentChunk.length > 1024) {
                chunks.push(currentChunk);
                currentChunk = "";
            }
        }
        chunks.push(currentChunk);
        let b64Result = chunks.join("");
        
        // 3. Re-pad with '='
        const padNeeded = (4 - (b64Result.length % 4)) % 4;
        b64Result += "=".repeat(padNeeded);

        try {
            const jsonStr = decodeURIComponent(escape(atob(b64Result)));
            // Validate it looks like our payload
            const obj = JSON.parse(jsonStr);
            if(obj.h && obj.t !== undefined) {
                resolve(jsonStr);
            } else {
                reject('INVALID_FORMAT');
            }
        } catch (e) {
            console.error("Decode error details:", e);
            reject('DECODE_ERROR');
        }
    });
};

// Helper: Find closest palette color
const snapToPalette = (r: number, g: number, b: number): number => {
    let minDist = Infinity;
    let closestIdx = 0;

    PALETTE_COLORS.forEach((hex, idx) => {
        // Hex to RGB
        const hr = parseInt(hex.slice(1, 3), 16);
        const hg = parseInt(hex.slice(3, 5), 16);
        const hb = parseInt(hex.slice(5, 7), 16);
        
        // Euclidean distance
        const dist = Math.sqrt(
            Math.pow(hr - r, 2) + 
            Math.pow(hg - g, 2) + 
            Math.pow(hb - b, 2)
        );

        if (dist < minDist) {
            minDist = dist;
            closestIdx = idx;
        }
    });
    return closestIdx;
};
