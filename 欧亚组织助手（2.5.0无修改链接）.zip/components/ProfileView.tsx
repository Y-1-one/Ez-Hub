import React, { useState, useEffect } from 'react';
import { UserProfile } from '../types';
import { getUserProfile, saveUserProfile, getStoredDepartments } from '../services/storageService';
import { Camera, Check, User } from 'lucide-react';

const ProfileView: React.FC = () => {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [departments] = useState(getStoredDepartments());
  const [isEditing, setIsEditing] = useState(false);
  
  // Edit State
  const [name, setName] = useState('');
  const [deptId, setDeptId] = useState('');
  const [position, setPosition] = useState('');
  const [avatar, setAvatar] = useState('');
  const [birthday, setBirthday] = useState('');

  useEffect(() => {
    const p = getUserProfile();
    setProfile(p);
    if (p) {
      setName(p.name);
      setDeptId(p.departmentId);
      setPosition(p.position);
      setAvatar(p.avatar);
      setBirthday(p.birthday || '');
    }
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setAvatar(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    if (!name || !deptId) return;
    const newProfile: UserProfile = { name, departmentId: deptId, position, avatar, birthday };
    saveUserProfile(newProfile);
    setProfile(newProfile);
    setIsEditing(false);
  };

  const deptName = departments.find(d => d.id === profile?.departmentId)?.name || '未设置';

  return (
    <div className="p-4 md:p-8">
       <h2 className="text-2xl font-bold text-gray-800 mb-6">个人中心</h2>
       
       <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 flex flex-col items-center">
          <div className="relative group">
            <div className="w-24 h-24 rounded-full bg-gray-100 flex items-center justify-center overflow-hidden border-4 border-white shadow-lg mb-4">
               {isEditing && avatar ? <img src={avatar} className="w-full h-full object-cover" /> : 
                profile?.avatar ? <img src={profile.avatar} className="w-full h-full object-cover" /> :
                <User size={40} className="text-gray-300" />}
            </div>
            {isEditing && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/30 rounded-full opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                 <Camera className="text-white" />
                 <input type="file" accept="image/*" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" />
              </div>
            )}
          </div>

          {isEditing ? (
            <div className="w-full max-w-sm space-y-4">
               <input value={name} onChange={e => setName(e.target.value)} className="w-full p-2 border rounded-lg text-center font-bold text-lg" placeholder="姓名" />
               <select value={deptId} onChange={e => setDeptId(e.target.value)} className="w-full p-2 border rounded-lg text-center">
                  {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
               </select>
               <input value={position} onChange={e => setPosition(e.target.value)} className="w-full p-2 border rounded-lg text-center" placeholder="职位" />
               <input value={birthday} onChange={e => setBirthday(e.target.value)} className="w-full p-2 border rounded-lg text-center" placeholder="生日 (MM-DD)" />
               <div className="flex justify-center gap-4 mt-4">
                 <button onClick={() => setIsEditing(false)} className="px-6 py-2 bg-gray-100 rounded-full text-sm">取消</button>
                 <button onClick={handleSave} className="px-6 py-2 bg-indigo-600 text-white rounded-full text-sm">保存</button>
               </div>
            </div>
          ) : (
            <div className="text-center">
              <h3 className="text-2xl font-bold text-gray-900">{profile?.name}</h3>
              <p className="text-indigo-600 font-medium mt-1">{deptName} · {profile?.position}</p>
              <button onClick={() => setIsEditing(true)} className="mt-6 px-6 py-2 border border-gray-200 rounded-full text-sm text-gray-600 hover:bg-gray-50">
                编辑资料
              </button>
            </div>
          )}
       </div>
    </div>
  );
};

export default ProfileView;