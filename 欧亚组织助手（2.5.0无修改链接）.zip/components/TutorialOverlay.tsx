
import React, { useState } from 'react';
import { createPortal } from 'react-dom';
import { CheckSquare, Layout, Shield, ArrowRight, Sparkles, X, Sun, Check, Lock, Grid, User } from 'lucide-react';
import { triggerHaptic } from '../services/hapticService';

// Helper for Portals
const ModalPortal = ({ children }: { children?: React.ReactNode }) => {
  return createPortal(
    children,
    document.body
  );
};

interface TutorialOverlayProps {
  onComplete: () => void;
}

const STEPS = [
  {
    id: 'welcome',
    title: '准备就绪',
    desc: '欢迎来到您的数字化成长空间。只需三步，带您快速了解核心功能。',
    // Custom render handled in component
  },
  {
    id: 'todo',
    title: '沉浸专注',
    desc: '每一个待办都伴随着星空与白噪音。支持一键同步至系统日历，调用原生提醒。',
  },
  {
    id: 'workbench',
    title: '资源聚合',
    desc: '工作台汇集了部门常用工具。支持通过 CIMBAR 彩色码快速克隆部门配置。',
  },
  {
    id: 'security',
    title: '隐私至上',
    desc: '本地优先架构，所有数据存储于您的设备。支持 AES 加密备份与迁移。',
  }
];

const TutorialOverlay: React.FC<TutorialOverlayProps> = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [isExiting, setIsExiting] = useState(false);

  const handleNext = () => {
    triggerHaptic('light');
    if (currentStep < STEPS.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      handleFinish();
    }
  };

  const handleFinish = () => {
    triggerHaptic('success');
    setIsExiting(true);
    setTimeout(onComplete, 300); // Wait for exit animation
  };

  const renderVisual = (stepId: string) => {
      switch(stepId) {
          case 'welcome':
              return (
                  <div className="w-24 h-24 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl flex items-center justify-center shadow-lg shadow-indigo-500/20 animate-[slide-up_0.4s_ease-out]">
                      <Sparkles size={40} className="text-white animate-pulse" />
                  </div>
              );
          case 'todo':
              return (
                  <div className="w-32 h-24 relative animate-[slide-up_0.4s_ease-out]">
                      {/* Mini Todo Card 1 */}
                      <div className="absolute top-0 left-0 right-0 h-14 bg-white dark:bg-slate-700 rounded-xl shadow-lg border border-slate-100 dark:border-slate-600 flex items-center px-3 gap-3 transform -rotate-3 z-10 animate-[pulse_3s_infinite]">
                          <div className="w-4 h-4 rounded-full border-2 border-indigo-500"></div>
                          <div className="flex-1">
                              <div className="h-2 w-16 bg-slate-200 dark:bg-slate-500 rounded-full mb-1"></div>
                              <div className="h-1.5 w-8 bg-slate-100 dark:bg-slate-600 rounded-full"></div>
                          </div>
                          <Sun size={12} className="text-orange-400" />
                      </div>
                      {/* Mini Todo Card 2 */}
                      <div className="absolute top-6 left-2 right-2 h-14 bg-indigo-500 rounded-xl shadow-md flex items-center px-3 gap-3 transform rotate-2 opacity-90 scale-95 z-0">
                         <div className="w-4 h-4 rounded-full bg-white/20 flex items-center justify-center"><Check size={8} className="text-white"/></div>
                         <div className="flex-1">
                            <div className="h-2 w-12 bg-white/30 rounded-full"></div>
                         </div>
                      </div>
                  </div>
              );
          case 'workbench':
              return (
                  <div className="w-24 h-24 bg-slate-100 dark:bg-slate-700 rounded-2xl grid grid-cols-2 gap-2 p-2 shadow-inner animate-[slide-up_0.4s_ease-out] border border-slate-200 dark:border-slate-600">
                      <div className="bg-white dark:bg-slate-600 rounded-lg shadow-sm flex items-center justify-center"><Grid size={12} className="text-indigo-500"/></div>
                      <div className="bg-white dark:bg-slate-600 rounded-lg shadow-sm flex items-center justify-center"><User size={12} className="text-blue-500"/></div>
                      <div className="bg-white dark:bg-slate-600 rounded-lg shadow-sm flex items-center justify-center col-span-2 bg-gradient-to-r from-orange-100 to-white dark:from-orange-500/20 dark:to-slate-600">
                          <div className="h-1.5 w-12 bg-slate-200 dark:bg-slate-500 rounded-full"></div>
                      </div>
                  </div>
              );
          case 'security':
              return (
                  <div className="w-24 h-24 bg-green-50 dark:bg-green-900/20 rounded-full flex items-center justify-center border-4 border-green-100 dark:border-green-800 animate-[slide-up_0.4s_ease-out]">
                      <div className="relative">
                          <Shield size={40} className="text-green-500" />
                          <div className="absolute -bottom-1 -right-1 bg-white dark:bg-slate-800 rounded-full p-1 shadow-sm">
                              <Lock size={12} className="text-green-600"/>
                          </div>
                      </div>
                  </div>
              );
          default: 
            return <div />;
      }
  };

  const stepData = STEPS[currentStep];

  return (
    <ModalPortal>
      <div className={`fixed inset-0 z-[999] flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${isExiting ? 'opacity-0' : 'opacity-100 animate-fade-in'}`}>
        
        <div className={`w-full max-w-sm glass-panel rounded-[2rem] p-8 relative overflow-hidden transition-all duration-500 ${isExiting ? 'scale-95 translate-y-4' : 'scale-100 translate-y-0'} bg-white/95 dark:bg-[#0f172a]/95 shadow-2xl`}>
          
          {/* Progress Indicators */}
          <div className="flex justify-center gap-2 mb-10">
            {STEPS.map((_, idx) => (
              <div 
                key={idx} 
                className={`h-1 rounded-full transition-all duration-300 ${idx === currentStep ? 'w-8 bg-indigo-500' : 'w-2 bg-slate-200 dark:bg-white/20'}`}
              />
            ))}
          </div>

          {/* Skip Button */}
          <button 
            onClick={handleFinish}
            className="absolute top-6 right-6 text-slate-400 dark:text-white/30 hover:text-slate-600 dark:hover:text-white transition-colors"
          >
            <X size={20} />
          </button>

          {/* Dynamic Content */}
          <div className="flex flex-col items-center text-center">
            {/* Visual Container */}
            <div key={stepData.id + '_visual'} className="h-32 flex items-center justify-center mb-2">
                {renderVisual(stepData.id)}
            </div>

            {/* Text */}
            <h3 key={stepData.id + '_title'} className="text-2xl font-bold text-slate-900 dark:text-white mb-3 animate-[fade-in_0.5s_ease-out]">
              {stepData.title}
            </h3>
            <p key={stepData.id + '_desc'} className="text-slate-500 dark:text-white/60 text-sm leading-relaxed mb-8 min-h-[4rem] animate-[fade-in_0.6s_ease-out]">
              {stepData.desc}
            </p>

            {/* Action Button */}
            <button 
              onClick={handleNext}
              className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold text-lg shadow-lg shadow-indigo-500/30 active:scale-[0.98] transition-all flex items-center justify-center gap-2 group"
            >
              {currentStep === STEPS.length - 1 ? '开始探索' : '下一步'}
              {currentStep !== STEPS.length - 1 && <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform"/>}
            </button>
          </div>

        </div>
      </div>
    </ModalPortal>
  );
};

export default TutorialOverlay;
