
import React, { useState, useEffect, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { Calendar, ArrowUpRight, Quote, CalendarPlus, BookOpen, ChevronRight, X, HelpCircle, AlertCircle, Smartphone, Globe, Copy, CheckCircle, Monitor, Trash2, Bell, Clock, Plus, Share, Check, Link, Apple, LayoutGrid, ToggleRight, Heart, Lightbulb, Bug, Github, MoreHorizontal } from 'lucide-react';
import { Todo, GlobalConfig } from '../types';
import { getStoredTodos, saveStoredTodos, getGlobalConfig } from '../services/storageService';
import { addToSystemCalendar, openNativeCalendar } from '../services/calendarService';
import { triggerHaptic } from '../services/hapticService';

// Helper for Portals - Moved outside to prevent re-creation and fix types
const ModalPortal = ({ children }: { children?: React.ReactNode }) => {
  return createPortal(
    children,
    document.body
  );
};

// Pure Chinese: Mix of Ancient Poetry & Modern Motivation
const MOTIVATIONAL_QUOTES = [
  "天行健，君子以自强不息。",
  "星光不问赶路人，时光不负有心人。",
  "满船清梦压星河。",
  "路漫漫其修远兮，吾将上下而求索。",
  "且视今朝，未来可期。",
  "心中有丘壑，眉目作山河。",
  "博观而约取，厚积而薄发。",
  "不啻微芒，造炬成阳。",
  "追光的人，终会光芒万丈。",
  "须知少时凌云志，曾许人间第一流。",
  "希君生羽翼，一化北溟鱼。",
  "大鹏一日同风起，扶摇直上九万里。",
  "如切如磋，如琢如磨。",
  "凡心所向，素履以往。",
  "流水不争先，争的是滔滔不绝。",
  "关关难过关关过，前路漫漫亦灿灿。",
  "志之所趋，无远弗届。",
  "且将新火试新茶，诗酒趁年华。",
  "山高自有客行路，水深自有渡船人。",
  "彼方尚有荣光在。",
  "岁月漫长，值得等待。",
  "乾坤未定，你我皆是黑马。",
  "少年心事当拿云。",
  "欲穷千里目，更上一层楼。",
  "人生万事须自为，跬步江山即寥廓。",
  "此时情绪此时天，无事小神仙。",
  "愿你以梦为马，不负韶华。",
  "热爱可抵岁月漫长。",
  "纵有疾风起，人生不言弃。",
  "种一棵树最好的时间是十年前，其次是现在。"
];

interface TodoViewProps {
    modalAction?: string;
    modalId?: string;
}

const TodoView: React.FC<TodoViewProps> = ({ modalAction, modalId }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [animState, setAnimState] = useState<'entering' | 'active' | 'exiting'>('active');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showGuideModal, setShowGuideModal] = useState(false); // New Guide Modal State
  const [guideTab, setGuideTab] = useState<'ios' | 'mac' | 'xiaomi' | 'honor' | 'android'>('ios'); // Guide Tabs
  const [dateInfo, setDateInfo] = useState<{date: string, weekday: string, year: string}>({date: '', weekday: '', year: ''});
  const [globalConfig, setGlobalConfig] = useState<GlobalConfig>(getGlobalConfig());

  // Todo State
  const [todos, setTodos] = useState<Todo[]>([]);
  
  // Helper to get local date string YYYY-MM-DD
  const getLocalDate = () => {
      const now = new Date();
      // Adjust for timezone to ensure we get "today" in local time, not UTC
      const offset = now.getTimezoneOffset() * 60000;
      return new Date(now.getTime() - offset).toISOString().split('T')[0];
  };

  const [newTodo, setNewTodo] = useState<Partial<Todo>>({
    title: '',
    date: getLocalDate(),
    time: '09:00',
    description: ''
  });

  // Load Todos & Config
  useEffect(() => {
    setTodos(getStoredTodos());
    setGlobalConfig(getGlobalConfig());
    
    // Handle URL Actions
    if (modalAction === 'new') {
      setShowAddModal(true);
      triggerHaptic('medium');
    }
  }, [modalAction]);

  // Sync Todos to Storage & SW
  const updateTodos = (newTodos: Todo[]) => {
    setTodos(newTodos);
    saveStoredTodos(newTodos);
    
    // Update Service Worker
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'UPDATE_TODOS',
        payload: newTodos
      });
    }
  };

  // Date Initialization
  useEffect(() => {
    const now = new Date();
    const weekdays = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
    setDateInfo({
      year: now.getFullYear().toString(),
      date: `${now.getMonth() + 1}月${now.getDate()}日`,
      weekday: weekdays[now.getDay()]
    });
  }, []);

  // Fantasy Transition Logic
  useEffect(() => {
    const cycleTime = 8000; 
    const exitDuration = 1000; 

    const interval = setInterval(() => {
      setAnimState('exiting');
      setTimeout(() => {
        setCurrentIndex(prev => (prev + 1) % MOTIVATIONAL_QUOTES.length);
        setAnimState('entering');
        requestAnimationFrame(() => {
          setTimeout(() => setAnimState('active'), 100);
        });
      }, exitDuration);
    }, cycleTime);
    
    return () => clearInterval(interval);
  }, []);

  const handleAddTodo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTodo.title || !newTodo.date || !newTodo.time) return;

    const todo: Todo = {
      id: Date.now().toString(),
      title: newTodo.title,
      description: newTodo.description || '',
      date: newTodo.date,
      time: newTodo.time,
      completed: false,
      tags: [],
      notified: false
    };

    const updated = [...todos, todo];
    // Sort by date/time
    updated.sort((a, b) => new Date(`${a.date}T${a.time}`).getTime() - new Date(`${b.date}T${b.time}`).getTime());
    
    updateTodos(updated);
    setNewTodo({
      title: '',
      date: getLocalDate(),
      time: '09:00',
      description: ''
    });
    setShowAddModal(false);
    triggerHaptic('success');
  };
  
  const currentQuote = MOTIVATIONAL_QUOTES[currentIndex];

  const renderIcon = (name: string, size: number = 20, className?: string) => {
    const props = { size, className };
    switch (name) {
      case 'CalendarPlus': return <CalendarPlus {...props} />;
      case 'ArrowUpRight': return <ArrowUpRight {...props} />;
      case 'Lightbulb': return <Lightbulb {...props} />;
      case 'Bug': return <Bug {...props} />;
      case 'Github': return <Github {...props} />;
      case 'Calendar': return <Calendar {...props} />;
      case 'BookOpen': return <BookOpen {...props} />;
      case 'Globe': return <Globe {...props} />;
      case 'Link': return <Link {...props} />;
      default: return <Plus {...props} />;
    }
  };

  return (
    <div className="h-full w-full relative overflow-hidden text-slate-800 dark:text-white select-none flex flex-col">
      
      {/* Note: StarryBackground removed to reveal global Liquid Background */}

      {/* --- 2. Main Layout (One Page Fit - No Scroll) --- */}
      {/* flex-col h-full ensures it fits the container. justify-between spreads content. */}
      <div className="relative z-10 flex flex-col h-full w-full">
        
        {/* === TOP SECTION: Content (Date & Quote) === */}
        {/* flex-1 with justify-center forces this to take up available space and center vertically */}
        <div className="flex-1 flex flex-col justify-center px-8 w-full">
           
           <div className="max-w-5xl mx-auto w-full flex flex-col md:flex-row md:items-center md:justify-between gap-8 md:gap-24">
               {/* Date Widget - Natural Flow */}
               <div className="flex flex-col gap-2 md:shrink-0">
                  <div className="flex items-baseline gap-3">
                     {/* FIX: Use distinct colors for light/dark mode instead of 'text-transparent' which breaks in light mode overrides */}
                     <span className="text-6xl md:text-9xl font-serif font-bold tracking-tighter text-slate-800 dark:text-white dark:bg-clip-text dark:bg-gradient-to-br dark:from-white dark:to-white/60 dark:text-transparent text-glow">
                       {new Date().getDate()}
                     </span>
                     <div className="flex flex-col border-l-2 border-slate-300 dark:border-white/20 pl-4 md:pl-6 justify-center">
                        <span className="text-sm md:text-xl font-bold text-indigo-500 dark:text-indigo-300 uppercase tracking-widest">{dateInfo.weekday}</span>
                        <span className="text-lg md:text-3xl text-slate-600 dark:text-white/80">{new Date().toLocaleString('default', { month: 'long' })} {dateInfo.year}</span>
                     </div>
                  </div>
               </div>

               {/* Quote Container - FIXED HEIGHT to prevent jumping */}
               <div className="relative w-full perspective-1000 flex flex-col justify-center min-h-[160px] md:min-h-[240px]">
                  <Quote size={40} className="text-slate-300 dark:text-white/20 absolute -top-8 -left-2 md:-top-10 md:-left-10" />
                  
                  <div className="flex items-center">
                    <h2 
                        className={`
                        font-serif leading-tight tracking-wide
                        transition-all duration-1000 ease-in-out
                        ${animState === 'active' ? 'opacity-100 blur-0 scale-100 translate-y-0' : ''}
                        ${animState === 'exiting' ? 'opacity-0 blur-xl scale-105 -translate-y-4' : ''}
                        ${animState === 'entering' ? 'opacity-0 blur-md scale-95 translate-y-4' : ''}
                        `}
                        style={{
                        fontSize: 'clamp(1.5rem, 4vw, 3.5rem)', // slightly smaller min for mobile
                        color: 'inherit', // Let global color rules handle it (dark text in light mode, white in dark)
                        textShadow: 'var(--text-shadow-glow, none)'
                        }}
                    >
                        {currentQuote}
                    </h2>
                  </div>

                  {/* Decorative Dots */}
                  <div className={`mt-8 flex gap-2 transition-opacity duration-1000 ${animState==='active'?'opacity-100':'opacity-0'}`}>
                     <div className="w-2 h-2 rounded-full bg-indigo-500 dark:bg-indigo-400 animate-bounce" style={{animationDelay: '0s'}}></div>
                     <div className="w-2 h-2 rounded-full bg-indigo-400 dark:bg-indigo-400/50 animate-bounce" style={{animationDelay: '0.2s'}}></div>
                     <div className="w-2 h-2 rounded-full bg-indigo-300 dark:bg-indigo-400/20 animate-bounce" style={{animationDelay: '0.4s'}}></div>
                  </div>
               </div>
           </div>
        </div>

        {/* === BOTTOM SECTION: Compact Action Deck (One Page Fit) === */}
        {/* shrink-0 ensures this doesn't get squashed. pb-4 adds a little breathing room above the nav bar area */}
        <div className="w-full max-w-5xl mx-auto px-6 shrink-0 pb-6 md:pb-16 md:mt-auto">
           
           {/* Primary Actions Grid */}
           <div className="grid grid-cols-2 gap-4 mb-4">
                 {/* Card 1: Configurable */}
                 <button 
                   onClick={() => { triggerHaptic('light'); window.open(globalConfig.todoCard1.url, '_blank'); }}
                   className="relative group h-28 md:h-40 glass-card rounded-3xl p-5 flex flex-col justify-between overflow-hidden hover:bg-white/50 dark:hover:bg-white/10 active:scale-[0.98]"
                 >
                    <div className="absolute right-0 top-0 p-4 opacity-20 group-hover:opacity-100 transition-opacity duration-500 group-hover:rotate-45 transform">
                       <Plus className="text-indigo-400 dark:text-indigo-300" size={28} />
                    </div>
                    <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 dark:bg-indigo-500/20 border border-indigo-500/20 dark:border-indigo-500/30 flex items-center justify-center text-indigo-500 dark:text-indigo-300 group-hover:text-white group-hover:bg-indigo-500 group-hover:shadow-[0_0_20px_rgba(99,102,241,0.5)] transition-all duration-300">
                       {renderIcon(globalConfig.todoCard1.iconName || 'CalendarPlus', 20)}
                    </div>
                    <div className="text-left">
                       <div className="text-sm font-bold text-slate-800 dark:text-gray-100 group-hover:translate-x-1 transition-transform">{globalConfig.todoCard1.title}</div>
                       <div className="text-[10px] text-slate-500 dark:text-gray-400 mt-0.5 group-hover:text-slate-700 dark:group-hover:text-gray-300 w-full truncate">{globalConfig.todoCard1.subtitle}</div>
                    </div>
                 </button>

                 {/* Card 2: Configurable */}
                 <button 
                   onClick={() => { triggerHaptic('light'); window.open(globalConfig.todoCard2.url, '_blank'); }}
                   className="relative group h-28 md:h-40 glass-card rounded-3xl p-5 flex flex-col justify-between overflow-hidden hover:bg-white/50 dark:hover:bg-white/10 active:scale-[0.98]"
                 >
                    <div className="absolute right-0 top-0 p-4 opacity-20 group-hover:opacity-100 transition-opacity duration-500 group-hover:rotate-45 transform">
                       <ArrowUpRight className="text-purple-400 dark:text-purple-300" size={28} />
                    </div>
                    <div className="w-10 h-10 rounded-2xl bg-purple-500/10 dark:bg-purple-500/20 border border-purple-500/20 dark:border-purple-500/30 flex items-center justify-center text-purple-500 dark:text-purple-300 group-hover:text-white group-hover:bg-purple-500 group-hover:shadow-[0_0_20px_rgba(168,85,247,0.5)] transition-all duration-300">
                       {renderIcon(globalConfig.todoCard2.iconName || 'Calendar', 20)}
                    </div>
                    <div className="text-left">
                       <div className="text-sm font-bold text-slate-800 dark:text-gray-100 group-hover:translate-x-1 transition-transform">{globalConfig.todoCard2.title}</div>
                       <div className="text-[10px] text-slate-500 dark:text-gray-400 mt-0.5 group-hover:text-slate-700 dark:group-hover:text-gray-300 w-full truncate">{globalConfig.todoCard2.subtitle}</div>
                    </div>
                 </button>
           </div>

           {/* Sync Guide Hint Card */}
           <button 
              onClick={() => { setShowGuideModal(true); triggerHaptic('selection'); }}
              className="w-full glass-card rounded-2xl p-4 flex items-center justify-between group active:scale-[0.99] transition-all hover:bg-white/50 dark:hover:bg-white/10 relative overflow-hidden"
           >
              <div className="absolute inset-0 bg-blue-500/5 dark:bg-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <div className="flex items-center gap-3 relative z-10">
                  <div className="w-10 h-10 rounded-full bg-blue-500/10 dark:bg-blue-500/20 text-blue-500 dark:text-blue-400 flex items-center justify-center border border-blue-200 dark:border-blue-500/30">
                      <HelpCircle size={20} />
                  </div>
                  <div className="text-left">
                      <div className="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2">
                          开启系统级强提醒
                          <span className="text-[9px] px-1.5 py-0.5 rounded bg-red-100 dark:bg-red-500/20 text-red-500 dark:text-red-300">推荐</span>
                      </div>
                      <div className="text-[10px] text-slate-500 dark:text-white/50">保证任务能同步到系统日历，调用原生通知</div>
                  </div>
              </div>
              <ChevronRight size={16} className="text-slate-400 dark:text-white/30 group-hover:translate-x-1 transition-transform relative z-10"/>
           </button>

        </div>

      </div>

      {/* Guide Modal */}
      {showGuideModal && (
        <ModalPortal>
            <div className="fixed inset-0 z-[100] flex items-end md:items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in" onClick={() => setShowGuideModal(false)}>
                <div className="glass-panel w-full max-w-2xl rounded-t-[2rem] md:rounded-3xl p-0 flex flex-col max-h-[90vh] bg-white/95 dark:bg-gray-900/95 relative shadow-2xl" onClick={e => e.stopPropagation()}>
                    {/* Header */}
                    <div className="p-6 pb-4 border-b border-gray-100 dark:border-white/10 flex justify-between items-center shrink-0">
                        <div>
                            <h3 className="text-xl font-bold text-slate-900 dark:text-white">系统日历同步指南</h3>
                            <p className="text-xs text-slate-500 dark:text-white/60 mt-1">如何同步 WPS 日历到第三方日历</p>
                        </div>
                        <button onClick={() => setShowGuideModal(false)} className="p-2 bg-gray-100 dark:bg-white/10 rounded-full text-slate-500 dark:text-white/60 hover:bg-gray-200 dark:hover:bg-white/20 transition-colors"><X size={20}/></button>
                    </div>

                    {/* Scrollable Content */}
                    <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-8">
                        {/* FEATURE: Rich Text Render for Custom Guide */}
                        {globalConfig.calendarGuideHtml && globalConfig.calendarGuideHtml.trim() !== "" ? (
                            <div className="space-y-4 animate-fade-in">
                                <div className="p-4 bg-indigo-50 dark:bg-indigo-500/10 border border-indigo-100 dark:border-indigo-500/20 rounded-xl">
                                    <h4 className="font-bold text-indigo-700 dark:text-indigo-300 text-sm mb-2 flex items-center gap-2">
                                        <BookOpen size={16}/> 组织专属教程
                                    </h4>
                                    <div 
                                        className="prose dark:prose-invert prose-sm max-w-none text-slate-600 dark:text-white/80 leading-relaxed text-xs [&>p]:mb-2 [&>ul]:list-disc [&>ul]:pl-4 [&>ol]:list-decimal [&>ol]:pl-4"
                                        dangerouslySetInnerHTML={{__html: globalConfig.calendarGuideHtml}} 
                                    />
                                </div>
                            </div>
                        ) : (
                            <>
                                {/* Default Guide Content */}
                                <div className="space-y-2">
                                    <h4 className="font-bold text-slate-800 dark:text-white flex items-center gap-2 text-sm"><Lightbulb size={16} className="text-amber-500"/> 功能介绍</h4>
                                    <p className="text-xs text-slate-600 dark:text-white/70 leading-relaxed bg-amber-50 dark:bg-amber-500/10 p-3 rounded-xl border border-amber-100 dark:border-amber-500/20">
                                        您可以通过 <span className="font-bold">CalDAV</span> 协议把 WPS 日历同步到手机或电脑的系统日历中。这样可以保证任务能调用系统的<span className="font-bold">原生通知提醒</span>，避免后台查杀导致错过重要事项。
                                    </p>
                                </div>

                                {/* Step 1 */}
                                <div className="space-y-3">
                                    <h4 className="font-bold text-slate-800 dark:text-white text-lg flex items-center gap-2">
                                        <span className="w-6 h-6 rounded-full bg-indigo-500 text-white flex items-center justify-center text-xs">1</span> 
                                        生成帐号
                                    </h4>
                                    <div className="text-sm text-slate-600 dark:text-white/80 pl-8 space-y-2">
                                        <p>目前仅支持在 <strong>PC网页端</strong> 获取 CalDAV 帐号：</p>
                                        <ol className="list-decimal list-inside space-y-1 text-xs bg-gray-50 dark:bg-white/5 p-3 rounded-xl">
                                            <li>打开日历首页 (rili.wps.cn)</li>
                                            <li>点击右上角“设置”</li>
                                            <li>找到 <strong>CalDAV 设置</strong></li>
                                            <li>选择需要同步的设备，点击生成即可获取帐号密码</li>
                                        </ol>
                                    </div>
                                </div>

                                {/* Step 2 */}
                                <div className="space-y-4">
                                    <h4 className="font-bold text-slate-800 dark:text-white text-lg flex items-center gap-2">
                                        <span className="w-6 h-6 rounded-full bg-indigo-500 text-white flex items-center justify-center text-xs">2</span> 
                                        添加帐号
                                    </h4>
                                    
                                    {/* Tabs */}
                                    <div className="flex gap-2 pl-8 overflow-x-auto pb-1 hide-scrollbar">
                                        {[
                                            {id: 'ios', label: 'iOS', icon: Apple},
                                            {id: 'mac', label: 'Mac', icon: Monitor},
                                            {id: 'xiaomi', label: '小米', icon: Smartphone},
                                            {id: 'honor', label: '荣耀', icon: Smartphone},
                                            {id: 'android', label: '其他安卓', icon: MoreHorizontal},
                                        ].map(tab => (
                                            <button 
                                                key={tab.id}
                                                onClick={() => setGuideTab(tab.id as any)}
                                                className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all whitespace-nowrap ${guideTab === tab.id ? 'bg-indigo-500 text-white shadow-md' : 'bg-gray-100 dark:bg-white/10 text-slate-500 dark:text-white/60'}`}
                                            >
                                                <tab.icon size={12} /> {tab.label}
                                            </button>
                                        ))}
                                    </div>

                                    <div className="pl-8">
                                        <div className="bg-gray-50 dark:bg-white/5 border border-gray-100 dark:border-white/10 rounded-xl p-4 text-sm text-slate-600 dark:text-white/80">
                                            {guideTab === 'ios' && (
                                                <ul className="space-y-2 list-disc list-inside text-xs leading-relaxed">
                                                    <li>打开 <strong>设置</strong> → <strong>日历</strong> → <strong>账户</strong></li>
                                                    <li>点击 <strong>添加账户</strong> → <strong>其他</strong></li>
                                                    <li>选择 <strong>添加 CalDAV 账户</strong> <span className="text-red-500">(注意：不是 CardDAV)</span></li>
                                                    <li>输入之前获取的服务器地址、用户名、密码</li>
                                                    <li>验证通过后保存即可</li>
                                                </ul>
                                            )}
                                            {guideTab === 'mac' && (
                                                <ul className="space-y-2 list-disc list-inside text-xs leading-relaxed">
                                                    <li>打开 <strong>系统偏好设置</strong> → <strong>互联网账户</strong></li>
                                                    <li>点击 <strong>添加 CalDAV 账户</strong></li>
                                                    <li>设置 "账户类型" 为 <strong>手动</strong></li>
                                                    <li>填入刚才获取的账户与密码即可</li>
                                                </ul>
                                            )}
                                            {guideTab === 'xiaomi' && (
                                                <ul className="space-y-2 list-disc list-inside text-xs leading-relaxed">
                                                    <li>打开 <strong>小米日历</strong> App</li>
                                                    <li>点击右上角菜单/更多 → <strong>日程导入</strong></li>
                                                    <li>选择 <strong>CalDAV 帐号导入</strong></li>
                                                    <li>输入获取的用户名、密码、服务器地址即可</li>
                                                </ul>
                                            )}
                                            {guideTab === 'honor' && (
                                                <ul className="space-y-2 list-disc list-inside text-xs leading-relaxed">
                                                    <li>打开 <strong>系统设置</strong> → <strong>用户和账户</strong> → 添加账户</li>
                                                    <li>选择 <strong>日历</strong> → <strong>金山日历</strong></li>
                                                    <li>或者：打开日历应用 → 更多 → 账户管理 → 添加 → 金山日历</li>
                                                    <li>登录需要同步的金山办公账号即可</li>
                                                </ul>
                                            )}
                                            {guideTab === 'android' && (
                                                <div className="space-y-3">
                                                    <p className="text-xs">部分厂商未原生支持，建议使用 <strong>DAVdroid</strong> 等第三方应用：</p>
                                                    <ul className="space-y-2 list-disc list-inside text-xs leading-relaxed">
                                                        <li>在 DAVdroid 点击添加账户 → 选择 <strong>使用 URL 和用户名登录</strong></li>
                                                        <li>输入获取的用户名、密码、服务器地址</li>
                                                        <li>添加成功后进入帐号 → 选择 CalDAV → 同步 icon</li>
                                                        <li><span className="text-amber-500">注：需保持软件后台运行，同步可能有延迟</span></li>
                                                    </ul>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            </>
                        )}

                        {/* FAQ */}
                        <div className="space-y-3 pt-4 border-t border-gray-100 dark:border-white/10">
                            <h4 className="font-bold text-slate-800 dark:text-white text-sm">常见问题</h4>
                            <div className="space-y-3">
                                <div>
                                    <div className="text-xs font-bold text-slate-700 dark:text-white/90 mb-1">Q: 自动同步的日历范围有哪些？</div>
                                    <div className="text-xs text-slate-500 dark:text-white/60">A: 在日历首页“我的日历”下可查看的日历会同步，共享日历暂不支持。</div>
                                </div>
                                <div>
                                    <div className="text-xs font-bold text-slate-700 dark:text-white/90 mb-1">Q: 同步的日历支持编辑吗？</div>
                                    <div className="text-xs text-slate-500 dark:text-white/60">A: 目前同步日程仅支持查看，<span className="text-red-500">不支持编辑</span>。</div>
                                </div>
                                <div>
                                    <div className="text-xs font-bold text-slate-700 dark:text-white/90 mb-1">Q: 哪些功能不支持？</div>
                                    <div className="text-xs text-slate-500 dark:text-white/60">A: 附件、新建日历、会议室查看、参与者列表、金山会议暂不支持同步。</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Footer */}
                    <div className="p-4 border-t border-gray-100 dark:border-white/10 text-center shrink-0 bg-gray-50/50 dark:bg-black/20 rounded-b-[2rem] md:rounded-b-3xl">
                        <p className="text-[10px] text-slate-400 dark:text-white/40 font-medium">
                            感谢 <span className="font-bold text-slate-500 dark:text-white/60">金山日历官方</span> 提供技术方案
                        </p>
                    </div>
                </div>
            </div>
        </ModalPortal>
      )}

      {/* Perspective CSS */}
      <style>{`
        .perspective-1000 { perspective: 1000px; }
      `}</style>
    </div>
  );
};

export default TodoView;
