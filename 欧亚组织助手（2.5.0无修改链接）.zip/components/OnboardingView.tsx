
import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, Department, LinkCard } from '../types';
import { getStoredDepartments, saveUserProfile, importAllData, generateUserId, getUserProfile, clearUserProfile, saveStoredDepartments, switchAccount, getSavedAccounts, compressImage } from '../services/storageService';
import { parseColorCode, unpackageData } from '../services/cimbarService';
import { triggerHaptic } from '../services/hapticService';
import { Camera, Sparkles, User, Users, Crown, ArrowRight, Calendar, ChevronRight, Check, ShieldCheck, Fingerprint, UserPlus, QrCode, UploadCloud, Lock, AlertCircle, FileCheck, RefreshCw, ArrowLeft, HardDrive, LogIn, Repeat, Building2, Plus, Settings2, Trash2, Edit3, School, GraduationCap } from 'lucide-react';

interface OnboardingProps {
  onComplete: () => void;
}

const DEFAULT_POSITIONS = [
  { id: 'level_1', label: '部员', en: 'MEMBER', icon: User, color: '14, 165, 233', desc: '星火汇聚 · 基石之力' }, // Sky Blue
  { id: 'level_2', label: '干事', en: 'OFFICER', icon: Users, color: '139, 92, 246', desc: '中流砥柱 · 承上启下' }, // Violet
  { id: 'level_3', label: '部长', en: 'MINISTER', icon: Crown, color: '249, 115, 22', desc: '领航掌舵 · 开拓前行' }, // Orange
];

// Colleges list for Branch Selection
export const COLLEGES = [
    '人文教育学院',
    '会计学院',
    '工商管理学院',
    '通识教育学院',
    '金融与数据科学学院',
    '艾德艺术设计学院',
    '文化传媒学院',
    '人居环境学院',
    '信息工程学院',
    '职业教育学院',
    '马克思主义学院',
    '校级组织'
];

const DEFAULT_COLLEGE = '人文教育学院';

const LOADING_MESSAGES = [
  "正在构建身份契约...",
  "写入本地存储空间...",
  "加密个人档案信息...",
  "同步部门权限配置...",
  "系统初始化完成，欢迎归队。"
];

// Helper to generate default cards for new custom departments
const generateDefaultCardsForDept = (deptId: string): LinkCard[] => {
    return [
        { id: `${deptId}_roster`, title: '人员花名册', description: '部门成员通讯录', url: 'https://docs.qq.com/sheet/example', iconName: 'Users', category: '通用服务' },
        { id: `${deptId}_leave`, title: '例会请假', description: '会议请假申请', url: 'https://docs.qq.com/form/example', iconName: 'FileText', category: '通用服务' },
        { id: `${deptId}_signin`, title: '例会签到', description: '扫码签到入口', url: 'https://docs.qq.com/form/example', iconName: 'Calendar', category: '通用服务' },
        { id: `${deptId}_profile`, title: '个人中心', description: '查看个人档案', url: '#settings', iconName: 'Monitor', category: '通用服务' }
    ];
};

class StarParticle {
  x: number;
  y: number;
  size: number;
  speedX: number;
  speedY: number;
  brightness: number;
  targetAlpha: number;

  constructor(height: number) {
    this.x = (Math.random() - 0.5) * 1000; 
    this.y = Math.random() * height;
    this.size = Math.random() * 2;
    this.speedX = (Math.random() - 0.5) * 0.3;
    this.speedY = (Math.random() - 0.5) * 0.3;
    this.brightness = 0;
    this.targetAlpha = Math.random() * 0.8 + 0.2;
  }

  update(height: number) {
    this.x += this.speedX;
    this.y += this.speedY;

    const bound = 500; 
    if (this.x < -bound) this.x = bound;
    if (this.x > bound) this.x = -bound;

    if (this.y < 0) this.y = height;
    if (this.y > height) this.y = 0;

    if (Math.random() < 0.05) {
        this.brightness = Math.random();
    } else {
        this.brightness += (this.targetAlpha - this.brightness) * 0.05;
    }
  }

  getScreenPos(width: number) {
      return {
          x: (width / 2) + this.x,
          y: this.y
      };
  }
}

const OnboardingView: React.FC<OnboardingProps> = ({ onComplete }) => {
  const [departments, setDepartments] = useState<Department[]>(getStoredDepartments());
  const existingProfile = getUserProfile();
  
  // Step Mapping:
  // -5: Login (Welcome Back)
  // -2: Restore (CIMBAR)
  // -1: Choice (New/Restore)
  // 0: Org Type Selection
  // 1: College Selection
  // 2: Role Selection
  // 3: Basic Info (Name/Dept)
  // 4: Birthday
  // 5: Avatar
  // 6: Loading
  
  const [step, setStep] = useState(existingProfile ? -5 : -1); 
  const [loadingIndex, setLoadingIndex] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);

  // --- Register State ---
  const [name, setName] = useState('');
  const [birthday, setBirthday] = useState('');
  const [avatar, setAvatar] = useState('');
  
  // Organization State
  const [orgMode, setOrgMode] = useState<'standard' | 'custom'>('standard');
  const [selectedCollege, setSelectedCollege] = useState(DEFAULT_COLLEGE);
  const [customOrgName, setCustomOrgName] = useState('');

  // Role Configuration State
  const [roleConfigMode, setRoleConfigMode] = useState<'standard' | 'custom'>('standard');
  const [customRoles, setCustomRoles] = useState(DEFAULT_POSITIONS);
  const [selectedRoleId, setSelectedRoleId] = useState(DEFAULT_POSITIONS[0].id);

  // Department Configuration State
  const [deptConfigMode, setDeptConfigMode] = useState<'standard' | 'custom'>('standard');
  const [selectedDeptId, setSelectedDeptId] = useState('');
  const [customDeptsList, setCustomDeptsList] = useState<string[]>([]);
  const [newDeptInput, setNewDeptInput] = useState('');

  // Import State
  const [importStep, setImportStep] = useState<'upload' | 'decrypt' | 'confirm' | 'auth_check' | 'legacy_reveal'>('upload');
  const [importError, setImportError] = useState<string | null>(null);
  const [rawPayload, setRawPayload] = useState<string>('');
  const [decryptPass, setDecryptPass] = useState('');
  const [restoredData, setRestoredData] = useState<any>(null);
  const [isProcessingImg, setIsProcessingImg] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particlesRef = useRef<StarParticle[]>([]);
  
  // Initialize default dept selection
  useEffect(() => {
      if (departments.length > 0) {
          setSelectedDeptId(departments[0].id);
      }
  }, []);

  // Sync role/dept modes when org changes
  useEffect(() => {
      if (orgMode === 'custom') {
          // If custom org selected, default to custom modes for better UX, but allow switch back
          setRoleConfigMode('custom');
          setDeptConfigMode('custom');
          setCustomDeptsList([]); // Reset custom depts
      } else {
          setRoleConfigMode('standard');
          setDeptConfigMode('standard');
          setCustomRoles(DEFAULT_POSITIONS);
      }
  }, [orgMode]);

  // Particle Animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = window.innerWidth;
    let height = window.innerHeight;
    canvas.width = width;
    canvas.height = height;

    particlesRef.current = Array.from({ length: 120 }, () => new StarParticle(height));

    const render = () => {
      ctx.clearRect(0, 0, width, height);
      // Determine active color based on selected role
      const activeRole = customRoles.find(p => p.id === selectedRoleId);
      const activeColor = step >= 2 ? (activeRole?.color || '255, 255, 255') : '100, 116, 139'; 
      
      const positions: {x: number, y: number}[] = [];

      particlesRef.current.forEach(p => {
        p.update(height);
        const pos = p.getScreenPos(width);
        positions.push(pos);

        ctx.fillStyle = `rgba(${activeColor}, ${p.brightness})`;
        ctx.beginPath();
        ctx.arc(pos.x, pos.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      });
      
      ctx.strokeStyle = `rgba(${activeColor}, 0.15)`;
      ctx.lineWidth = 0.5;
      
      for (let i = 0; i < positions.length; i++) {
        for (let j = i + 1; j < positions.length; j++) {
            const dx = positions[i].x - positions[j].x;
            const dy = positions[i].y - positions[j].y;
            if (Math.abs(dx) > 120 || Math.abs(dy) > 120) continue;

            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < 120) {
                ctx.beginPath();
                ctx.moveTo(positions[i].x, positions[i].y);
                ctx.lineTo(positions[j].x, positions[j].y);
                ctx.stroke();
            }
        }
      }
      requestAnimationFrame(render);
    };
    render();

    const handleResize = () => {
        width = window.innerWidth;
        height = window.innerHeight;
        canvas.width = width;
        canvas.height = height;
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [selectedRoleId, step, customRoles]);

  const goToStep = (nextStep: number) => {
    triggerHaptic('light');
    setIsTransitioning(true);
    setTimeout(() => {
        setStep(nextStep);
        setIsTransitioning(false);
        window.scrollTo(0,0);
        setTimeout(() => triggerHaptic('medium'), 50);
    }, 400); 
  };

  // --- Logic: Add Custom Department ---
  const handleAddCustomDept = () => {
      if (newDeptInput.trim()) {
          setCustomDeptsList([...customDeptsList, newDeptInput.trim()]);
          setNewDeptInput('');
          triggerHaptic('success');
      }
  };

  const handleRemoveCustomDept = (index: number) => {
      const newList = [...customDeptsList];
      newList.splice(index, 1);
      setCustomDeptsList(newList);
      triggerHaptic('warning');
  };

  // --- Logic: Finalize Registration ---
  const handleFinishRegister = () => {
    const registerDate = new Date().toISOString().split('T')[0];
    
    // 1. Determine Final Role Name
    const selectedRoleObj = customRoles.find(r => r.id === selectedRoleId);
    const finalPositionName = selectedRoleObj?.label || '成员';

    // 2. Determine Final Organization Name
    // Rule: School + College + OrgName
    let finalOrgName = '';
    let finalCollege = '';

    if (orgMode === 'standard') {
        finalCollege = selectedCollege;
        // If standard, default to "Student Growth Promotion Association" if not specified
        finalOrgName = `西安欧亚学院${selectedCollege}学生成长促进会`;
    } else {
        // Custom Org
        finalOrgName = customOrgName;
        finalCollege = selectedCollege; // Use selected college even for custom orgs
    }

    // CRITICAL: Check for Duplicate Org Name to prevent overwriting existing accounts
    const savedAccounts = getSavedAccounts();
    if (savedAccounts.some(acc => acc.organization === finalOrgName && !acc.isCurrent)) {
        alert('错误：本地已存在名为“' + finalOrgName + '”的组织数据。\n\n请修改组织名称（例如添加后缀），否则将覆盖原有存档。');
        triggerHaptic('error');
        return;
    }

    // 3. Determine Final Departments & Dept ID
    let finalDeptId = selectedDeptId;
    
    if (deptConfigMode === 'custom') {
        if (customDeptsList.length === 0) {
            alert('请至少添加一个部门');
            return;
        }
        
        const newDepartments: Department[] = customDeptsList.map((deptName, index) => {
            const id = `custom_dept_${Date.now()}_${index}`;
            return {
                id: id,
                name: deptName,
                description: `${finalOrgName} - ${deptName}`,
                cards: generateDefaultCardsForDept(id),
                announcements: []
            };
        });
        
        saveStoredDepartments(newDepartments);
        
        if (!finalDeptId || !newDepartments.find(d => d.id === finalDeptId)) {
             finalDeptId = newDepartments[0].id;
        }
    }

    const userId = generateUserId(name, finalDeptId, finalPositionName, registerDate);
    
    const profile: UserProfile = {
        name,
        departmentId: finalDeptId,
        position: finalPositionName,
        avatar,
        birthday,
        organization: finalOrgName,
        college: finalCollege, // Save separate college field
        registerDate,
        userId,
        identity: 'user' // Default to User. Upgrades to permanent_admin if criteria met.
    };
    
    saveUserProfile(profile);
    triggerHaptic('heavy');
    goToStep(6); // Go to Loading Step
  };

  const handleLoginExisting = () => {
      localStorage.removeItem('eurasia_logged_out');
      triggerHaptic('success');
      onComplete();
  };

  // FIX: Use switchAccount('NEW_ACCOUNT') instead of destructive wipe
  const handleSwitchAccount = () => {
      if (confirm('即将为您创建新的身份档案。\n\n当前账号数据将自动备份，稍后可在主界面顶部的‘切换组织’中找回。\n\n确定继续吗？')) {
          switchAccount('NEW_ACCOUNT'); // This safely backs up current data and resets active keys
          // Note: switchAccount reloads the page, so we don't need to manually goToStep(-1) usually,
          // but if it's instant, the reload handles the state reset.
      }
  };

  // --- Import Logic ---
  const handleCimbarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setIsProcessingImg(true);
    setImportError(null);
    triggerHaptic('selection');

    const reader = new FileReader();
    reader.onload = (event) => {
       const img = new Image();
       img.onload = async () => {
          try {
             const jsonStr = await parseColorCode(img);
             setRawPayload(jsonStr);
             triggerHaptic('success');
             
             // Check encryption
             const payload = JSON.parse(jsonStr);
             if (payload.e) {
                setImportStep('decrypt');
             } else {
                try {
                   const finalData = unpackageData(jsonStr);
                   setRestoredData(finalData);
                   setImportStep('confirm');
                } catch(err) {
                   setImportError('数据完整性校验失败');
                   triggerHaptic('error');
                }
             }
          } catch (e) {
             setImportError('无法识别有效的配置码，请确保图片清晰');
             triggerHaptic('error');
          } finally {
             setIsProcessingImg(false);
          }
       };
       img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleDecrypt = () => {
    try {
        const finalData = unpackageData(rawPayload, decryptPass);
        setRestoredData(finalData);
        setImportStep('confirm');
        setImportError(null);
        triggerHaptic('success');
    } catch (e) {
        setImportError('密码错误或数据损坏');
        triggerHaptic('error');
    }
  };

  const confirmRestore = () => {
     if (restoredData) {
        triggerHaptic('heavy');
        importAllData(restoredData);
        localStorage.removeItem('eurasia_logged_out');
        goToStep(6); // Go to loading/finish animation
     }
  };


  useEffect(() => {
    if (step === 6) {
        let currentMsg = 0;
        const interval = setInterval(() => {
            currentMsg++;
            if (currentMsg >= LOADING_MESSAGES.length) {
                clearInterval(interval);
                triggerHaptic('success'); // Final success
                setTimeout(onComplete, 800);
            } else {
                setLoadingIndex(currentMsg);
                triggerHaptic('tick');
            }
        }, 1200);
        return () => clearInterval(interval);
    }
  }, [step, onComplete]);

  // FIX: Apply compressImage to avatar upload
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
          const compressed = await compressImage(file, 300, 0.7);
          setAvatar(compressed);
          triggerHaptic('medium');
      } catch (err) {
          alert('图片处理失败，请重试');
      }
    }
  };

  return (
    // FORCE DARK THEME for Onboarding
    // HIDE SCROLLBAR globally for this view
    <div className="fixed inset-0 bg-[#02040a] text-always-white font-sans flex flex-col">
      <canvas ref={canvasRef} className="absolute inset-0 z-0 opacity-60 pointer-events-none" />
      
      {/* Background Glow follows active role color */}
      <div 
         className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full blur-[120px] transition-colors duration-1000 opacity-20 pointer-events-none z-0"
         style={{ background: step >= 2 ? `rgb(${customRoles.find(p=>p.id===selectedRoleId)?.color || '100,116,139'})` : '#64748b' }}
      ></div>

      <div className="relative z-10 w-full h-full overflow-y-auto overflow-x-hidden hide-scrollbar">
         <div className="min-h-full w-full flex flex-col items-center justify-center py-8 px-6">
            
            {/* STEP -5: WELCOME BACK (LOGIN) */}
            {step === -5 && existingProfile && (
               <div className={`w-full max-w-sm text-center transition-all duration-500 animate-fade-in ${isTransitioning ? 'opacity-0 scale-95' : 'opacity-100 scale-100'}`}>
                   {/* ... (Existing Login UI) ... */}
                   <div className="w-24 h-24 rounded-full border-4 border-white/20 mx-auto mb-6 overflow-hidden bg-white/10 shadow-[0_0_30px_rgba(255,255,255,0.2)]">
                       {existingProfile.avatar ? <img src={existingProfile.avatar} className="w-full h-full object-cover" /> : <User size={48} className="text-white/50 w-full h-full p-4"/>}
                   </div>
                   <h1 className="text-2xl font-bold text-always-white mb-1">欢迎回来，{existingProfile.name}</h1>
                   <p className="text-always-white/50 text-sm mb-8">{existingProfile.position} · {existingProfile.organization}</p>
                   
                   <button 
                     onClick={handleLoginExisting}
                     className="w-full py-4 bg-white text-black rounded-full font-bold text-lg hover:bg-gray-100 transition-colors shadow-lg flex items-center justify-center gap-2 mb-6 active:scale-95"
                   >
                      <LogIn size={20}/> 登录原账号
                   </button>

                   <div className="pt-6 border-t border-white/10">
                      <p className="text-xs text-always-white/40 mb-3">不是本人？</p>
                      <button onClick={handleSwitchAccount} className="text-sm font-bold text-indigo-400 hover:text-indigo-300 flex items-center justify-center gap-1 mx-auto transition-colors">
                          注册新账号 <ArrowRight size={14}/>
                      </button>
                   </div>
               </div>
            )}

            {/* ... (Previous Steps -1, -2, 0, 1, 2 unchanged) ... */}
            
            {/* STEP -1: INITIAL CHOICE */}
            {step === -1 && (
               <div className={`w-full max-w-4xl transition-all duration-500 animate-fade-in ${isTransitioning ? 'opacity-0 scale-95' : 'opacity-100 scale-100'}`}>
                   {/* ... (Existing Choice UI) ... */}
                   <div className="text-center mb-16">
                       <h1 className="text-4xl md:text-7xl font-serif font-bold tracking-widest mb-6 text-transparent bg-clip-text bg-gradient-to-br from-white via-slate-200 to-slate-400 drop-shadow-lg text-always-white">
                          欧亚组织助手
                       </h1>
                       <div className="flex items-center justify-center gap-4 opacity-60">
                          <div className="h-px w-12 bg-white/50"></div>
                          <p className="text-xs md:text-sm tracking-[0.4em] uppercase font-light font-sans text-always-white">Eurasia Organization Assistant</p>
                          <div className="h-px w-12 bg-white/50"></div>
                       </div>
                   </div>

                   <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-12">
                       {/* Choice A: New User */}
                       <button 
                         onClick={() => goToStep(0)}
                         className="group relative bg-white/5 hover:bg-white/10 border border-white/10 rounded-3xl p-8 md:p-12 text-left transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl hover:shadow-blue-900/20 active:scale-95 overflow-hidden"
                       >
                          <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform duration-500">
                             <UserPlus size={100} className="text-always-white" />
                          </div>
                          <div className="relative z-10">
                             <div className="w-16 h-16 rounded-2xl bg-blue-500/20 flex items-center justify-center text-blue-300 mb-6 group-hover:bg-blue-500 group-hover:text-white transition-colors">
                                <UserPlus size={32} className="text-always-white"/>
                             </div>
                             <h3 className="text-2xl font-bold mb-2 text-always-white">我是新成员</h3>
                             <p className="text-always-white/50 text-sm">注册新身份，初始化系统配置，开启您的成长之旅。</p>
                          </div>
                       </button>

                       {/* Choice B: Restore User */}
                       <button 
                         onClick={() => { setImportStep('upload'); setRestoredData(null); setRawPayload(''); setImportError(null); goToStep(-2); }}
                         className="group relative bg-white/5 hover:bg-white/10 border border-white/10 rounded-3xl p-8 md:p-12 text-left transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl hover:shadow-purple-900/20 active:scale-95 overflow-hidden"
                       >
                          <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform duration-500">
                             <QrCode size={100} className="text-always-white" />
                          </div>
                          <div className="relative z-10">
                             <div className="w-16 h-16 rounded-2xl bg-purple-500/20 flex items-center justify-center text-purple-300 mb-6 group-hover:bg-purple-500 group-hover:text-white transition-colors">
                                <QrCode size={32} className="text-always-white"/>
                             </div>
                             <h3 className="text-2xl font-bold mb-2 text-always-white">已有账号</h3>
                             <p className="text-always-white/50 text-sm">通过彩色配置码 (CIMBAR) 恢复个人档案与数据。</p>
                          </div>
                       </button>
                   </div>
               </div>
            )}

            {/* STEP -2: RESTORE ACCOUNT */}
            {step === -2 && (
              <div className={`w-full max-w-md transition-all duration-500 animate-fade-in ${isTransitioning ? 'opacity-0 scale-95 translate-y-4' : 'opacity-100 scale-100 translate-y-0'}`}>
                 <div className="flex items-center gap-2 mb-8">
                   <button onClick={() => goToStep(-1)} className="p-2 bg-white/5 rounded-full hover:bg-white/10 transition-colors text-always-white"><ArrowLeft size={20} className="text-always-white"/></button>
                   <span className="text-xs text-always-white/40 uppercase tracking-widest">Account Recovery</span>
                </div>

                <div className="text-center mb-10">
                    <h1 className="text-3xl font-bold mb-2 text-always-white">恢复身份</h1>
                    <p className="text-always-white/50 text-sm">上传您的彩色配置码以恢复数据</p>
                </div>

                {/* Upload State */}
                {importStep === 'upload' && (
                    <div className="animate-fade-in">
                        <label className={`w-full h-64 border-2 border-dashed rounded-3xl flex flex-col items-center justify-center cursor-pointer transition-all group ${importError ? 'border-red-500/50 bg-red-500/10' : 'border-white/20 bg-white/5 hover:bg-white/10 hover:border-white/40'}`} onClick={() => triggerHaptic('selection')}>
                           <div className="w-20 h-20 rounded-full bg-white/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                              {isProcessingImg ? <RefreshCw className="animate-spin text-always-white/70" size={32} /> : <QrCode size={32} className="text-always-white/70" />}
                           </div>
                           <span className="font-bold text-lg mb-1 text-always-white">{isProcessingImg ? '正在解析...' : '点击上传图片'}</span>
                           <span className="text-xs text-always-white/40">支持 CIMBAR 彩色码</span>
                           <input type="file" accept="image/*" onChange={handleCimbarUpload} className="hidden" disabled={isProcessingImg} />
                        </label>
                        {importError && (
                            <div className="mt-4 p-4 bg-red-500/20 border border-red-500/30 rounded-xl text-red-200 text-sm flex items-center gap-2 animate-pulse">
                                <AlertCircle size={16} className="text-red-200" /> {importError}
                            </div>
                        )}
                    </div>
                )}

                {/* ... (Decrypt & Confirm steps) ... */}
                {importStep === 'decrypt' && (
                    <div className="animate-fade-in">
                        <div className="w-16 h-16 bg-amber-500/20 rounded-full flex items-center justify-center text-amber-400 mb-6 mx-auto">
                           <Lock size={32} className="text-always-white"/>
                        </div>
                        <p className="text-center text-always-white/70 mb-6">该配置已被加密，请输入密码解锁</p>
                        
                        <input 
                           type="password"
                           value={decryptPass}
                           onChange={e => setDecryptPass(e.target.value)}
                           className="w-full bg-black/30 border border-white/10 rounded-xl p-4 text-center text-xl text-always-white focus:outline-none focus:border-white/40 transition-colors mb-4"
                           placeholder="输入密码"
                           autoFocus
                        />
                        {importError && <p className="text-red-400 text-xs text-center mb-4">{importError}</p>}
                        
                        <button onClick={handleDecrypt} className="w-full py-4 bg-white text-black rounded-xl font-bold hover:bg-gray-200 transition-colors">
                            解密并验证
                        </button>
                    </div>
                )}

                {importStep === 'confirm' && restoredData && (
                     <div className="animate-fade-in text-center">
                        <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center text-green-400 mb-6 mx-auto">
                           <FileCheck size={40} className="text-always-white"/>
                        </div>
                        <h3 className="text-xl font-bold mb-2 text-always-white">验证通过</h3>
                        <div className="bg-white/5 rounded-xl p-6 mb-6 text-left border border-white/10">
                            {(() => {
                                const profile = restoredData.exportVersion === 2 ? restoredData.active?.profile : restoredData.profile;
                                const orgCount = restoredData.exportVersion === 2 
                                    ? 1 + Object.keys(restoredData.accounts || {}).length 
                                    : 1;

                                if (profile) {
                                    return (
                                        <div className="flex items-center gap-4">
                                            <div className="w-12 h-12 rounded-full bg-white/10 overflow-hidden flex items-center justify-center">
                                                {profile.avatar ? <img src={profile.avatar} className="w-full h-full object-cover"/> : <User size={24} className="text-always-white/50"/>}
                                            </div>
                                            <div>
                                                <div className="font-bold text-always-white">{profile.name}</div>
                                                <div className="text-xs text-always-white/50">{profile.position}</div>
                                                <div className="text-xs text-indigo-400 mt-1 flex items-center gap-1 font-bold">
                                                    <Building2 size={10} />
                                                    已加入 {orgCount} 个组织
                                                </div>
                                            </div>
                                        </div>
                                    );
                                } else {
                                    return <p className="text-always-white/70">包含 {(restoredData.todos?.length || restoredData.active?.todos?.length || 0)} 个任务数据</p>;
                                }
                            })()}
                        </div>

                        <div className="flex items-center justify-center gap-2 text-always-white/40 text-xs mb-8">
                             <HardDrive size={12} className="text-always-white/60"/>
                             <span>所有数据将安全存储于本地设备</span>
                        </div>
                        
                        <button onClick={confirmRestore} className="w-full py-4 bg-green-500 text-white rounded-xl font-bold hover:bg-green-600 shadow-[0_0_20px_rgba(34,197,94,0.4)] transition-colors">
                            确认恢复身份
                        </button>
                     </div>
                )}
              </div>
            )}

            {/* STEP 0: ORGANIZATION TYPE SELECTION */}
            {step === 0 && (
                <div className={`w-full max-w-lg transition-all duration-500 animate-fade-in ${isTransitioning ? 'opacity-0 scale-95 translate-y-4' : 'opacity-100 scale-100 translate-y-0'}`}>
                    <div className="flex items-center gap-2 mb-8">
                       <button onClick={() => goToStep(-1)} className="p-2 bg-white/5 rounded-full hover:bg-white/10 transition-colors text-always-white"><ArrowLeft size={20} className="text-always-white"/></button>
                       <span className="text-xs text-always-white/40 uppercase tracking-widest">Select Organization</span>
                    </div>

                    <div className="text-center mb-10">
                        <div className="w-20 h-20 bg-indigo-500/20 rounded-3xl flex items-center justify-center text-indigo-300 mx-auto mb-6 shadow-lg border border-indigo-500/30">
                            <Building2 size={40} className="text-always-white"/>
                        </div>
                        <h2 className="text-3xl font-bold mb-2 text-always-white">选择您的组织</h2>
                        <p className="text-always-white/50 text-sm">加入欧亚学促会或创建属于您的团队空间</p>
                    </div>

                    <div className="space-y-4">
                        {/* Option 1: Eurasia SGP (Standard) */}
                        <div 
                            onClick={() => { setOrgMode('standard'); triggerHaptic('selection'); }}
                            className={`p-6 rounded-2xl border cursor-pointer transition-all ${orgMode === 'standard' ? 'bg-indigo-500/20 border-indigo-500 shadow-[0_0_20px_rgba(99,102,241,0.2)]' : 'bg-white/5 border-white/10 hover:bg-white/10'}`}
                        >
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center shrink-0">
                                    <Sparkles size={20} className="text-yellow-300"/>
                                </div>
                                <div className="flex-1 text-left">
                                    <div className="font-bold text-always-white text-sm md:text-base">欧亚学促会</div>
                                    <div className="text-xs text-always-white/50 mt-1">西安欧亚学院学生成长促进会</div>
                                </div>
                                {orgMode === 'standard' && <div className="w-6 h-6 bg-indigo-500 rounded-full flex items-center justify-center"><Check size={14} className="text-white"/></div>}
                            </div>
                        </div>

                        {/* Option 2: Custom Org */}
                        <div 
                            onClick={() => { setOrgMode('custom'); setCustomOrgName(''); triggerHaptic('selection'); }}
                            className={`p-6 rounded-2xl border cursor-pointer transition-all ${orgMode === 'custom' ? 'bg-white/10 border-white/40' : 'bg-white/5 border-white/10 hover:bg-white/10'}`}
                        >
                            <div className="flex items-center gap-4 mb-4">
                                <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center shrink-0">
                                    <Plus size={20} className="text-always-white"/>
                                </div>
                                <div className="flex-1 text-left">
                                    <div className="font-bold text-always-white text-sm md:text-base">其他学生组织</div>
                                    <div className="text-xs text-always-white/50 mt-1">手动输入您的组织名称</div>
                                </div>
                                {orgMode === 'custom' && <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center"><Check size={14} className="text-black"/></div>}
                            </div>
                            
                            {orgMode === 'custom' && (
                                <input 
                                    autoFocus
                                    value={customOrgName}
                                    onChange={(e) => setCustomOrgName(e.target.value)}
                                    placeholder="请输入组织全称"
                                    className="w-full bg-black/20 border border-white/20 rounded-xl p-3 text-sm text-always-white focus:outline-none focus:border-white/50 transition-colors animate-fade-in"
                                />
                            )}
                        </div>
                    </div>

                    <div className="flex justify-center mt-10">
                       <button 
                         disabled={orgMode === 'custom' && !customOrgName}
                         onClick={() => {
                             // Always go to College Selection regardless of mode
                             goToStep(1); 
                         }}
                         className="group relative px-8 py-4 bg-white text-black rounded-full font-bold text-lg hover:shadow-[0_0_20px_rgba(255,255,255,0.4)] transition-all active:scale-95 flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                       >
                          <span>下一步</span>
                          <ArrowRight className="group-hover:translate-x-1 transition-transform" />
                       </button>
                    </div>
                </div>
            )}

            {/* STEP 1: COLLEGE SELECTION (Single Page optimized) */}
            {step === 1 && (
                <div className={`w-full max-w-lg transition-all duration-500 animate-fade-in flex flex-col h-full justify-center ${isTransitioning ? 'opacity-0 scale-95 translate-y-4' : 'opacity-100 scale-100 translate-y-0'}`}>
                    <div className="flex items-center gap-2 mb-4 shrink-0">
                       <button onClick={() => goToStep(0)} className="p-2 bg-white/5 rounded-full hover:bg-white/10 transition-colors text-always-white"><ArrowLeft size={20} className="text-always-white"/></button>
                       <span className="text-xs text-always-white/40 uppercase tracking-widest">Select College</span>
                    </div>

                    <div className="text-center mb-6 shrink-0">
                        <div className="w-16 h-16 bg-emerald-500/20 rounded-3xl flex items-center justify-center text-emerald-300 mx-auto mb-4 shadow-lg border border-emerald-500/30">
                            <GraduationCap size={32} className="text-always-white"/>
                        </div>
                        <h2 className="text-2xl font-bold mb-1 text-always-white">选择所属分院</h2>
                    </div>

                    {/* Denser Grid for Single Page Fit */}
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2 overflow-y-auto hide-scrollbar pr-1 pb-2 flex-1 min-h-0">
                        {COLLEGES.map(college => (
                            <button 
                                key={college}
                                onClick={() => { setSelectedCollege(college); triggerHaptic('light'); }}
                                className={`p-3 rounded-xl text-left transition-all text-xs font-bold border flex items-center justify-between ${selectedCollege === college ? 'bg-white text-indigo-900 border-white shadow-lg shadow-white/10' : 'bg-white/5 border-white/10 text-always-white/70 hover:bg-white/10'}`}
                            >
                                <span className="truncate">{college}</span>
                                {selectedCollege === college && <Check size={14} className="shrink-0"/>}
                            </button>
                        ))}
                    </div>

                    <div className="flex justify-center mt-6 shrink-0">
                       <button 
                         onClick={() => goToStep(2)}
                         className="group relative px-8 py-4 bg-white text-black rounded-full font-bold text-lg hover:shadow-[0_0_20px_rgba(255,255,255,0.4)] transition-all active:scale-95 flex items-center gap-2"
                       >
                          <span>确认分院</span>
                          <ArrowRight className="group-hover:translate-x-1 transition-transform" />
                       </button>
                    </div>
                </div>
            )}
            
            {/* STEP 2: ROLE SELECTION (Compact Single Page) */}
            {step === 2 && (
              <div className={`w-full max-w-lg md:max-w-5xl transition-all duration-500 animate-fade-in flex flex-col h-full justify-center ${isTransitioning ? 'opacity-0 scale-95 translate-y-4' : 'opacity-100 scale-100 translate-y-0'}`}>
                <div className="flex items-center justify-between mb-4 shrink-0">
                   <div className="flex items-center gap-2">
                       <button onClick={() => goToStep(1)} className="p-2 bg-white/5 rounded-full hover:bg-white/10 transition-colors text-always-white"><ArrowLeft size={20} className="text-always-white"/></button>
                       <span className="text-xs text-always-white/40 uppercase tracking-widest">Role</span>
                   </div>
                   <div className="flex bg-white/10 p-1 rounded-lg">
                       <button onClick={() => setRoleConfigMode('standard')} className={`px-2 py-1 rounded-md text-[10px] font-bold transition-all ${roleConfigMode === 'standard' ? 'bg-white text-black' : 'text-always-white/50 hover:text-always-white'}`}>标准</button>
                       <button onClick={() => setRoleConfigMode('custom')} className={`px-2 py-1 rounded-md text-[10px] font-bold transition-all ${roleConfigMode === 'custom' ? 'bg-white text-black' : 'text-always-white/50 hover:text-always-white'}`}>自定义</button>
                   </div>
                </div>
                
                <div className="text-center mb-6 shrink-0">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/10 bg-white/5 backdrop-blur-md mb-2">
                        <Sparkles size={12} className="text-yellow-300" />
                        <span className="text-[10px] tracking-widest text-always-white/60 uppercase">System Initialization</span>
                    </div>
                    <h1 className="text-3xl md:text-5xl font-serif font-bold tracking-wide mb-1 text-transparent bg-clip-text bg-gradient-to-b from-white to-white/60 text-always-white">
                        身份共鸣
                    </h1>
                </div>

                {/* Compact List for Mobile, Grid for Desktop */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 md:gap-6 mb-6 w-full flex-1 min-h-0 overflow-y-auto hide-scrollbar">
                    {customRoles.map((pos) => {
                        const isActive = selectedRoleId === pos.id;
                        return (
                            <div key={pos.id} className="relative group">
                                <button
                                    onClick={() => { setSelectedRoleId(pos.id); triggerHaptic('selection'); }}
                                    className={`
                                      w-full relative rounded-2xl border transition-all duration-300 overflow-hidden
                                      p-3 md:p-6
                                      flex flex-row md:flex-col 
                                      items-center md:justify-center 
                                      text-left md:text-center 
                                      gap-4 md:gap-6
                                      h-full
                                      ${isActive 
                                        ? 'bg-white/10 border-white/30 shadow-[0_0_30px_rgba(0,0,0,0.5)] scale-[1.02]' 
                                        : 'bg-white/5 border-white/5 hover:bg-white/10 hover:border-white/20 active:scale-95'
                                      }
                                    `}
                                >
                                    <div className={`
                                       w-10 h-10 md:w-16 md:h-16 rounded-full flex items-center justify-center transition-all duration-500 shrink-0
                                       ${isActive ? 'bg-white text-black scale-110 shadow-lg' : 'bg-white/10 text-white/70 group-hover:bg-white/20'}
                                    `}>
                                       <pos.icon size={isActive ? 24 : 18} className={isActive ? 'text-black' : 'text-always-white'}/>
                                    </div>
                                    <div className="flex-1 w-full min-w-0">
                                       {roleConfigMode === 'custom' ? (
                                           <div className="space-y-1">
                                              <input 
                                                value={pos.en} 
                                                onChange={(e) => setCustomRoles(prev => prev.map(r => r.id === pos.id ? {...r, en: e.target.value.toUpperCase()} : r))}
                                                className="w-full bg-black/20 text-[10px] font-bold tracking-widest text-always-white/70 text-left md:text-center rounded p-1 border border-white/10 focus:border-white/50 outline-none"
                                                placeholder="ENGLISH TITLE"
                                              />
                                              <input 
                                                value={pos.label} 
                                                onChange={(e) => setCustomRoles(prev => prev.map(r => r.id === pos.id ? {...r, label: e.target.value} : r))}
                                                className="w-full bg-black/20 text-lg font-bold text-always-white text-left md:text-center rounded p-1 border border-white/10 focus:border-white/50 outline-none"
                                                placeholder="中文职位"
                                              />
                                           </div>
                                       ) : (
                                           <>
                                              <div className="text-[10px] font-bold tracking-widest opacity-50 mb-0.5 text-always-white">{pos.en}</div>
                                              <div className="text-lg md:text-2xl font-bold mb-0.5 text-always-white">{pos.label}</div>
                                           </>
                                       )}
                                       <div className={`text-[10px] md:text-xs transition-opacity duration-300 mt-0.5 ${isActive ? 'opacity-100 text-always-white/90' : 'opacity-40 text-always-white'}`}>
                                          {pos.desc}
                                       </div>
                                    </div>
                                </button>
                            </div>
                        );
                    })}
                </div>

                <div className="flex justify-center shrink-0">
                   <button 
                     onClick={() => goToStep(3)}
                     className="group relative px-8 py-4 bg-white text-black rounded-full font-bold text-lg hover:shadow-[0_0_20px_rgba(255,255,255,0.4)] transition-all active:scale-95 flex items-center gap-2"
                   >
                      <span>下一步</span>
                      <ArrowRight className="group-hover:translate-x-1 transition-transform" />
                   </button>
                </div>
              </div>
            )}
            
            {/* STEP 3-6: REMAINING REGISTRATION STEPS */}
            {step >= 3 && step <= 6 && (
                <div className={`w-full max-w-md transition-all duration-500 ${isTransitioning ? 'opacity-0 scale-95 translate-y-4' : 'opacity-100 scale-100 translate-y-0'}`}>
                    {step === 3 && (
                        <>
                        <h2 className="text-2xl font-bold mb-6 text-center text-always-white">基本档案</h2>
                        <div className="space-y-6">
                            <div>
                                <label className="block text-xs text-gray-400 mb-2 uppercase tracking-wider">姓名 / Name</label>
                                <input 
                                    type="text" 
                                    value={name}
                                    onChange={e => setName(e.target.value)}
                                    className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-always-white focus:outline-none focus:border-white/40 transition-colors"
                                    placeholder="请输入您的姓名"
                                />
                            </div>
                            
                            {/* Department Selection */}
                            <div>
                                <div className="flex justify-between items-center mb-2">
                                    <label className="block text-xs text-gray-400 uppercase tracking-wider">部门 / Department</label>
                                    
                                    {/* FIX: Only show standard/custom toggle if in Standard Org Mode */}
                                    {orgMode === 'standard' && (
                                        <div className="flex bg-white/10 p-0.5 rounded-lg">
                                           <button onClick={() => setDeptConfigMode('standard')} className={`px-2 py-1 rounded-md text-[10px] font-bold transition-all ${deptConfigMode === 'standard' ? 'bg-white text-black' : 'text-always-white/50 hover:text-always-white'}`}>标准架构</button>
                                           <button onClick={() => setDeptConfigMode('custom')} className={`px-2 py-1 rounded-md text-[10px] font-bold transition-all ${deptConfigMode === 'custom' ? 'bg-white text-black' : 'text-always-white/50 hover:text-always-white'}`}>自定义</button>
                                        </div>
                                    )}
                                </div>
                                
                                <div className="space-y-2 max-h-[300px] overflow-y-auto custom-scrollbar">
                                    {deptConfigMode === 'standard' ? (
                                        departments.map(dept => (
                                        <div 
                                            key={dept.id}
                                            onClick={() => { setSelectedDeptId(dept.id); triggerHaptic('selection'); }}
                                            className={`p-3 rounded-lg border cursor-pointer flex items-center justify-between transition-all ${selectedDeptId === dept.id ? 'bg-white/10 border-white/40' : 'bg-transparent border-white/10 hover:bg-white/5'}`}
                                        >
                                            <span className="text-sm text-always-white">{dept.name}</span>
                                            {selectedDeptId === dept.id && <Check size={16} className="text-green-400"/>}
                                        </div>
                                        ))
                                    ) : (
                                        <div className="space-y-3">
                                            {customDeptsList.map((deptName, idx) => (
                                                <div key={idx} className="flex items-center gap-2 animate-fade-in">
                                                    <div className="flex-1 p-3 bg-white/10 rounded-lg border border-white/20 text-sm text-always-white flex justify-between items-center">
                                                        <span>{deptName}</span>
                                                    </div>
                                                    <button onClick={() => handleRemoveCustomDept(idx)} className="p-2 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/40"><Trash2 size={16}/></button>
                                                </div>
                                            ))}
                                            <div className="flex gap-2 pt-2">
                                                <input 
                                                    value={newDeptInput}
                                                    onChange={e => setNewDeptInput(e.target.value)}
                                                    placeholder="输入部门名称"
                                                    className="flex-1 bg-black/20 border border-white/10 rounded-lg p-3 text-sm text-always-white focus:outline-none focus:border-white/40"
                                                    onKeyDown={(e) => e.key === 'Enter' && handleAddCustomDept()}
                                                />
                                                <button onClick={handleAddCustomDept} className="px-4 bg-white/10 hover:bg-white/20 border border-white/10 rounded-lg text-always-white"><Plus size={20}/></button>
                                            </div>
                                            {customDeptsList.length === 0 && <p className="text-xs text-always-white/40 text-center py-2">添加自定义部门以构建架构</p>}
                                        </div>
                                    )}
                                </div>
                            </div>

                            <div className="pt-4 flex justify-between">
                                <button onClick={() => goToStep(2)} className="text-always-white/50 hover:text-always-white transition-colors">上一步</button>
                                <button 
                                    disabled={!name || (deptConfigMode === 'standard' && !selectedDeptId) || (deptConfigMode === 'custom' && customDeptsList.length === 0)}
                                    onClick={() => goToStep(4)}
                                    className="px-6 py-2 bg-white text-black rounded-full font-bold disabled:opacity-50 disabled:cursor-not-allowed hover:bg-white/90 transition-colors"
                                >
                                    下一步
                                </button>
                            </div>
                        </div>
                        </>
                    )}
                    {/* ... (Steps 4, 5, 6 identical to original) ... */}
                    {step === 4 && (
                        <>
                        <h2 className="text-2xl font-bold mb-2 text-center text-always-white">破壳日</h2>
                        <p className="text-always-white/50 text-center text-sm mb-8">我们将为您准备每年的生日惊喜</p>
                        <div className="bg-white/5 border border-white/10 rounded-2xl p-6 mb-8">
                            <div className="flex items-center gap-4 mb-4">
                                <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center"><Calendar size={20} className="text-always-white"/></div>
                                <div className="text-sm text-always-white/70">请输入生日 (月-日)</div>
                            </div>
                            <input 
                                type="text" 
                                value={birthday}
                                onChange={e => setBirthday(e.target.value)}
                                className="w-full bg-black/20 border border-white/10 rounded-xl p-4 text-center text-2xl tracking-widest focus:outline-none focus:border-white/40 transition-colors placeholder:text-white/10 text-always-white"
                                placeholder="MM-DD"
                                maxLength={5}
                            />
                            <p className="text-xs text-center text-always-white/30 mt-2">例如: 05-20</p>
                        </div>
                        <div className="flex justify-between">
                            <button onClick={() => goToStep(3)} className="text-always-white/50 hover:text-always-white transition-colors">上一步</button>
                            <button 
                                disabled={!birthday || birthday.length < 3}
                                onClick={() => goToStep(5)}
                                className="px-6 py-2 bg-white text-black rounded-full font-bold disabled:opacity-50 disabled:cursor-not-allowed hover:bg-white/90 transition-colors"
                            >
                                下一步
                            </button>
                        </div>
                        </>
                    )}
                    {step === 5 && (
                        <>
                        <h2 className="text-2xl font-bold mb-8 text-center text-always-white">上传形象照</h2>
                        <div className="flex flex-col items-center mb-10">
                            <div className="relative group">
                                <div className={`w-32 h-32 rounded-full flex items-center justify-center overflow-hidden border-4 transition-colors ${avatar ? 'border-white' : 'border-white/20 bg-white/5'}`}>
                                    {avatar ? (
                                        <img src={avatar} alt="Avatar" className="w-full h-full object-cover" />
                                    ) : (
                                        <User size={48} className="text-always-white/20" />
                                    )}
                                </div>
                                <label className="absolute bottom-0 right-0 w-10 h-10 bg-white text-black rounded-full flex items-center justify-center cursor-pointer hover:scale-110 transition-transform shadow-lg">
                                    <Camera size={20} />
                                    <input type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
                                </label>
                            </div>
                            <p className="text-always-white/40 text-xs mt-4">点击相机图标上传</p>
                        </div>
                        <div className="flex justify-between items-center">
                            <button onClick={() => goToStep(4)} className="text-always-white/50 hover:text-always-white transition-colors">上一步</button>
                            <button 
                                onClick={handleFinishRegister}
                                className="px-8 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full font-bold shadow-[0_0_20px_rgba(59,130,246,0.5)] hover:shadow-[0_0_30px_rgba(59,130,246,0.7)] transition-all active:scale-95 flex items-center gap-2 text-white"
                            >
                                <Fingerprint size={20}/>
                                <span>确认身份</span>
                            </button>
                        </div>
                        </>
                    )}
                    {step === 6 && (
                        <div className="w-full max-w-md text-center animate-fade-in text-always-white">
                            <div className="relative w-24 h-24 mx-auto mb-8">
                                <div className="absolute inset-0 border-4 border-white/10 rounded-full"></div>
                                <div className="absolute inset-0 border-t-4 border-white rounded-full animate-spin"></div>
                                <ShieldCheck size={40} className="absolute inset-0 m-auto text-always-white/80" />
                            </div>
                            <h2 className="text-2xl font-bold mb-4 text-always-white">身份录入中</h2>
                            <div className="h-8 relative overflow-hidden">
                                {LOADING_MESSAGES.map((msg, i) => (
                                <div 
                                    key={i}
                                    className={`absolute inset-0 transition-all duration-500 flex items-center justify-center text-sm text-always-white/60
                                    ${i === loadingIndex ? 'opacity-100 translate-y-0' : i < loadingIndex ? 'opacity-0 -translate-y-4' : 'opacity-0 translate-y-4'}
                                    `}
                                >
                                    {msg}
                                </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            )}
            
         </div>
      </div>
    </div>
  );
};

export default OnboardingView;
