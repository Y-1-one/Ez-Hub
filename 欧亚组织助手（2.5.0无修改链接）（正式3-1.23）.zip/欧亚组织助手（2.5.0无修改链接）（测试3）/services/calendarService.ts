
import { Todo } from '../types';

/**
 * Pushes event to native mobile calendar via ICS file sharing.
 * Uses Web Share API (Level 1) or File Download (Level 2).
 */
export const addToSystemCalendar = async (todo: Todo) => {
  const { title, date, time } = todo;
  
  // 1. Robust Date Parsing
  // Parse date and time (YYYY-MM-DD HH:mm) treating input as Local Time
  const [year, month, day] = date.split('-').map(Number);
  const [hours, minutes] = time.split(':').map(Number);
  
  const startDate = new Date(year, month - 1, day, hours, minutes);
  const endDate = new Date(startDate.getTime() + 60 * 60 * 1000); // Default 1 hour duration

  // Helper to format date for ICS (UTC format with Z)
  const formatICSDate = (d: Date) => {
    return d.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
  };

  const now = formatICSDate(new Date());
  const startStr = formatICSDate(startDate);
  const endStr = formatICSDate(endDate);

  // 2. Construct ICS Content (RFC 5545)
  const cleanTitle = title.replace(/[\\;,]/g, '');
  const cleanDesc = (todo.description || '来自欧亚学生成长助手的提醒').replace(/[\\;,]/g, '');

  const icsContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Eurasia Student Growth//App//CN
CALSCALE:GREGORIAN
METHOD:PUBLISH
BEGIN:VEVENT
UID:${todo.id}-${Date.now()}@eurasia.app
DTSTAMP:${now}
DTSTART:${startStr}
DTEND:${endStr}
SUMMARY:${cleanTitle}
DESCRIPTION:${cleanDesc}
STATUS:CONFIRMED
BEGIN:VALARM
TRIGGER:-PT10M
DESCRIPTION:Reminder
ACTION:DISPLAY
END:VALARM
END:VEVENT
END:VCALENDAR`;

  const fileName = `event_${Date.now()}.ics`;
  const file = new File([icsContent], fileName, { type: 'text/calendar' });

  // 3. Synchronization Logic
  
  // Strategy A: Web Share API (Best for Mobile Native)
  if (
    navigator.share && 
    navigator.canShare && 
    navigator.canShare({ files: [file] }) && 
    /mobile|android|iphone|ipad/i.test(navigator.userAgent)
  ) {
    try {
      await navigator.share({
        files: [file],
        title: '添加到日历',
        text: title
      });
      return true;
    } catch (error: any) {
      if (error.name !== 'AbortError') {
         console.warn('Share failed, falling back to download:', error);
         triggerDownload(file);
      }
      return true;
    }
  }

  // Strategy B: Direct URL Download
  triggerDownload(file);
  return true;
};

const triggerDownload = (file: File) => {
  const url = window.URL.createObjectURL(file);
  const link = document.createElement('a');
  link.href = url;
  link.download = file.name;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => window.URL.revokeObjectURL(url), 1000);
};

/**
 * Attempts to open the native calendar app.
 * Note: This relies on URL schemes and may not work on all devices/browsers
 * due to security restrictions (sandboxing).
 */
export const openNativeCalendar = () => {
  const u = navigator.userAgent;
  const isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);
  
  if (isiOS) {
    // iOS standard scheme
    window.location.href = 'calshow://';
  } else {
    // Android is fragmented. We try a common intent via hidden iframe or location.
    // content://com.android.calendar/time/ is a common content provider path.
    try {
      window.location.href = 'content://com.android.calendar/time/';
    } catch(e) {
      alert('无法自动唤起日历应用，请手动打开。');
    }
  }
};
