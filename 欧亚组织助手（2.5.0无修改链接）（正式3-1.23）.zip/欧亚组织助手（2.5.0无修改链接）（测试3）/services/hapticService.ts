
import { getStoredSettings } from './storageService';

type HapticType = 'light' | 'medium' | 'heavy' | 'selection' | 'success' | 'warning' | 'error' | 'tick';

export const triggerHaptic = (type: HapticType) => {
  // Check if browser supports vibration
  if (!navigator.vibrate) return;

  // Get current intensity setting (0-3)
  const intensity = getStoredSettings().hapticIntensity;

  if (intensity === 0) return; // Haptic disabled

  // Multiplier for duration based on intensity
  // Intensity 1: 0.7x, 2: 1x, 3: 1.5x
  const multiplier = intensity === 1 ? 0.6 : (intensity === 3 ? 1.4 : 1.0);

  let pattern: number | number[] = 0;

  switch (type) {
    case 'tick':
      // Extremely short for scroll/ticks
      pattern = 5 * multiplier;
      break;
    case 'selection':
      // Standard UI tap
      pattern = 10 * multiplier;
      break;
    case 'light':
      pattern = 15 * multiplier;
      break;
    case 'medium':
      pattern = 25 * multiplier;
      break;
    case 'heavy':
      pattern = 40 * multiplier;
      break;
    case 'success':
      // Two short distinct taps
      pattern = [10 * multiplier, 50, 10 * multiplier];
      break;
    case 'warning':
      pattern = [30 * multiplier, 50, 30 * multiplier];
      break;
    case 'error':
      // Three rapid taps
      pattern = [50 * multiplier, 50, 50 * multiplier, 50, 50 * multiplier];
      break;
    default:
      pattern = 15 * multiplier;
  }

  // Safety check to ensure pattern is valid
  try {
     navigator.vibrate(pattern);
  } catch (e) {
     // Ignore errors (some browsers restrict vibration without user interaction context)
  }
};
