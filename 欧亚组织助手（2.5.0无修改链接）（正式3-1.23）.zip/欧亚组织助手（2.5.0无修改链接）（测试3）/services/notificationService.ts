
export const requestNotificationPermission = async (): Promise<boolean> => {
  // 1. Check browser support (Silent check)
  if (!('Notification' in window)) {
    console.warn('Browser does not support Notification API');
    return false;
  }

  // 2. Check current state
  if (Notification.permission === 'granted') {
    return true;
  }

  if (Notification.permission === 'denied') {
    // Silent return, UI should handle the guidance
    console.log('Notification permission was previously denied');
    return false;
  }

  // 3. Request permission (Must be triggered by user gesture)
  try {
    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
      // Send a test notification immediately to confirm
      try {
        if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
           navigator.serviceWorker.controller.postMessage({
             type: 'TRIGGER_NOTIFICATION_IMMEDIATE',
             title: '提醒已开启',
             body: '您将准时收到待办事项提醒'
           });
        } else {
           new Notification('提醒已开启', { body: '您将准时收到待办事项提醒' });
        }
      } catch (e) {
        console.warn('Immediate notification failed, but permission granted', e);
      }
      return true;
    } else {
      return false;
    }
  } catch (e) {
    console.error('Permission request error:', e);
    return false;
  }
};

export const sendNotification = (title: string, body: string) => {
  if (!('Notification' in window)) return;
  
  if (Notification.permission === 'granted') {
    try {
      // Try Service Worker first for better mobile support
      if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
         navigator.serviceWorker.controller.postMessage({
           type: 'TRIGGER_NOTIFICATION_IMMEDIATE',
           title,
           body
         });
      } else {
        // Fallback to classic API
        const notification = new Notification(title, {
          body,
          icon: '/vite.svg',
          requireInteraction: true
        });
        setTimeout(() => notification.close(), 5000);
      }
    } catch (e) {
      console.error('Notification error', e);
    }
  }
};
