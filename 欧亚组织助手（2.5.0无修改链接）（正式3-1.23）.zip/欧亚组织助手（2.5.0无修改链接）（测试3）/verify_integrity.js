// 这是一个可以在浏览器控制台运行的脚本，用于验证数据完整性
// 使用方法：复制以下代码，在浏览器按 F12 打开控制台 (Console)，粘贴并回车运行。

(function() {
    console.group("🔍 欧亚助手数据完整性自检");
    
    // 1. 检查当前活跃用户
    const profileStr = localStorage.getItem('eurasia_sg_user_profile');
    const settingsStr = localStorage.getItem('eurasia_sg_settings');
    
    if (profileStr) {
        try {
            const p = JSON.parse(profileStr);
            console.log(`✅ 当前活跃用户: ${p.name}`);
            console.log(`   - 职位: ${p.position}`);
            console.log(`   - 组织: ${p.organization}`);
            console.log(`   - ID: ${p.userId}`);
        } catch (e) {
            console.error("❌ 用户档案 JSON 格式错误");
        }
    } else {
        console.warn("⚠️ 当前无活跃用户 (处于未登录/Onboarding 状态)");
    }

    // 2. 检查备份账号
    const accounts = [];
    let brokenAccounts = 0;
    for(let i=0; i<localStorage.length; i++) {
        const key = localStorage.key(i);
        if(key && key.startsWith('eurasia_account_')) {
            try {
                const data = JSON.parse(localStorage.getItem(key));
                if (data.profile && data.profile.name) {
                    accounts.push({
                        key: key,
                        name: data.profile.name,
                        org: data.profile.organization
                    });
                } else {
                    brokenAccounts++;
                }
            } catch (e) {
                brokenAccounts++;
            }
        }
    }
    
    console.log(`📦 已备份账号数量: ${accounts.length}`);
    if (accounts.length > 0) {
        console.table(accounts);
    }
    
    if (brokenAccounts > 0) {
        console.error(`❌ 发现 ${brokenAccounts} 个损坏的备份槽位`);
    } else {
        console.log("✅ 所有备份槽位数据格式正常");
    }

    // 3. 检查全局配置
    if (settingsStr) {
        console.log("✅ 全局设置已加载");
    } else {
        console.warn("⚠️ 使用默认全局设置");
    }

    console.groupEnd();
    return "自检完成";
})();
