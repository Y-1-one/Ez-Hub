I have identified the root causes and formulated a plan to address all three requests:

### 1. Mobile Dark Mode & System Override
- **Issue**: The status bar color doesn't adapt, and background persistence is flaky.
- **Fix**: 
    - In `App.tsx`, I will implement a robust `useEffect` that explicitly updates the `<meta name="theme-color">` tag whenever the theme changes.
    - Set color to `#0f172a` (Slate 900) for Dark Mode and `#f8fafc` (Slate 50) for Light Mode to match the app background.
    - This ensures the browser UI (status/nav bars) matches the app theme.

### 2. Admin Console - Global Config Improvements
- **Issue**: Users cannot configure specific URLs for "Feature Suggestion" and "Bug Feedback" cards because the URL input was hidden in the UI.
- **Fix**:
    - In `SettingsView.tsx`, I will remove the restriction that only shows the URL input for `todoCard`s. All cards will now have an editable URL field.
    - In `FeedbackView.tsx`, I will update the click handlers to prioritize the specific card's URL (e.g., `feedbackCard1.url`) and fall back to the global `feedbackUrl` only if the specific URL is empty.

### 3. Admin Console - Department Management
- **Issue**: Admins currently lack a way to add, edit, or delete departments from the workbench.
- **Fix**:
    - In `SettingsView.tsx`, I will add a new "Department Management" section in the Admin Console.
    - Implement a new Modal for managing departments with the following features:
        - **List View**: Show all active departments.
        - **Add**: Create new departments with auto-generated IDs.
        - **Edit**: Modify department names and descriptions.
        - **Delete**: Remove departments (with confirmation).
    - Ensure these changes are persisted via `storageService`.

I will now execute these changes sequentially.