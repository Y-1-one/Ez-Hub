I have analyzed the current codebase and designed a plan to refactor the Dark Mode implementation to support "System", "Light", and "Dark" modes as requested.

### 1. Update Type Definitions (`src/types.ts`)
- Modify `AppSettings` interface:
  - Remove `darkMode: boolean`.
  - Add `themeMode: 'system' | 'light' | 'dark'`.

### 2. Update Storage Service (`src/services/storageService.ts`)
- Update `DEFAULT_SETTINGS` to default `themeMode` to `'system'`.
- Update `getStoredSettings()` to handle migration from legacy data:
  - If `darkMode: true` exists, map to `themeMode: 'dark'`.
  - If `darkMode: false` exists, map to `themeMode: 'light'`.

### 3. Update Main Application Logic (`src/App.tsx`)
- Replace `globalDarkMode` boolean state with `themeMode` state.
- Implement a robust `useEffect` to handle theme application:
  - **Dark**: Force `.dark` class.
  - **Light**: Remove `.dark` class.
  - **System**: Listen to `window.matchMedia('(prefers-color-scheme: dark)')` and update dynamically when system settings change.

### 4. Update Settings Interface (`src/components/SettingsView.tsx`)
- Replace the current "Dark Mode" toggle switch with a 3-option selector (Segmented Control).
- Options: 
  - 🌓 跟随系统 (System)
  - ☀️ 浅色模式 (Light)
  - 🌙 深色模式 (Dark)
- Update props to pass `onThemeChange` instead of `onThemeToggle`.

This will ensure a consistent experience across mobile and desktop, resolving the reported bugs and adhering to the new requirement.