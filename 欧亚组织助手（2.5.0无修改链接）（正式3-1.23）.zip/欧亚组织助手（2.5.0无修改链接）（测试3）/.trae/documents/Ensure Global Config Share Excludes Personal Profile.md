I have analyzed the request and the existing codebase. The user wants to ensure that when sharing "Global Config" (Admin Console -> Share), it only includes organization-level settings (Global Config, Departments) and excludes the administrator's personal profile (User Profile). On the receiving end, it should overwrite the organization settings but preserve the receiver's personal account.

**Current Implementation Analysis:**

1.  **Export Logic (`getExportData` in `storageService.ts`)**:
    *   Currently, `getExportData` accepts a scope: `'full' | 'profile_only' | 'global_only'`.
    *   `'global_only'` already exists and filters out `profile` and `todos`. It returns `departments`, `globalConfig`, and `settings`.
    *   The export payload structure is `{ exportVersion: 2, timestamp: ..., active: {...filteredData}, accounts: {...} }`.

2.  **Import Logic (`importAllData` in `storageService.ts`)**:
    *   Currently, `importAllData` indiscriminately imports what is present in the payload.
    *   If `data.profile` exists, it overwrites `USER_PROFILE_KEY`.
    *   If `data.profile` is MISSING (which is the case for `global_only`), it does *not* touch `USER_PROFILE_KEY` (Lines 524-529 check `if (data.profile)`).
    *   **However**, `importAllData` does NOT explicitly handle the case where we might want to *ensure* the profile isn't touched even if the payload accidentally contains it (though `global_only` shouldn't).
    *   **Crucially**, the `handleImportJSON` and `handleCimbarUpload` in `SettingsView.tsx` simply call `importAllData(finalData)`.

3.  **The "Share" UI (`SettingsView.tsx`)**:
    *   I need to ensure the "Admin Console -> Share" button triggers `getExportData('global_only')`.
    *   I need to verify where `exportScope` state is set in `SettingsView.tsx`.

**Proposed Plan:**

1.  **Verify/Fix Export Trigger**:
    *   In `SettingsView.tsx`, locate the "Export Global Config" (or similar) button in the Admin Console.
    *   Ensure it sets `exportScope` to `'global_only'` before opening the export modal.

2.  **Enhance Import Safety**:
    *   Modify `importAllData` in `storageService.ts` to be more explicit about merging.
    *   Specifically, when importing `global_only` data (which we can infer or pass as a flag), we should double-check that we don't accidentally nuke the user's profile if the backup file was malformed or if the user selected the wrong file type (though the user asked for "Share Global Config" flow).
    *   Actually, `importAllData` implementation is already safe: `if (data.profile) { ... }`. If the export was `global_only`, `data.profile` is undefined, so it won't be overwritten.
    *   The user's requirement "Receiver can only sync the whole app organization settings but keep original user account" is satisfied by `global_only` export + current import logic.

3.  **Refine UI Text**:
    *   Update the text in the export/import modals to clearly state "Sharing Organization Config (excludes personal data)".

**Actionable Steps:**
1.  Check `SettingsView.tsx` to see what `setExportScope` is called with when clicking the share button in Admin Console.
2.  If it's not strictly `global_only`, force it.
3.  Add a confirmation/info text in the UI to reassure the admin.

I will verify the `SettingsView.tsx` export button logic now.