I have analyzed the current codebase and designed a plan to optimize for 120Hz refresh rates, reduce power consumption, and improve perceived performance with loading states.

### 1. Optimize `OnboardingView.tsx` (Fluidity & Power)
*   **Issue**: The `StarParticle` animation loop runs continuously using `requestAnimationFrame`, consuming CPU/GPU even when the tab is hidden or the component is unmounted. The particle update logic creates new objects in some cases.
*   **Fix**:
    *   Implement `visibilitychange` listener to pause the animation loop when the tab is inactive.
    *   Optimize the loop to avoid object allocation (reusing objects where possible) to reduce GC pressure.
    *   Ensure the loop fully stops when the component unmounts.

### 2. Optimize `App.tsx` (Global Smoothness & Loading)
*   **Issue**: Transitions rely on standard CSS. `LiquidBackground` is heavy.
*   **Fix**:
    *   Ensure `LiquidBackground` uses `will-change: transform` (already partially done, but verify).
    *   The `ViewSkeleton` is good, but `SettingsView`'s async operations (image compression, export) lack specific inline loading states.
    *   Add `scroll-behavior: smooth` to global styles if not present.

### 3. Add Loading States in `SettingsView.tsx`
*   **Issue**: Image upload and export generation can be slow but currently block UI without clear "processing" feedback beyond a simple alert or toast.
*   **Fix**:
    *   Add a spinner or "Generating..." state to the "Export" and "Avatar Upload" buttons.
    *   Use `useTransition` for tab switching if it feels laggy (though React 18 automatic batching handles most).

### 4. Global CSS/Tailwind Optimizations
*   **Fix**: Ensure `transform-gpu` is used on large animating layers to force hardware acceleration.

I will focus on `OnboardingView.tsx` first as it has the most intensive animation loop. Then I will refine `SettingsView.tsx`.

**Actionable Plan:**
1.  **Refactor `OnboardingView.tsx`**: Add `usePageVisibility` hook (or local logic) to pause the canvas loop. Optimize the particle class.
2.  **Update `SettingsView.tsx`**: Add visual loading indicators for:
    *   Avatar compression/upload.
    *   CIMBAR generation.
    *   File import/decryption.
3.  **Verify `App.tsx`**: Ensure `LiquidBackground` respects the `paused` prop effectively (it does, but I'll double check the CSS animation play state).

This covers "Global fluidity", "Loading process animation", and "Power optimization".