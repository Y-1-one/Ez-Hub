I will fix the clipboard read issues and add a manual fallback mechanism for text import in both `SettingsView.tsx` and `WorkbenchView.tsx`.

## Implementation Plan

### 1. Refactor Import Logic in `SettingsView.tsx`
- **Extract Logic**: I will move the data processing logic from `handlePasteImport` into a reusable function `processImportText(text: string)`.
- **Enhance `handlePasteImport`**:
    - It will first attempt to read from the clipboard.
    - If successful, it calls `processImportText`.
    - If it fails (permission denied or API unavailable), it will automatically trigger the new **Manual Input Modal**.
- **Add Manual Input Modal**:
    - A new modal state `'manual_import'` will be added.
    - It will feature a large textarea for users to manually paste the text.
    - A "Confirm" button will pass the text to `processImportText`.

### 2. Refactor Import Logic in `WorkbenchView.tsx`
- **Enhance `handlePasteImport`**:
    - Similar to Settings, it will try to read the clipboard.
    - On failure, it will trigger a new **Manual Input Modal**.
- **Add Manual Input Modal**:
    - A new modal state `'manual_scan'` will be added.
    - Users can paste the department configuration text manually.
    - A "Confirm" button will call the existing `processScannedData` function.

### 3. User Experience Improvements
- The manual input modal will auto-focus the textarea.
- Clear error messages will guide the user ("Automatic paste failed, please paste manually").

This ensures that even if the browser restricts clipboard access (common in non-secure contexts or strict privacy settings), the user can always successfully import their data.