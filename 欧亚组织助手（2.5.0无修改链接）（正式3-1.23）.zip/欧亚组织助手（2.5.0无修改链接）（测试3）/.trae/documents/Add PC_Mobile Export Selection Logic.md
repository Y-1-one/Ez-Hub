I will modify the share and download interfaces in `SettingsView.tsx` and `WorkbenchView.tsx` to add the requested "PC vs Mobile" selection logic, and I will also ensure the "Inheritance/Recovery" interface is properly covered.

## Implementation Plan

### 1. Intercept Download Actions with Selection Modal
I will modify the following functions to stop the immediate download and instead open a **Selection Modal**:
- **Global Backup**: `handleDownloadCimbar` & `handleExportJSON` (Settings)
- **Inheritance / Authority Token**: `handleDownloadAuthQr` (Settings)
- **Department Share**: `handleSaveQrImage` (Workbench)

### 2. New "Export Mode Selection" Modal
When any of the above actions are triggered, a modal will appear with two options:

#### A. 💻 PC Export (电脑端导出)
- Preserves the original behavior.
- Allows downloading the **Image (PNG)** or **File (JSON)**.
- **Enhanced**: Includes the option to view the mobile text payload as well (as requested: "all methods let him choose").

#### B. 📱 Mobile Export (移动端导出)
- Designed for environments where file/image transfer is restricted.
- Displays the **Data Payload** as a copyable text string.
- **Security**: Uses the existing encryption logic (AES/HMAC) so the text is secure if the user enabled encryption.

### 3. Fix Missing Inheritance/Recovery Interface
I noticed that while the system generates a **Recovery Code** (`generatedFailureCode`) when inheritance fails, it currently **does not display it** to the user.
- I will add a UI to display this generated code.
- I will apply the same "Copy Text" pattern to this interface so users can easily copy the recovery code to send back to the admin.

### 4. Add "Import from Text" Capability
To ensure the "Mobile Export" text can be used, I will also add a **"Paste Text / Clipboard"** button to the corresponding import interfaces:
- **Backup Restore**: Add "Paste Text" to `import_cimbar` / `import_file` modals.
- **Department Scan**: Add "Paste Configuration" to the Scan modal in `WorkbenchView`.
- **Identity Restore**: Ensure the existing input box accepts the copied text format.

### Code Changes
- **`components/SettingsView.tsx`**: Add `pendingExportData` state, Selector Modal, and Recovery Code display.
- **`components/WorkbenchView.tsx`**: Add `qrPayload` state and Selector Modal.

This ensures a complete loop: users can export text on one device and paste it into another to restore data, transfer permissions, or recover lost identities.