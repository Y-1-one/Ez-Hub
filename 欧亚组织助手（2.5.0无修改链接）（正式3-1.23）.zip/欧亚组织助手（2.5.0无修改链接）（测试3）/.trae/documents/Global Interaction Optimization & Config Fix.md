I will optimize the global interaction and fix the incomplete global resource configuration in `SettingsView.tsx`.

## Implementation Plan

### 1. Global Interaction Optimization
- **Close Button & Gestures**: I will add a standardized "Close" button (X icon) to the top-right of all modals in `SettingsView.tsx` and `WorkbenchView.tsx`.
- **Animation Refinement**: I will ensure all modals have consistent `animate-fade-in` or `animate-slide-up` classes.
- **Haptic Feedback**: I will review all clickable elements in modals to ensure `triggerHaptic` is called consistently.

### 2. Fix Global Resource Configuration
- **Expand Config Fields**: I will update the `GlobalConfig` interface and the editor UI in `SettingsView.tsx` to include all fields used in `FeedbackView.tsx` (e.g., `feedbackCard1`, `feedbackCard2`, `githubCard`).
- **Fix Sync Issue**: The user reported that "in-app config changed but global settings name didn't". This suggests the state in `SettingsView` might be stale or not reflecting the latest `GlobalConfig` when opening the edit modal. I will ensure `setEditGlobalConfig(globalConfig)` is called whenever the modal opens to load the latest values.

### 3. Code Changes
- **`components/SettingsView.tsx`**:
    - Add "Close" buttons to all `ModalPortal` contents.
    - Update `handleSaveGlobalConfig` and the "Global Resource Config" modal to support editing all Feedback cards fully.
    - Ensure `editGlobalConfig` is synced with `globalConfig` on modal open.
- **`components/WorkbenchView.tsx`**:
    - Add "Close" buttons to all `ModalPortal` contents.
    - Standardize modal animations.

This ensures a smoother, more polished user experience and gives admins full control over the Feedback view content.