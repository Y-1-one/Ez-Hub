
export interface Todo {
  id: string;
  title: string;
  description?: string;
  date: string; // ISO Date string YYYY-MM-DD
  time: string; // HH:mm
  completed: boolean;
  tags: string[];
  notified?: boolean; 
  _sw_notified?: boolean;
}

export interface LinkCard {
  id: string;
  title: string;
  description: string;
  url: string;
  iconName: string; 
  isPinned?: boolean;
  category?: string;
}

export interface Announcement {
  id: string;
  content: string;
  isPinned: boolean;
  date: string;
  publisherName?: string;
  publisherPosition?: string;
}

export interface Department {
  id: string;
  name: string;
  description: string;
  isTopLevel?: boolean;
  cards: LinkCard[];
  announcements: Announcement[];
}

export type UserIdentity = 'user' | 'temp_admin' | 'long_term_admin' | 'permanent_admin';

export interface UserProfile {
  name: string;
  departmentId: string;
  position: string;
  avatar: string;
  birthday?: string;
  college?: string; // Added college field
  organization?: string;
  registerDate?: string;
  identity?: UserIdentity;
  userId?: string;
}

export interface CardConfig {
  title?: string;
  subtitle?: string;
  url?: string;
  iconName?: string;
}

export interface GlobalConfig {
  feedbackUrl: string;
  githubUrl: string;
  contactPhone: string;
  contactQrCode: string;
  todoCard1: CardConfig;
  todoCard2: CardConfig;
  feedbackCard1: CardConfig;
  feedbackCard2: CardConfig;
  githubCard: CardConfig;
  calendarGuideHtml?: string;
}

export interface WebDavConfig {
  enabled: boolean;
  url: string;
  username?: string;
  password?: string;
}

export interface AppSettings {
  enableNotifications: boolean;
  themeMode: 'system' | 'light' | 'dark';
  hapticIntensity: number;
  webDav: WebDavConfig;
}

export type ViewState = 'todo' | 'workbench' | 'feedback' | 'settings';
