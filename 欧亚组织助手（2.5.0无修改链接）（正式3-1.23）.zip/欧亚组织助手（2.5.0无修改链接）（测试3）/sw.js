// Service Worker for Background Notifications
const CHECK_INTERVAL = 15000; // Check every 15 seconds

let todos = [];

self.addEventListener('install', (event) => {
  self.skipWaiting(); // Force activation
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

// Listen for updates from the main app
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'UPDATE_TODOS') {
    todos = event.data.payload;
    console.log('[SW] Updated todos list:', todos.length);
  }
});

// Notification click handler - Focus or open the app window
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      // Try to find an existing window to focus
      for (const client of clientList) {
        if (client.url && 'focus' in client) {
          return client.focus();
        }
      }
      // If no window is open, open a new one
      if (clients.openWindow) {
        return clients.openWindow('/');
      }
    })
  );
});

// The heartbeat loop to check for due tasks
setInterval(() => {
  if (!todos.length) return;

  const now = new Date();
  // Format current time to match YYYY-MM-DD HH:mm
  // Note: We need local time matching the user's input string
  const pad = (n) => n.toString().padStart(2, '0');
  const currentDateStr = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
  const currentTimeStr = `${pad(now.getHours())}:${pad(now.getMinutes())}`;

  todos.forEach(todo => {
    // Check if task matches current date/time and hasn't been notified yet (in this session context)
    // Note: The main app filters out 'completed' and 'notified' tasks before sending to us,
    // but we double check to be safe.
    if (!todo.completed && !todo.notified && todo.date === currentDateStr && todo.time === currentTimeStr) {
      
      // Check if we already triggered this specifically in this SW instance to avoid double fire in same minute
      if (!todo._sw_notified) {
        showNativeNotification(todo);
        todo._sw_notified = true; // Mark locally in SW

        // Tell main app to update storage
        self.clients.matchAll().then(clients => {
          clients.forEach(client => client.postMessage({
            type: 'NOTIFICATION_SENT',
            todoId: todo.id
          }));
        });
      }
    }
  });
}, CHECK_INTERVAL);

function showNativeNotification(todo) {
  self.registration.showNotification('任务提醒', {
    body: `时间到了：${todo.title}`,
    icon: '/vite.svg', // Fallback icon
    badge: '/vite.svg',
    vibrate: [200, 100, 200], // Vibration pattern
    tag: todo.id, // Prevent duplicate notifications for same ID
    renotify: true,
    requireInteraction: true, // Keep on screen until user interacts (important for lock screen)
    data: { url: '/' }
  });
}