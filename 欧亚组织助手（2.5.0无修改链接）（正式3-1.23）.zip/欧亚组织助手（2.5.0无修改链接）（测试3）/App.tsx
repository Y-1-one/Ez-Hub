
import React, { useState, useEffect, useRef, memo, Suspense } from 'react';
import { CheckSquare, Layout, Settings, WifiOff, BellRing, Music, Volume2, VolumeX, Upload, CloudRain, X, Play, Pause, ListMusic, Sparkles, Waves, Flame, Leaf, Moon, Headphones, ChevronRight, Check, BookOpen, MessageSquareHeart, Cake, Gift, Plus, Building2, LogOut, ChevronDown, UserPlus, RefreshCw, Trash2, Activity, ArrowRight } from 'lucide-react';
import { ViewState } from './types';
import { getUserProfile, getStoredSettings, getSavedAccounts, switchAccount, deleteAccount } from './services/storageService';
import { triggerHaptic } from './services/hapticService';
import TodoView from './components/TodoView';
// Eager load critical path, Lazy load others for faster TTI
import OnboardingView from './components/OnboardingView';
import TutorialOverlay from './components/TutorialOverlay';

const WorkbenchView = React.lazy(() => import('./components/WorkbenchView'));
const SettingsView = React.lazy(() => import('./components/SettingsView'));
const FeedbackView = React.lazy(() => import('./components/FeedbackView'));

// --- Optimized Loading Skeleton ---
const ViewSkeleton = () => (
  <div className="w-full h-full flex items-center justify-center animate-pulse">
    <div className="w-12 h-12 rounded-full border-4 border-white/20 border-t-indigo-500 animate-spin"></div>
  </div>
);

// --- Liquid Background Component (Optimized for GPU) ---
const LiquidBackground = memo(({ paused }: { paused: boolean }) => {
  return (
    <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none bg-[#f8fafc] dark:bg-[#0f172a] transition-colors duration-500 transform-gpu">
       {/* Added 'will-change-transform' and conditional animation state to save battery */}
       <div className={`absolute top-[-10%] left-[-10%] w-[50vw] h-[50vw] rounded-full mix-blend-multiply filter blur-[80px] bg-[#ff80b5] opacity-20 dark:bg-purple-500 dark:opacity-30 will-change-transform ${paused ? '' : 'animate-blob'}`}></div>
       <div className={`absolute top-[-10%] right-[-10%] w-[50vw] h-[50vw] rounded-full mix-blend-multiply filter blur-[80px] animation-delay-2000 bg-[#9089fc] opacity-20 dark:bg-indigo-500 dark:opacity-30 will-change-transform ${paused ? '' : 'animate-blob'}`}></div>
       <div className={`absolute bottom-[-20%] left-[10%] w-[60vw] h-[60vw] rounded-full mix-blend-multiply filter blur-[90px] animation-delay-4000 bg-[#7dd3fc] opacity-25 dark:bg-pink-500 dark:opacity-30 will-change-transform ${paused ? '' : 'animate-blob'}`}></div>
       <div className={`absolute bottom-[10%] right-[-5%] w-[40vw] h-[40vw] rounded-full mix-blend-multiply filter blur-[64px] animate-pulse bg-[#fcd34d] opacity-15 dark:bg-blue-600 dark:opacity-20 will-change-transform ${paused ? '' : 'animate-blob'}`}></div>
       <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 dark:opacity-20 brightness-100 contrast-150 mix-blend-overlay"></div>
       <div className="absolute inset-0 bg-gradient-to-t from-white/40 via-transparent to-white/40 dark:from-black/20 dark:via-transparent dark:to-black/20 pointer-events-none"></div>
    </div>
  );
});

// Custom hook for network status
function useNetworkStatus() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);
  return isOnline;
}

// Custom hook for Page Visibility (Battery Optimization)
function usePageVisibility() {
  const [isVisible, setIsVisible] = useState(!document.hidden);
  useEffect(() => {
    const handleVisibilityChange = () => setIsVisible(!document.hidden);
    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => document.removeEventListener("visibilitychange", handleVisibilityChange);
  }, []);
  return isVisible;
}

// --- Atmosphere Synthesis Engine (Optimized) ---
class AtmosphereEngine {
  ctx: AudioContext | null = null;
  masterGain: GainNode | null = null;
  activeNodes: AudioNode[] = [];
  activeElements: HTMLAudioElement[] = [];

  init() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      this.masterGain = this.ctx.createGain();
      this.masterGain.connect(this.ctx.destination);
    }
    // Resume context if suspended
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    this.masterGain!.gain.cancelScheduledValues(this.ctx.currentTime);
    this.masterGain!.gain.setValueAtTime(1, this.ctx.currentTime);
  }

  suspend() {
    if (this.ctx && this.ctx.state === 'running') {
      this.ctx.suspend();
    }
  }

  resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  stop() {
    if (!this.ctx || !this.masterGain) return;
    const nodesToKill = [...this.activeNodes];
    const elementsToKill = [...this.activeElements];
    this.activeNodes = [];
    this.activeElements = [];
    const t = this.ctx.currentTime;
    // Smooth fade out to avoid clicks
    this.masterGain.gain.cancelScheduledValues(t);
    this.masterGain.gain.setValueAtTime(this.masterGain.gain.value, t);
    this.masterGain.gain.linearRampToValueAtTime(0, t + 0.5);
    setTimeout(() => {
      elementsToKill.forEach(el => { el.pause(); el.src = ""; });
      nodesToKill.forEach(node => { try { node.disconnect(); } catch(e){} });
    }, 600); 
  }

  playStream(url: string, volume: number = 1.0) {
    if (!this.ctx || !this.masterGain) return;
    const audio = new Audio();
    audio.crossOrigin = "anonymous";
    audio.src = url;
    audio.loop = true;
    audio.preload = "auto"; 
    // audio.volume is handled by gain node for better control
    const source = this.ctx.createMediaElementSource(audio);
    const gainNode = this.ctx.createGain();
    gainNode.gain.value = volume;
    source.connect(gainNode).connect(this.masterGain);
    audio.play().catch(e => console.error("Audio Play Error:", e));
    this.activeElements.push(audio);
    this.activeNodes.push(source);
    this.activeNodes.push(gainNode);
  }

  playRain() { this.init(); this.playStream('https://assets.mixkit.co/active_storage/sfx/2515/2515-preview.mp3', 0.85); }
  playFire() { this.init(); this.playStream('https://assets.mixkit.co/active_storage/sfx/1330/1330-preview.mp3', 0.9); }
  playForest() { this.init(); this.playStream('https://assets.mixkit.co/active_storage/sfx/1210/1210-preview.mp3', 0.6); }
  playOcean() { this.init(); this.playStream('https://assets.mixkit.co/active_storage/sfx/1196/1196-preview.mp3', 0.7); }
  playNight() { this.init(); this.playStream('https://assets.mixkit.co/active_storage/sfx/1242/1242-preview.mp3', 0.6); }
}

const atmosphereEngine = new AtmosphereEngine();

type AudioType = 'generated' | 'custom';
interface AudioTrack {
  id: string; 
  title: string; 
  type: AudioType; 
  icon: any; 
  description?: string;
  color: string;
}

const ATMOSPHERE_PRESETS: AudioTrack[] = [
  { id: 'rain', title: '听雨·独处', description: '沉浸式窗外雨声，隔绝外界喧嚣', type: 'generated', icon: CloudRain, color: 'from-blue-500 to-indigo-600' },
  { id: 'fire', title: '静谧·篝火', description: '清晰的木柴燃烧爆裂声，极度解压', type: 'generated', icon: Flame, color: 'from-orange-600 to-amber-700' },
  { id: 'forest', title: '森林·晨曦', description: '清晨的鸟鸣与微风，焕发活力', type: 'generated', icon: Leaf, color: 'from-emerald-500 to-green-700' },
  { id: 'night', title: '深夜·书房', description: '旷野虫鸣与极其安静的底噪', type: 'generated', icon: Moon, color: 'from-slate-700 to-slate-900' },
  { id: 'ocean', title: '深海·冥想', description: '有节奏的潮汐海浪，平复焦虑', type: 'generated', icon: Waves, color: 'from-cyan-600 to-blue-800' }
];

const Visualizer = ({ active }: { active: boolean }) => (
  <div className="relative w-5 h-5 flex items-center justify-center">
    {active ? (
      <>
        <div className="absolute inset-0 border-[1.5px] rounded-full animate-[spin_2s_linear_infinite] border-t-transparent border-l-transparent border-slate-900/80 dark:border-white/80"></div>
        <div className="w-1.5 h-1.5 rounded-full bg-slate-900 dark:bg-white"></div>
      </>
    ) : (
      <Music size={16} />
    )}
  </div>
);

const NAV_ITEMS = [
  { id: 'todo', label: '任务', icon: CheckSquare },
  { id: 'workbench', label: '工作台', icon: Layout },
  { id: 'feedback', label: '反馈', icon: MessageSquareHeart },
  { id: 'settings', label: '设置', icon: Settings },
];

function App() {
  const [currentView, setCurrentView] = useState<ViewState>('todo');
  const [routeParams, setRouteParams] = useState<any>({});
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false); 
  const [alarmMsg, setAlarmMsg] = useState<string | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [themeMode, setThemeMode] = useState(getStoredSettings().themeMode);
  const [birthdayMsg, setBirthdayMsg] = useState<{type: 'today'|'belated', daysAgo?: number} | null>(null);
  const [isBgmPlaying, setIsBgmPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState<AudioTrack>(ATMOSPHERE_PRESETS[0]);
  const [customTrackUrl, setCustomTrackUrl] = useState<string | null>(null);
  const [musicPanelVisible, setMusicPanelVisible] = useState(false); 
  const [musicPanelMounted, setMusicPanelMounted] = useState(false); 
  const [showOrgSwitcher, setShowOrgSwitcher] = useState(false);
  const [orgSwitcherMode, setOrgSwitcherMode] = useState<'list' | 'confirm_add' | 'confirm_switch' | 'confirm_delete'>('list'); 
  const [availableAccounts, setAvailableAccounts] = useState<any[]>([]);
  const [pendingAccount, setPendingAccount] = useState<any>(null); 
  const [currentOrgName, setCurrentOrgName] = useState('欧亚学促会');
  const [isSwitching, setIsSwitching] = useState(false); 
  const [isManagingOrgs, setIsManagingOrgs] = useState(false); 
  const [appRefreshKey, setAppRefreshKey] = useState(0);

  const mainContentRef = useRef<HTMLDivElement>(null);
  const htmlAudioRef = useRef<HTMLAudioElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [alarmAudio, setAlarmAudio] = useState<HTMLAudioElement | null>(null); 
  
  const isOnline = useNetworkStatus();
  const isPageVisible = usePageVisibility();

  // --- BATTERY & PERFORMANCE OPTIMIZATION ---
  // Automatically suspend/resume audio engine based on visibility to save CPU/Battery
  useEffect(() => {
    if (isBgmPlaying) {
      if (isPageVisible) {
        if (currentTrack.type === 'generated') atmosphereEngine.resume();
        if (htmlAudioRef.current) htmlAudioRef.current.play();
      } else {
        if (currentTrack.type === 'generated') atmosphereEngine.suspend();
        if (htmlAudioRef.current) htmlAudioRef.current.pause();
      }
    }
  }, [isPageVisible, isBgmPlaying, currentTrack.type]);

  useEffect(() => {
    const applyTheme = () => {
        const isDark = themeMode === 'dark' || (themeMode === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
        const metaThemeColor = document.querySelector('meta[name="theme-color"]');
        if (isDark) {
            document.documentElement.classList.add('dark');
            if (metaThemeColor) metaThemeColor.setAttribute('content', '#0f172a');
        } else {
            document.documentElement.classList.remove('dark');
            if (metaThemeColor) metaThemeColor.setAttribute('content', '#f8fafc');
        }
    };

    applyTheme();

    if (themeMode === 'system') {
        const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
        mediaQuery.addEventListener('change', applyTheme);
        return () => mediaQuery.removeEventListener('change', applyTheme);
    }
  }, [themeMode]);

  const showToast = (msg: string) => { setToastMsg(msg); setTimeout(() => setToastMsg(null), 3000); };

  const openMusicPanel = () => {
    triggerHaptic('medium');
    setMusicPanelMounted(true);
    requestAnimationFrame(() => setMusicPanelVisible(true));
  };

  const closeMusicPanel = () => {
    setMusicPanelVisible(false);
    setTimeout(() => setMusicPanelMounted(false), 300);
  };

  const openOrgSwitcher = () => {
      triggerHaptic('medium');
      setAvailableAccounts(getSavedAccounts());
      setOrgSwitcherMode('list'); 
      setIsManagingOrgs(false); 
      setShowOrgSwitcher(true);
  };

  const navigate = (path: string) => {
    triggerHaptic('light');
    window.location.hash = path;
  };

  const handleTutorialComplete = () => {
      setShowTutorial(false);
      localStorage.setItem('eurasia_tutorial_seen', 'true');
  };

  const handleSwitchAccountAction = async (targetOrg: string) => {
      setIsSwitching(true);
      triggerHaptic('heavy');
      setTimeout(() => {
          switchAccount(targetOrg);
          setIsSwitching(false);
      }, 300);
  };

  const handleDeleteAccountAction = (orgName: string) => {
      const result = deleteAccount(orgName);
      if (result.isCurrent) {
          window.location.reload(); 
      } else {
          setAvailableAccounts(getSavedAccounts()); 
          setOrgSwitcherMode('list'); 
          triggerHaptic('heavy');
          showToast('组织数据已删除');
      }
  };

  useEffect(() => {
    if (mainContentRef.current) {
      mainContentRef.current.scrollTop = 0;
    }
    window.scrollTo(0, 0);
  }, [currentView, routeParams]);

  useEffect(() => {
    let touchStartX = 0;
    let touchStartY = 0;
    const EDGE_THRESHOLD = 40; 
    const SWIPE_THRESHOLD = 50;

    const handleTouchStart = (e: TouchEvent) => {
      touchStartX = e.touches[0].clientX;
      touchStartY = e.touches[0].clientY;
    };

    const handleTouchEnd = (e: TouchEvent) => {
      const touchEndX = e.changedTouches[0].clientX;
      const touchEndY = e.changedTouches[0].clientY;
      const diffX = touchEndX - touchStartX;
      const diffY = touchEndY - touchStartY;
      const windowWidth = window.innerWidth;

      const isLeftEdge = touchStartX <= EDGE_THRESHOLD;
      const isRightEdge = touchStartX >= windowWidth - EDGE_THRESHOLD;

      if (!isLeftEdge && !isRightEdge) return;

      const isBackGesture = (isLeftEdge && diffX > SWIPE_THRESHOLD) || 
                            (isRightEdge && diffX < -SWIPE_THRESHOLD);
      const isHorizontal = Math.abs(diffX) > Math.abs(diffY) * 1.5;

      if (isBackGesture && isHorizontal) {
         handleBackNavigation();
      }
    };

    const handleBackNavigation = () => {
      if (currentView === 'workbench' && routeParams.deptId) {
         navigate('#workbench');
         return;
      }
      if (currentView !== 'todo') {
         navigate('#todo');
      }
    };

    window.addEventListener('touchstart', handleTouchStart, { passive: true });
    window.addEventListener('touchend', handleTouchEnd, { passive: true });

    return () => {
      window.removeEventListener('touchstart', handleTouchStart);
      window.removeEventListener('touchend', handleTouchEnd);
    };
  }, [currentView, routeParams]);


  useEffect(() => { 
    if (isBgmPlaying) {
      playAudio(currentTrack); 
    }
  }, [currentTrack]);

  const toggleBgm = () => { 
    triggerHaptic('medium');
    if (isBgmPlaying) {
      setIsBgmPlaying(false);
      stopAudio();
    } else {
      setIsBgmPlaying(true);
      playAudio(currentTrack);
    }
  };

  const playAudio = async (track: AudioTrack) => {
    if (htmlAudioRef.current) { 
      htmlAudioRef.current.pause(); 
      htmlAudioRef.current = null; 
    }
    atmosphereEngine.stop();
    try {
      if (track.type === 'custom' && customTrackUrl) {
         const audio = new Audio(customTrackUrl);
         audio.loop = true; 
         audio.volume = 0.5;
         htmlAudioRef.current = audio;
         audio.play().catch(e => { console.error(e); setIsBgmPlaying(false); });
      } else if (track.type === 'generated') {
         switch(track.id) {
            case 'rain': atmosphereEngine.playRain(); break;
            case 'fire': atmosphereEngine.playFire(); break;
            case 'forest': atmosphereEngine.playForest(); break;
            case 'night': atmosphereEngine.playNight(); break;
            case 'ocean': atmosphereEngine.playOcean(); break;
            default: atmosphereEngine.playRain();
         }
      }
      setIsBgmPlaying(true);
    } catch (e) {
      console.error(e); 
      setIsBgmPlaying(false); 
      showToast('播放失败');
    }
  };

  const stopAudio = () => {
    if (htmlAudioRef.current) htmlAudioRef.current.pause();
    atmosphereEngine.stop();
    setIsBgmPlaying(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setCustomTrackUrl(url);
      const newTrack: AudioTrack = { 
        id: 'custom_file', 
        title: file.name.slice(0, 15), 
        type: 'custom', 
        icon: Upload,
        description: '本地上传的音频文件',
        color: 'from-gray-500 to-gray-700'
      };
      setCurrentTrack(newTrack);
      setIsBgmPlaying(true);
      playAudio(newTrack); 
      closeMusicPanel();
    }
  };

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.slice(1);
      if (!hash) { window.history.replaceState(null, '', '#todo'); setCurrentView('todo'); return; }
      const parts = hash.split('/');
      const mainView = parts[0] as ViewState;
      if (['todo', 'workbench', 'settings', 'feedback'].includes(mainView)) {
        React.startTransition(() => {
            setCurrentView(mainView);
            if (mainView === 'workbench') setRouteParams({ deptId: parts[1] || null });
            else if (mainView === 'todo') setRouteParams({ action: parts[1], id: parts[2] });
        });
      } else { window.history.replaceState(null, '', '#todo'); setCurrentView('todo'); }
    };
    handleHashChange(); window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const getAbbreviatedOrgName = (name: string) => {
      if (!name) return '欧亚学促会';
      const match = name.match(/西安欧亚学院(.+)学生成长促进会/);
      if (match && match[1]) {
          const college = match[1];
          let shortCollege = college;
          if (college.includes('人文教育')) shortCollege = '人文';
          else if (college.includes('文化传媒')) shortCollege = '文传';
          else if (college.includes('工商管理')) shortCollege = '工商';
          else if (college.includes('会计')) shortCollege = '会计';
          else if (college.includes('人居环境')) shortCollege = '人居';
          else if (college.includes('金融')) shortCollege = '金数'; 
          else if (college.includes('艾德')) shortCollege = '艾德';
          else if (college.includes('职业教育')) shortCollege = '职教';
          else if (college.includes('通识教育')) shortCollege = '通识';
          else if (college.includes('高等职业')) shortCollege = '高职';
          else if (college.includes('信息工程')) shortCollege = '信工';
          else if (college.includes('马克思主义')) shortCollege = '马院';
          
          return `${shortCollege}学促会`;
      }
      
      if (name.length > 8) {
          if (name.endsWith('协会')) return name.substring(0, 4) + '...协会';
          if (name.endsWith('社团')) return name.substring(0, 4) + '...社团';
          if (name.endsWith('俱乐部')) return name.substring(0, 4) + '...俱乐部';
          return name.substring(0, 6) + '...';
      }
      return name;
  };

  useEffect(() => {
    const profile = getUserProfile();
    const isLoggedOut = localStorage.getItem('eurasia_logged_out') === 'true';
    if (profile && profile.organization) {
        setCurrentOrgName(profile.organization);
    } else {
        setCurrentOrgName('欧亚学促会');
    }
    if (!profile || isLoggedOut) {
      setShowOnboarding(true);
    } else if (profile.birthday) {
       checkBirthday(profile.birthday);
    }
  }, [isOnline]);

  const checkBirthday = (bday: string) => {
     const now = new Date();
     const currentYear = now.getFullYear();
     const [bMonth, bDay] = bday.split('-').map(Number);
     const lastWishYear = localStorage.getItem('eurasia_last_birthday_wish_year');
     if (lastWishYear === String(currentYear)) return;
     const today = new Date(currentYear, now.getMonth(), now.getDate());
     const thisYearBday = new Date(currentYear, bMonth - 1, bDay);
     const diffTime = today.getTime() - thisYearBday.getTime();
     const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
     if (diffDays === 0) {
        setBirthdayMsg({ type: 'today' });
        triggerHaptic('success');
        localStorage.setItem('eurasia_last_birthday_wish_year', String(currentYear));
     } else if (diffDays > 0 && diffDays <= 30) {
        setBirthdayMsg({ type: 'belated', daysAgo: diffDays });
        localStorage.setItem('eurasia_last_birthday_wish_year', String(currentYear));
     }
  };

  const handleAlarm = (msg: string) => {
    setAlarmMsg(msg); if(isBgmPlaying) stopAudio();
    const a = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
    a.loop = true; a.play().catch(()=>{}); setAlarmAudio(a);
    triggerHaptic('heavy');
  };
  const dismissAlarm = () => { setAlarmMsg(null); alarmAudio?.pause(); };

  if (showOnboarding) return <OnboardingView onComplete={() => {
    setShowOnboarding(false);
    const profile = getUserProfile();
    if (profile && profile.organization) setCurrentOrgName(profile.organization);
    setAppRefreshKey(prev => prev + 1); 
    navigate('#todo');
    if (!localStorage.getItem('eurasia_tutorial_seen')) {
        setTimeout(() => setShowTutorial(true), 500);
    }
  }} />;

  const isGlassView = currentView !== 'todo';

  return (
    <div className={`h-[100dvh] w-full font-sans flex flex-col overflow-hidden fixed inset-0 z-10 animate-fade-in text-slate-900 dark:text-white transition-colors duration-500`}>
      {/* Pass paused state to LiquidBackground to stop animation loop when hidden */}
      <LiquidBackground paused={!isPageVisible} />
      <div className={`relative z-20 h-full w-full flex flex-col transform-gpu`}>
      <div className="shrink-0 z-50 transition-transform relative pointer-events-none md:pointer-events-auto">
        <div className={`transition-all bg-red-500/80 backdrop-blur-md text-white flex justify-center items-center pointer-events-auto ${!isOnline ? 'h-6' : 'h-0 overflow-hidden'}`}>
           <div className="text-[10px] text-center flex gap-1 items-center"><WifiOff size={10}/> 离线模式</div>
        </div>
        <div className="md:hidden fixed top-0 left-0 right-0 z-50 p-4 pt-safe mt-2 pointer-events-none flex justify-center">
           <div className={`pointer-events-auto flex items-center justify-between gap-4 px-5 py-2.5 rounded-full transition-all duration-500 ease-out bg-white/60 dark:bg-glass-200 backdrop-blur-xl border border-white/40 dark:border-white/20 shadow-lg shadow-black/5 dark:shadow-black/20`}>
             <div onClick={openOrgSwitcher} className="flex items-center gap-2 cursor-pointer active:scale-95 transition-transform group">
                <div className="w-2 h-2 rounded-full bg-indigo-500 dark:bg-indigo-400 shadow-[0_0_8px_rgba(99,102,241,0.5)] dark:shadow-[0_0_8px_rgba(129,140,248,0.8)] animate-pulse"></div>
                <div className="font-bold text-sm tracking-tight text-slate-900 dark:text-white flex items-center gap-1 max-w-[120px] truncate">
                    {getAbbreviatedOrgName(currentOrgName)}
                    <ChevronDown size={12} className="text-slate-400 dark:text-white/50 group-hover:text-indigo-500 transition-colors"/>
                </div>
             </div>
             <div className="w-px h-3 bg-black/10 dark:bg-white/20"></div>
             <div onClick={openMusicPanel} className="flex items-center gap-2 cursor-pointer active:scale-95 transition-transform text-slate-600 dark:text-white/80">
                <span className="text-[10px] font-medium tracking-wide">{isBgmPlaying ? '专注中' : '氛围'}</span>
                <Visualizer active={isBgmPlaying} />
             </div>
           </div>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden relative">
        <aside className="hidden md:flex flex-col w-64 glass-panel border-r-0 h-full p-6 z-20 transition-colors duration-300">
            <div onClick={openOrgSwitcher} className="flex items-center gap-3 mb-8 cursor-pointer group p-2 -ml-2 rounded-xl hover:bg-white/50 dark:hover:bg-white/5 transition-all">
              <div className="w-10 h-10 bg-indigo-600 dark:bg-indigo-500/80 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg border border-white/20 group-hover:scale-105 transition-transform">E</div>
              <div className="flex-1 min-w-0">
                  <h1 className="font-bold text-slate-900 dark:text-white flex items-center gap-2 truncate">
                      {getAbbreviatedOrgName(currentOrgName)}
                      <ChevronDown size={14} className="text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity"/>
                  </h1>
                  <p className="text-xs text-indigo-600 dark:text-indigo-200">点击切换组织</p>
              </div>
            </div>
            <nav className="space-y-2 flex-1">
              <NavButton view="todo" current={currentView} onNavigate={() => navigate('#todo')} icon={CheckSquare} label="任务中心" />
              <NavButton view="workbench" current={currentView} onNavigate={() => navigate('#workbench')} icon={Layout} label="工作台" />
              <NavButton view="feedback" current={currentView} onNavigate={() => navigate('#feedback')} icon={MessageSquareHeart} label="反馈" />
              <NavButton view="settings" current={currentView} onNavigate={() => navigate('#settings')} icon={Settings} label="设置" />
            </nav>
            <div className="mt-auto pt-6 border-t border-black/5 dark:border-white/5">
              <div className="mb-3 text-xs font-bold text-slate-400 dark:text-white/40 uppercase flex items-center gap-1 tracking-wider">
                <Headphones size={10}/> 沉浸专注
              </div>
              <div className="bg-white/60 dark:bg-white/5 rounded-2xl p-1.5 border border-white/40 dark:border-white/10 flex items-center gap-2.5 p-2 shadow-sm hover:shadow-md transition-all group backdrop-blur-sm">
                  <button onClick={toggleBgm} className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all active:scale-90 shadow-sm ${isBgmPlaying ? 'bg-indigo-500 text-white' : 'bg-white dark:bg-white/10 text-slate-600 dark:text-white border border-gray-100 dark:border-white/5'}`}>
                    {isBgmPlaying ? <Volume2 size={18}/> : <VolumeX size={18}/>}
                  </button>
                  <div className="flex-1 min-w-0 cursor-pointer" onClick={openMusicPanel}>
                    <div className="font-bold text-sm truncate text-slate-800 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-300 transition-colors">{currentTrack.title}</div>
                    <div className="text-[10px] text-slate-500 dark:text-white/50 flex items-center gap-1">
                       {isBgmPlaying ? <span className="text-indigo-500 flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse"></span>播放中</span> : '点击切换场景'}
                    </div>
                  </div>
                  <div className="pr-2 text-slate-300 dark:text-white/20 group-hover:text-indigo-400 dark:group-hover:text-white/60 transition-colors">
                     <ListMusic size={16}/>
                  </div>
              </div>
            </div>
        </aside>

        <main ref={mainContentRef} className={`flex-1 h-full relative overflow-y-auto hide-scrollbar ${['todo'].includes(currentView) ? 'pt-0' : 'pt-24'} md:pt-0 pb-28 md:pb-0 transition-all duration-300 will-change-transform`}>
          <div className="h-full flex flex-col md:p-8">
             <div className={`flex-1 md:rounded-3xl relative flex flex-col ${isGlassView ? 'md:glass-panel md:overflow-hidden' : ''}`}>
                <div key={currentView + appRefreshKey} className="flex-1 flex flex-col animate-slide-up will-change-transform h-full">
                    {/* Wrap lazy loaded components in Suspense with Skeleton */}
                    <Suspense fallback={<ViewSkeleton />}>
                        {currentView === 'todo' && <TodoView modalAction={routeParams.action} modalId={routeParams.id} />}
                        {currentView === 'workbench' && <WorkbenchView selectedDeptId={routeParams.deptId} onSelectDept={(id) => navigate(id ? `#workbench/${id}` : '#workbench')} />}
                        {currentView === 'feedback' && <FeedbackView />}
                        {currentView === 'settings' && <SettingsView onThemeChange={(mode) => setThemeMode(mode)} />}
                    </Suspense>
                </div>
             </div>
          </div>
        </main>
      </div>

      <nav className="md:hidden fixed bottom-6 left-6 right-6 z-[60]" style={{ marginBottom: 'env(safe-area-inset-bottom)' }}>
         <div className="relative h-16 w-full rounded-full transition-all duration-500 flex items-center justify-between px-2 shadow-2xl bg-white/60 dark:bg-glass-200 border border-white/40 dark:border-white/20 shadow-gray-200/50 dark:shadow-black/40 backdrop-blur-2xl">
           {NAV_ITEMS.map((item) => {
             const isActive = currentView === item.id;
             return (
               <button key={item.id} onClick={() => navigate(`#${item.id}`)} className={`relative flex items-center justify-center rounded-full transition-all duration-300 ease-[cubic-bezier(0.2,0,0,1)] active:scale-90 ${isActive ? 'flex-[1.3] bg-black/5 dark:bg-white/20 text-indigo-600 dark:text-white h-12 border border-black/5 dark:border-white/10' : 'flex-1 text-slate-400 dark:text-white/50 h-12 border border-transparent hover:bg-black/5 dark:hover:bg-white/5'}`} style={{ WebkitTapHighlightColor: 'transparent' }}>
                 <item.icon size={22} strokeWidth={isActive ? 2.5 : 2} className={isActive ? 'text-current' : 'text-current'} />
                 <span className={`overflow-hidden whitespace-nowrap text-xs font-bold transition-all duration-300 ease-out ${isActive ? 'max-w-[80px] opacity-100 ml-2' : 'max-w-0 opacity-0 ml-0'}`}>{item.label}</span>
               </button>
             );
           })}
         </div>
      </nav>

      {/* Org Switcher Modal (Existing Code) - Kept mostly same but ensures overlays are optimized */}
      {showOrgSwitcher && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in" onClick={() => !isSwitching && setShowOrgSwitcher(false)}>
             <div className="glass-panel w-full max-w-sm rounded-3xl p-6 shadow-2xl animate-slide-up bg-white/95 dark:bg-gray-900/90" onClick={e => e.stopPropagation()}>
                 <div className="flex justify-between items-center mb-6">
                     <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2"><Building2 size={20} className="text-indigo-500"/> {orgSwitcherMode === 'confirm_add' ? '确认添加' : (orgSwitcherMode === 'confirm_switch' ? '确认切换' : (orgSwitcherMode === 'confirm_delete' ? '确认删除' : '切换组织'))}</h3>
                     {!isSwitching && (
                        <div className="flex items-center gap-2">
                            {!['confirm_add', 'confirm_switch', 'confirm_delete'].includes(orgSwitcherMode) && (
                                <button 
                                    onClick={() => { setIsManagingOrgs(!isManagingOrgs); triggerHaptic('medium'); }} 
                                    className={`px-3 py-1 rounded-full text-xs font-bold transition-colors ${isManagingOrgs ? 'bg-indigo-100 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-300' : 'text-slate-500 dark:text-white/60 hover:text-indigo-500'}`}
                                >
                                    {isManagingOrgs ? '完成' : '管理'}
                                </button>
                            )}
                            <button onClick={() => setShowOrgSwitcher(false)} className="p-2 bg-black/5 dark:bg-white/10 rounded-full"><X size={18}/></button>
                        </div>
                     )}
                 </div>

                 {orgSwitcherMode === 'list' && (
                     <>
                        <div className="space-y-3 max-h-[300px] overflow-y-auto custom-scrollbar mb-4">
                            {availableAccounts.map((acc: any) => (
                                <button 
                                  key={acc.organization} 
                                  onClick={() => { 
                                    if (isManagingOrgs) {
                                        setPendingAccount(acc);
                                        setOrgSwitcherMode('confirm_delete');
                                        triggerHaptic('warning');
                                    } else {
                                        if (acc.organization === currentOrgName) { 
                                          setShowOrgSwitcher(false); 
                                        } else { 
                                          setPendingAccount(acc);
                                          setOrgSwitcherMode('confirm_switch');
                                          triggerHaptic('medium');
                                        } 
                                    }
                                  }} 
                                  className={`w-full p-4 rounded-xl flex items-center gap-4 transition-all border ${acc.organization === currentOrgName ? 'bg-indigo-50 dark:bg-indigo-500/20 border-indigo-200 dark:border-indigo-500/50' : 'bg-white dark:bg-white/5 border-gray-100 dark:border-white/10 hover:bg-gray-50 dark:hover:bg-white/10'}`}
                                >
                                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-400 to-purple-500 flex items-center justify-center text-white font-bold shadow-md">{acc.organization.slice(0,1)}</div>
                                    <div className="flex-1 text-left">
                                        <div className="font-bold text-slate-800 dark:text-white text-sm line-clamp-1">{getAbbreviatedOrgName(acc.organization)}</div>
                                        <div className="text-xs text-slate-500 dark:text-white/50">{acc.userName} · {acc.userId.slice(0,6)}...</div>
                                    </div>
                                    {isManagingOrgs ? (
                                        <div className="w-8 h-8 rounded-full bg-red-100 dark:bg-red-500/20 text-red-500 dark:text-red-400 flex items-center justify-center shadow-sm">
                                            <Trash2 size={16}/>
                                        </div>
                                    ) : (
                                        acc.organization === currentOrgName && <Check size={18} className="text-indigo-500"/>
                                    )}
                                </button>
                            ))}
                        </div>
                        <button 
                            onClick={(e) => { 
                                e.stopPropagation(); 
                                triggerHaptic('medium');
                                setOrgSwitcherMode('confirm_add'); 
                            }} 
                            className="w-full py-3 border-2 border-dashed border-gray-300 dark:border-white/20 rounded-xl flex items-center justify-center gap-2 text-slate-500 dark:text-white/50 hover:bg-gray-50 dark:hover:bg-white/5 hover:text-indigo-500 dark:hover:text-indigo-400 hover:border-indigo-300 transition-colors font-bold text-sm"
                        >
                            <Plus size={18}/> 添加/注册新组织
                        </button>
                     </>
                 )}

                 {orgSwitcherMode === 'confirm_switch' && pendingAccount && (
                     <div className="animate-fade-in text-center">
                        <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-500/20 rounded-full flex items-center justify-center text-indigo-500 mx-auto mb-4">
                            {isSwitching ? <RefreshCw className="animate-spin" size={32}/> : <Building2 size={32} />}
                        </div>
                        <h4 className="font-bold text-slate-800 dark:text-white text-lg mb-2">{isSwitching ? '正在切换...' : '切换到该组织?'}</h4>
                        <div className="bg-white dark:bg-white/5 p-3 rounded-xl mb-4 border border-gray-100 dark:border-white/10">
                            <div className="font-bold text-indigo-600 dark:text-indigo-300 text-sm mb-1">{pendingAccount.organization}</div>
                            <div className="text-xs text-slate-500 dark:text-white/60">{pendingAccount.userName}</div>
                        </div>
                        <p className="text-sm text-slate-500 dark:text-white/60 mb-6 leading-relaxed">
                            {isSwitching ? '请稍候，正在同步并恢复应用状态。' : <span>系统将自动保存当前组织 <span className="font-bold">{currentOrgName}</span> 的所有进度与配置。</span>}
                        </p>
                        <div className="flex gap-3">
                            <button 
                                onClick={() => setOrgSwitcherMode('list')} 
                                disabled={isSwitching}
                                className="flex-1 py-3 bg-gray-100 dark:bg-white/10 rounded-xl font-bold text-slate-600 dark:text-white/80 hover:bg-gray-200 dark:hover:bg-white/20 transition-colors disabled:opacity-50"
                            >
                                取消
                            </button>
                            <button 
                                onClick={() => handleSwitchAccountAction(pendingAccount.organization)} 
                                disabled={isSwitching}
                                className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-wait"
                            >
                                {isSwitching ? '切换中...' : <>确认切换 <ArrowRight size={16}/></>}
                            </button>
                        </div>
                     </div>
                 )}

                 {orgSwitcherMode === 'confirm_delete' && pendingAccount && (
                     <div className="animate-fade-in text-center">
                        <div className="w-16 h-16 bg-red-100 dark:bg-red-500/20 rounded-full flex items-center justify-center text-red-500 mx-auto mb-4">
                            <Trash2 size={32} />
                        </div>
                        <h4 className="font-bold text-slate-800 dark:text-white text-lg mb-2">确认删除该组织?</h4>
                        <div className="bg-white dark:bg-white/5 p-3 rounded-xl mb-4 border border-red-200 dark:border-red-500/30">
                            <div className="font-bold text-red-600 dark:text-red-300 text-sm mb-1">{pendingAccount.organization}</div>
                            <div className="text-xs text-slate-500 dark:text-white/60">{pendingAccount.userName}</div>
                        </div>
                        <p className="text-sm text-slate-500 dark:text-white/60 mb-6 leading-relaxed">
                            此操作将 <span className="text-red-500 font-bold">永久删除</span> 该组织下的所有本地数据（任务、配置等），且无法恢复。
                        </p>
                        <div className="flex gap-3">
                            <button 
                                onClick={() => setOrgSwitcherMode('list')} 
                                className="flex-1 py-3 bg-gray-100 dark:bg-white/10 rounded-xl font-bold text-slate-600 dark:text-white/80 hover:bg-gray-200 dark:hover:bg-white/20 transition-colors"
                            >
                                取消
                            </button>
                            <button 
                                onClick={() => handleDeleteAccountAction(pendingAccount.organization)} 
                                className="flex-1 py-3 bg-red-600 text-white rounded-xl font-bold shadow-lg flex items-center justify-center gap-2 hover:bg-red-700"
                            >
                                确认删除
                            </button>
                        </div>
                     </div>
                 )}

                 {orgSwitcherMode === 'confirm_add' && (
                     <div className="animate-fade-in text-center">
                        <div className="w-16 h-16 bg-blue-100 dark:bg-blue-500/20 rounded-full flex items-center justify-center text-blue-500 mx-auto mb-4">
                            <UserPlus size={32} />
                        </div>
                        <h4 className="font-bold text-slate-800 dark:text-white text-lg mb-2">添加新账号</h4>
                        <p className="text-sm text-slate-500 dark:text-white/60 mb-6 leading-relaxed">
                            此操作将自动保存当前所有数据到本地，并返回初始注册页面以创建新的组织身份。<br/><span className="text-xs opacity-70">(数据不会丢失，随时可切换回来)</span>
                        </p>
                        <div className="flex gap-3">
                            <button 
                                onClick={() => setOrgSwitcherMode('list')} 
                                className="flex-1 py-3 bg-gray-100 dark:bg-white/10 rounded-xl font-bold text-slate-600 dark:text-white/80"
                            >
                                取消
                            </button>
                            <button 
                                onClick={() => { switchAccount('NEW_ACCOUNT'); }} 
                                className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg"
                            >
                                确认前往
                            </button>
                        </div>
                     </div>
                 )}
             </div>
          </div>
      )}

      {/* Music Panel (Existing) */}
      {musicPanelMounted && (
        <div className={`fixed inset-0 z-[60] flex items-end md:items-center justify-center transition-all duration-300 ${musicPanelVisible ? 'bg-black/20 dark:bg-black/60 backdrop-blur-[4px]' : 'bg-black/0 backdrop-blur-none pointer-events-none'}`} onClick={closeMusicPanel}>
           <div className={`w-full md:max-w-xl rounded-t-[2.5rem] md:rounded-3xl shadow-2xl relative max-h-[85vh] overflow-hidden flex flex-col transition-transform duration-300 cubic-bezier(0.16, 1, 0.3, 1) bg-white/90 dark:bg-gray-900/90 backdrop-blur-2xl border border-white/20 dark:border-white/10 ${musicPanelVisible ? 'translate-y-0 opacity-100 scale-100' : 'translate-y-full md:translate-y-10 md:opacity-0 md:scale-95'}`} onClick={e => e.stopPropagation()}>
              <div className="p-6 pb-4 shrink-0">
                <div className="w-12 h-1.5 bg-gray-300 dark:bg-white/20 rounded-full mx-auto mb-6 md:hidden"></div>
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xl font-bold flex items-center gap-2 text-slate-900 dark:text-white"><div className="p-2 bg-indigo-50 dark:bg-white/10 rounded-full text-indigo-600 dark:text-indigo-400"><Headphones size={20} /></div>氛围模式</h3>
                  <button onClick={closeMusicPanel} className="p-2 bg-gray-100 dark:bg-white/10 hover:bg-gray-200 dark:hover:bg-white/20 rounded-full active:scale-95 transition-transform text-slate-500 dark:text-white/70"><X size={20}/></button>
                </div>
                <div className={`bg-gradient-to-br ${currentTrack.color} rounded-3xl p-6 text-white shadow-xl shadow-indigo-500/20 dark:shadow-none transition-all duration-500 flex items-center justify-between relative overflow-hidden group mb-2 border border-white/20 ring-1 ring-white/20`}>
                   <div className="absolute top-0 right-0 -mr-8 -mt-8 w-32 h-32 bg-white/20 rounded-full blur-2xl mix-blend-overlay"></div>
                   <div className="absolute bottom-0 left-0 -ml-8 -mb-8 w-32 h-32 bg-black/10 rounded-full blur-2xl"></div>
                   <div className="flex items-center gap-5 relative z-10">
                      <div className={`w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center backdrop-blur-md border border-white/20 ${isBgmPlaying ? 'shadow-[0_0_25px_rgba(255,255,255,0.4)] scale-105' : 'scale-100'} transition-all duration-700`}><Visualizer active={isBgmPlaying} /></div>
                      <div>
                         <div className="font-bold text-xl tracking-tight text-white mb-1">{currentTrack.title}</div>
                         <div className="text-xs font-medium text-white/80 flex items-center gap-1.5">{isBgmPlaying ? (<><span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"></span> 沉浸专注中</>) : ('点击播放以开始')}</div>
                      </div>
                   </div>
                   <button onClick={toggleBgm} className="w-14 h-14 bg-white text-indigo-600 rounded-full flex items-center justify-center shadow-lg active:scale-90 transition-transform relative z-10 hover:bg-gray-50">{isBgmPlaying ? <Pause fill="currentColor" size={24} /> : <Play fill="currentColor" size={24} className="ml-1"/>}</button>
                </div>
              </div>
              <div className="px-6 pb-8 overflow-y-auto flex-1">
                 <h4 className="text-xs font-bold text-slate-400 dark:text-white/40 mb-4 px-1 uppercase tracking-wider">选择场景</h4>
                 <div className="space-y-3">
                    {ATMOSPHERE_PRESETS.map((track) => (
                      <div key={track.id} onClick={() => { triggerHaptic('selection'); if (currentTrack.id !== track.id) { setCurrentTrack(track); if (!isBgmPlaying) { setIsBgmPlaying(true); playAudio(track); } } else { toggleBgm(); } }} className={`group flex items-center gap-4 p-4 rounded-2xl cursor-pointer transition-all duration-300 active:scale-[0.98] border ${currentTrack.id === track.id ? 'bg-white dark:bg-white/10 border-indigo-200 dark:border-white/20 shadow-lg shadow-indigo-100/50 dark:shadow-none ring-1 ring-indigo-100 dark:ring-transparent' : 'bg-white/40 dark:bg-white/5 border-transparent hover:bg-white/80 dark:hover:bg-white/10 hover:border-white/50 dark:hover:border-white/10'}`}>
                         <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-white bg-gradient-to-br ${track.color} shadow-sm transition-transform duration-300 ${currentTrack.id === track.id ? 'scale-110 shadow-md' : 'group-hover:scale-105'}`}><track.icon size={22} /></div>
                         <div className="flex-1">
                            <div className={`font-bold text-sm mb-0.5 ${currentTrack.id === track.id ? 'text-indigo-900 dark:text-white' : 'text-slate-700 dark:text-white/80'}`}>{track.title}</div>
                            <div className="text-xs text-slate-500 dark:text-white/40 leading-tight">{track.description}</div>
                         </div>
                         {currentTrack.id === track.id && (<div className={`text-indigo-500 dark:text-indigo-400 transition-opacity duration-300 ${isBgmPlaying ? 'opacity-100' : 'opacity-0'}`}><Activity size={20} className="animate-pulse" /></div>)}
                      </div>
                    ))}
                    <div className="mt-6 pt-2">
                      <button onClick={() => { fileInputRef.current?.click(); triggerHaptic('selection'); }} className="w-full flex items-center justify-center gap-2 p-4 rounded-2xl border-2 border-dashed border-slate-200 dark:border-white/10 text-slate-500 dark:text-white/50 text-sm font-medium hover:border-indigo-400 dark:hover:border-white/30 hover:text-indigo-500 dark:hover:text-white hover:bg-indigo-50/50 dark:hover:bg-white/5 transition-all active:scale-95"><Upload size={18}/> <span>上传本地音频文件</span></button>
                      <input ref={fileInputRef} type="file" accept="audio/*" className="hidden" onChange={handleFileUpload} />
                    </div>
                 </div>
              </div>
           </div>
        </div>
      )}

      {/* Tutorial Overlay */}
      {showTutorial && <TutorialOverlay onComplete={handleTutorialComplete} />}

      {birthdayMsg && (
         <div className="fixed inset-0 z-[150] bg-black/90 flex flex-col items-center justify-center p-8 animate-fade-in text-center overflow-hidden" onClick={() => setBirthdayMsg(null)}>
            <div className="absolute inset-0 z-0 opacity-50">
               {[...Array(20)].map((_, i) => (<div key={i} className="absolute bg-white/20 w-1 h-1 rounded-full animate-bounce" style={{ left: Math.random()*100+'%', top: Math.random()*100+'%', animationDuration: Math.random()*2+1+'s' }}></div>))}
            </div>
            <div className="relative z-10 glass-panel p-8 rounded-3xl max-w-sm w-full shadow-[0_0_50px_rgba(255,105,180,0.3)] transform transition-transform animate-[slide-up_0.5s_ease-out]">
               <div className="w-24 h-24 bg-gradient-to-tr from-pink-400 to-orange-400 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg animate-bounce"><Cake size={48} className="text-white"/></div>
               {birthdayMsg.type === 'today' ? (<><h2 className="text-3xl font-bold text-white mb-2">生日快乐!</h2><p className="text-pink-100 text-lg mb-8 leading-relaxed">愿你眼中有光，心中有爱<br/>岁岁平安，万事顺遂</p></>) : (<><h2 className="text-2xl font-bold text-white mb-2">迟到的祝福</h2><p className="text-pink-100 text-sm mb-8 leading-relaxed">虽然错过了 {birthdayMsg.daysAgo} 天前的生日<br/>但祝福永远不会缺席<br/>祝你新的一岁，闪闪发光</p></>)}
               <button onClick={() => setBirthdayMsg(null)} className="px-8 py-3 bg-white text-pink-600 rounded-full font-bold shadow-lg active:scale-95 transition-transform flex items-center gap-2 mx-auto"><Gift size={18}/> 收下祝福</button>
            </div>
         </div>
      )}

      {alarmMsg && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm animate-fade-in">
           <div className="glass-panel rounded-3xl p-8 max-w-sm w-full text-center shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-red-500"></div>
              <div className="w-20 h-20 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-6"><BellRing size={36} className="text-red-500 animate-bounce"/></div>
              <h3 className="text-2xl font-bold mb-2 text-white">任务提醒</h3>
              <p className="text-gray-300 mb-8 leading-relaxed">{alarmMsg}</p>
              <button onClick={dismissAlarm} className="w-full py-3.5 bg-red-600 text-white font-bold rounded-xl shadow-lg shadow-red-900/50 active:scale-95 transition-transform hover:bg-red-700">我知道了</button>
           </div>
        </div>
      )}
      {toastMsg && <div className="fixed bottom-24 left-1/2 -translate-x-1/2 glass-panel text-slate-900 dark:text-white px-5 py-2.5 rounded-full text-sm font-medium z-[100] shadow-xl animate-fade-in flex items-center gap-2 border border-black/5 dark:border-white/20"><Check size={14} className="text-green-500 dark:text-green-400"/>{toastMsg}</div>}
      
      <style>{`
        html { scroll-behavior: smooth; }
        .pb-safe { padding-bottom: env(safe-area-inset-bottom); }
        .pt-safe { padding-top: env(safe-area-inset-top); }
        .hide-scrollbar::-webkit-scrollbar { display: none; }
        @keyframes fade-in { from { opacity: 0; transform: translate3d(0, 10px, 0) scale(0.98); } to { opacity: 1; transform: translate3d(0, 0, 0) scale(1); } }
        /* Refined Page Transition */
        @keyframes slide-up { 
            from { opacity: 0; transform: translate3d(0, 30px, 0) scale(0.98); } 
            to { opacity: 1; transform: translate3d(0, 0, 0) scale(1); } 
        }
        .animate-fade-in { animation: fade-in 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
        .animate-slide-up { animation: slide-up 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
        .will-change-transform { will-change: transform; }
      `}</style>
      </div>
    </div>
  );
}

const NavButton = ({ view, current, onNavigate, icon: Icon, label }: any) => (
  <button onClick={onNavigate} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all active:scale-95 group border ${current === view ? 'bg-black/5 dark:bg-white/10 text-slate-900 dark:text-white font-bold border-black/10 dark:border-white/20' : 'text-slate-500 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 border-transparent'}`}>
    <Icon size={20} className={`transition-transform group-active:scale-90 ${current === view ? 'text-indigo-600 dark:text-white' : 'text-slate-400 dark:text-white/50'}`} />
    {label}
    {current === view && <ChevronRight size={14} className="ml-auto text-slate-400 dark:text-white/50" />}
  </button>
);

export default App;
