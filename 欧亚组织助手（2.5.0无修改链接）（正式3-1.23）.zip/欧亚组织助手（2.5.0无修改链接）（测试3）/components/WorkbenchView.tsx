
import React, { useState, useEffect, useRef, memo } from 'react';
import { createPortal } from 'react-dom';
import { Department, LinkCard, Announcement, UserProfile, UserIdentity } from '../types';
import { getStoredDepartments, saveStoredDepartments, getUserProfile } from '../services/storageService';
import { generateColorCode, parseColorCode } from '../services/cimbarService';
import { triggerHaptic } from '../services/hapticService';
import { ArrowLeft, Edit2, Check, Plus, Trash2, ExternalLink, Link, FileText, Monitor, Users, Calendar, Megaphone, Pin, PinOff, Edit, Share2, ScanLine, X, Camera, Image as ImageIcon, Download, Briefcase, Zap, PenLine, Clock, Layers, AlertTriangle, Coffee, Globe, MessageCircle, Book, Cloud, CornerUpLeft, Copy, Smartphone, ArrowRight } from 'lucide-react';

interface WorkbenchViewProps {
  selectedDeptId: string | null;
  onSelectDept: (id: string | null) => void;
}

// Helper for Portals
const ModalPortal = ({ children }: { children?: React.ReactNode }) => {
  return createPortal(
    children,
    document.body
  );
};

// --- MEMOIZED COMPONENTS FOR PERFORMANCE (120Hz TARGET) ---

const RenderIcon = memo(({ name, size = 20 }: { name: string, size?: number }) => {
    switch (name) {
      case 'FileText': return <FileText size={size} />;
      case 'Monitor': return <Monitor size={size} />;
      case 'Users': return <Users size={size} />;
      case 'Calendar': return <Calendar size={size} />;
      case 'Image': return <ImageIcon size={size} />;
      case 'Briefcase': return <Briefcase size={size} />;
      case 'Zap': return <Zap size={size} />;
      case 'Coffee': return <Coffee size={size} />;
      case 'Download': return <Download size={size} />;
      case 'Clock': return <Clock size={size} />;
      case 'Globe': return <Globe size={size} />;
      case 'MessageCircle': return <MessageCircle size={size} />;
      case 'Book': return <Book size={size} />;
      case 'Cloud': return <Cloud size={size} />;
      default: return <Link size={size} />;
    }
});

const DeptCard = memo(({ dept, isActive, onClick, index }: { dept: Department, isActive: boolean, onClick: () => void, index: number }) => (
    <div 
      onClick={onClick}
      style={{ animationDelay: `${0.1 + (index * 0.05)}s` }}
      className={`
        glass-card p-5 rounded-2xl cursor-pointer 
        transition-all duration-300 
        hover:border-indigo-400/50 hover:bg-white/80 dark:hover:bg-white/10 hover:-translate-y-1 
        group relative animate-slide-up opacity-0 border border-transparent shadow-sm hover:shadow-lg
        ${isActive ? 'ring-2 ring-indigo-500 ring-offset-2 ring-offset-[#f8fafc] dark:ring-offset-[#0f172a]' : ''}
      `}
    >
      {isActive && (
        <div className="absolute top-2 right-2 w-2 h-2 bg-indigo-500 rounded-full shadow-[0_0_10px_#6366f1]"></div>
      )}
      <h3 className="font-bold text-slate-800 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-300 transition-colors mb-1">{dept.name}</h3>
      <p className="text-xs text-slate-500 dark:text-white/50 leading-relaxed min-h-[2.5rem] mb-2 line-clamp-2">{dept.description}</p>
      <div className="inline-flex items-center gap-1 bg-black/5 dark:bg-white/5 text-slate-400 dark:text-white/40 text-[10px] px-2 py-0.5 rounded-full mt-auto border border-black/5 dark:border-white/5">
         <Zap size={10} className="text-orange-400"/>
         {dept.cards.length} 个应用
      </div>
    </div>
));

const AppCard = memo(({ card, isEditMode, isSelected, onClick, onTogglePin, onDelete }: { card: LinkCard, isEditMode: boolean, isSelected: boolean, onClick: () => void, onTogglePin?: (e: React.MouseEvent) => void, onDelete?: (e: React.MouseEvent) => void }) => (
    <div 
        onClick={onClick}
        className={`
        glass-card p-4 rounded-2xl
        flex flex-col items-center text-center h-32 justify-center gap-3 
        transition-all duration-300 
        hover:-translate-y-1 hover:bg-white/90 dark:hover:bg-white/10
        group relative border border-white/60 dark:border-white/5
        shadow-sm hover:shadow-lg
        ${isEditMode ? 'border-indigo-400/50 border-dashed bg-indigo-50 dark:bg-indigo-500/10' : ''} 
        ${card.isPinned && !isEditMode ? 'border-orange-200 dark:border-orange-500/30 bg-orange-50 dark:bg-orange-500/10' : ''}
        `}
    >
        {card.isPinned && !isEditMode && (
            <div className="absolute top-2 right-2 text-orange-400 opacity-80">
                <Pin size={12} fill="currentColor" />
            </div>
        )}

        {isEditMode && (
            <div 
                className="absolute -top-2 -right-2 flex gap-1 z-50 pointer-events-auto"
                onClick={(e) => e.stopPropagation()} 
            >
                <button 
                    onClick={onTogglePin} 
                    className={`w-8 h-8 flex items-center justify-center glass-card rounded-full ${card.isPinned ? 'text-orange-400 border-orange-500/50' : 'text-slate-400 dark:text-white/40'}`}
                >
                    {card.isPinned ? <PinOff size={14} /> : <Pin size={14} />}
                </button>
                <button 
                    onClick={onDelete} 
                    className="w-8 h-8 flex items-center justify-center glass-card border-red-500/50 text-red-400 rounded-full"
                >
                    <Trash2 size={14} />
                </button>
            </div>
        )}

        <div className={`p-3 rounded-2xl transition-colors ${isEditMode ? 'bg-indigo-100 dark:bg-indigo-500/30 text-indigo-600 dark:text-indigo-200' : card.isPinned ? 'bg-orange-100 dark:bg-orange-500/20 text-orange-500 dark:text-orange-300 group-hover:bg-orange-500 group-hover:text-white' : 'bg-slate-100/50 dark:bg-white/10 text-slate-600 dark:text-white/70 group-hover:bg-indigo-500 group-hover:text-white'}`}>
            <RenderIcon name={card.iconName} size={24} />
        </div>
        <div className="w-full">
            <h4 className="font-bold text-slate-800 dark:text-white text-sm w-full truncate mb-0.5 group-hover:text-slate-900 dark:group-hover:text-white transition-colors">{card.title}</h4>
            <p className="text-[10px] text-slate-500 dark:text-white/40 w-full truncate">{card.description}</p>
        </div>
    </div>
));

// --- MAIN COMPONENT ---

const WorkbenchView: React.FC<WorkbenchViewProps> = ({ selectedDeptId, onSelectDept }) => {
  const [departments, setDepartments] = useState<Department[]>([]);
  const [isEditMode, setIsEditMode] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  
  // Card/Announcement/DeptInfo Editing
  const [editingCard, setEditingCard] = useState<Partial<LinkCard> | null>(null);
  const [editingAnnounce, setEditingAnnounce] = useState<Partial<Announcement> | null>(null);
  const [editingDeptInfo, setEditingDeptInfo] = useState<{name: string, desc: string} | null>(null);
  const [qrPayload, setQrPayload] = useState('');
  const [manualInputText, setManualInputText] = useState('');

  const [activeModal, setActiveModal] = useState<'card' | 'announce' | 'share' | 'scan' | 'deptInfo' | 'export_selector' | 'manual_scan' | null>(null);
  const [cardToDelete, setCardToDelete] = useState<string | null>(null);

  const [qrCodeUrl, setQrCodeUrl] = useState('');
  const [isGeneratingQr, setIsGeneratingQr] = useState(false);
  const [scanError, setScanError] = useState<string | null>(null);

  useEffect(() => {
    setDepartments(getStoredDepartments());
    const profile = getUserProfile();
    setUserProfile(profile);
  }, []);

  const saveDepartments = (newDepts: Department[]) => {
    setDepartments(newDepts);
    saveStoredDepartments(newDepts);
  };

  const selectedDept = departments.find(d => d.id === selectedDeptId);
  const presidium = departments.find(d => d.isTopLevel);
  const otherDepts = departments.filter(d => !d.isTopLevel);

  // --- Logic: Group Cards by Category ---
  const getGroupedCards = () => {
    if (!selectedDept) return {};
    
    // Sort by pin state first
    const sorted = [...selectedDept.cards].sort((a, b) => {
        return (b.isPinned ? 1 : 0) - (a.isPinned ? 1 : 0);
    });

    const groups: {[key: string]: LinkCard[]} = {};
    
    // Initialize common groups to ensure order
    groups['通用服务'] = [];
    groups['业务功能'] = [];

    sorted.forEach(card => {
        const cat = card.category || '默认分类';
        if (!groups[cat]) groups[cat] = [];
        groups[cat].push(card);
    });

    return groups;
  };

  const groupedCards = getGroupedCards();
  const categories = Object.keys(groupedCards).sort((a, b) => {
      // "通用服务" first, "业务功能" second, then alphabetical
      if (a === '通用服务') return -1;
      if (b === '通用服务') return 1;
      if (a === '业务功能') return -1;
      if (b === '业务功能') return 1;
      return a.localeCompare(b);
  });

  const existingCategories = selectedDept 
    ? Array.from(new Set(selectedDept.cards.map(c => c.category || '业务功能'))).filter(Boolean)
    : [];

  // --- CRUD Handlers ---
  const promptDeleteCard = (e: React.MouseEvent, cardId: string) => {
    e.preventDefault(); e.stopPropagation();
    triggerHaptic('warning');
    setTimeout(() => setCardToDelete(cardId), 10);
  };

  const confirmDeleteCard = () => {
    if (!selectedDeptId || !cardToDelete) return;
    const newDepts = departments.map(d => 
      d.id === selectedDeptId ? { ...d, cards: d.cards.filter(c => c.id !== cardToDelete) } : d
    );
    saveDepartments(newDepts);
    setCardToDelete(null);
    triggerHaptic('heavy');
  };

  const handleTogglePinCard = (deptId: string, cardId: string, e: React.MouseEvent) => {
    e.preventDefault(); e.stopPropagation();
    triggerHaptic('selection');
    const newDepts = departments.map(d => {
      if (d.id === deptId) {
        return {
          ...d,
          cards: d.cards.map(c => c.id === cardId ? { ...c, isPinned: !c.isPinned } : c)
        };
      }
      return d;
    });
    saveDepartments(newDepts);
  };

  const handleDeleteAnnounce = (deptId: string, aId: string) => {
    triggerHaptic('warning');
    if (!confirm('确定删除此公告吗？')) return;
    triggerHaptic('medium');
    const newDepts = departments.map(d => 
      d.id === deptId ? { ...d, announcements: d.announcements.filter(a => a.id !== aId) } : d
    );
    saveDepartments(newDepts);
  };

  const handleSaveCard = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDeptId || !editingCard?.title || !editingCard?.url) return;
    
    const newDepts = departments.map(d => {
      if (d.id === selectedDeptId) {
        let newCards = [...d.cards];
        if (editingCard.id) {
          newCards = newCards.map(c => c.id === editingCard.id ? editingCard as LinkCard : c);
        } else {
          newCards.push({ 
              ...editingCard, 
              id: Date.now().toString(),
              category: editingCard.category || '业务功能'
          } as LinkCard);
        }
        return { ...d, cards: newCards };
      }
      return d;
    });
    saveDepartments(newDepts);
    setActiveModal(null);
    triggerHaptic('success');
  };

  const handleSaveAnnounce = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDeptId || !editingAnnounce?.content) return;

    const newDepts = departments.map(d => {
      if (d.id === selectedDeptId) {
        let newAnns = [...d.announcements];
        const now = new Date().toISOString().split('T')[0];
        
        const publisherInfo = !editingAnnounce.id && userProfile ? {
          publisherName: userProfile.name,
          publisherPosition: userProfile.position
        } : {};

        if (editingAnnounce.id) {
           newAnns = newAnns.map(a => a.id === editingAnnounce.id ? { ...a, ...editingAnnounce } as Announcement : a);
        } else {
          newAnns.unshift({ 
            ...editingAnnounce, 
            ...publisherInfo,
            id: Date.now().toString(), 
            date: now 
          } as Announcement);
        }
        return { ...d, announcements: newAnns };
      }
      return d;
    });
    saveDepartments(newDepts);
    setActiveModal(null);
    triggerHaptic('success');
  };

  const handleSaveDeptInfo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDeptId || !editingDeptInfo) return;
    const newDepts = departments.map(d => {
      if (d.id === selectedDeptId) {
        return { ...d, name: editingDeptInfo.name, description: editingDeptInfo.desc };
      }
      return d;
    });
    saveDepartments(newDepts);
    setActiveModal(null);
    triggerHaptic('success');
  };

  const openDeptInfoEdit = () => {
    if (selectedDept) {
      triggerHaptic('medium');
      setEditingDeptInfo({ name: selectedDept.name, desc: selectedDept.description });
      setActiveModal('deptInfo');
    }
  };

  const handleShareDept = async () => {
    if (!selectedDept) return;
    triggerHaptic('medium');
    setIsGeneratingQr(true);
    try {
      const payload = {
        type: 'dept_config_v1',
        id: selectedDept.id,
        name: selectedDept.name, 
        description: selectedDept.description,
        cards: selectedDept.cards,
        announcements: selectedDept.announcements,
        timestamp: Date.now()
      };
      
      const jsonStr = JSON.stringify(payload);
      setQrPayload(jsonStr);
      const url = await generateColorCode(jsonStr);
      setQrCodeUrl(url);
      setActiveModal('share');
    } catch (e) {
      alert('生成配置码失败：数据处理错误');
    } finally {
      setIsGeneratingQr(false);
    }
  };

  const handleSaveQrImage = () => {
    if (!qrCodeUrl || !selectedDept) return;
    triggerHaptic('selection');
    setActiveModal('export_selector');
  };

  const handleScanClick = () => {
    setScanError(null);
    setActiveModal('scan');
    triggerHaptic('medium');
  };

  const processScannedData = (dataStr: string) => {
    try {
      const data = JSON.parse(dataStr);
      if (data.type !== 'dept_config_v1' || !data.id || !Array.isArray(data.cards)) {
        throw new Error('无效的部门配置数据');
      }
      const targetDeptExists = departments.some(d => d.id === data.id);
      
      if (targetDeptExists) {
        triggerHaptic('warning');
        if (confirm(`检测到部门配置：\n${data.name}\n\n包含 ${data.cards.length} 个应用，${data.announcements.length} 条公告。\n\n是否覆盖本地对应部门的数据？`)) {
            const newDepts = departments.map(d => {
              if (d.id === data.id) {
                 return {
                   ...d,
                   name: data.name || d.name,
                   description: data.description || d.description,
                   cards: data.cards,
                   announcements: data.announcements
                 };
              }
              return d;
            });
            saveDepartments(newDepts);
            alert('配置导入成功！');
            setActiveModal(null);
            triggerHaptic('success');
            return true;
        }
      } else {
        triggerHaptic('medium');
        if (confirm(`检测到新部门配置：\n${data.name}\n\n包含 ${data.cards.length} 个应用，${data.announcements.length} 条公告。\n\n是否添加该部门到您的工作台？`)) {
            const newDept: Department = {
                id: data.id,
                name: data.name,
                description: data.description || '已导入的部门',
                isTopLevel: false,
                cards: data.cards,
                announcements: data.announcements
            };
            const newDepts = [...departments, newDept];
            saveDepartments(newDepts);
            alert('新部门添加成功！');
            setActiveModal(null);
            triggerHaptic('success');
            return true;
        }
      }
    } catch (e) {
      alert('无法识别该配置码，可能是格式错误或版本不兼容');
      triggerHaptic('error');
    }
    return false;
  };

  const handlePasteImport = async () => {
    try {
        const text = await navigator.clipboard.readText();
        if (!text) throw new Error('Empty');
        triggerHaptic('success');
        processScannedData(text);
    } catch (e) {
        // Fallback to manual input
        setManualInputText('');
        setActiveModal('manual_scan');
        triggerHaptic('warning');
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    triggerHaptic('selection');
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = async () => {
        try {
           const jsonStr = await parseColorCode(img);
           processScannedData(jsonStr);
        } catch (err) {
           console.error(err);
           alert('未能识别有效的彩色配置码，请确保图片清晰且未经压缩');
           triggerHaptic('error');
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const iconList = [
    'Link', 'FileText', 'Monitor', 'Users', 
    'Calendar', 'Image', 'Briefcase', 'Zap', 
    'Coffee', 'Download', 'Clock', 'Globe', 
    'MessageCircle', 'Book', 'Cloud'
  ];

  const isRecent = (dateStr: string) => {
    const d = new Date(dateStr);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - d.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
    return diffDays <= 3;
  };

  // --- Views ---
  
  if (!selectedDeptId) {
    return (
      <div className="p-4 pt-24 pb-32 md:pb-8 animate-fade-in text-slate-800 dark:text-white">
        <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold flex items-center gap-2"><Briefcase className="text-indigo-600 dark:text-indigo-400" size={24}/> 部门导航</h2>
            <button onClick={handleScanClick} className="p-2.5 bg-white/50 dark:bg-white/10 rounded-full backdrop-blur-md border border-white/20 text-slate-700 dark:text-white hover:bg-white/20 active:scale-95 transition-transform"><ScanLine size={18} /></button>
        </div>
        
        {/* Presidium Card */}
        {presidium && (
          <div 
            onClick={() => { onSelectDept(presidium.id); triggerHaptic('light'); }}
            className="glass-card bg-gradient-to-br from-indigo-500 to-purple-600 p-6 rounded-3xl mb-8 cursor-pointer transform transition-all duration-300 hover:scale-[1.02] active:scale-95 text-always-white relative overflow-hidden animate-slide-up group border border-indigo-500/30 shadow-xl"
          >
            <div className="absolute top-0 right-0 p-8 opacity-20 transform translate-x-4 -translate-y-4 group-hover:scale-110 transition-transform">
               <Briefcase size={100} className="text-always-white" />
            </div>
            <div className="relative z-10">
              <h3 className="text-2xl font-bold mb-1 text-always-white text-glow">{presidium.name}</h3>
              <p className="text-always-white/70 text-sm mb-4 max-w-[80%]">{presidium.description}</p>
              <div className="inline-flex items-center gap-2 bg-white/20 px-3 py-1 rounded-full text-xs font-medium backdrop-blur-sm border border-white/20 text-always-white">
                <span>{presidium.cards.length} 个应用</span>
                <ArrowLeft className="rotate-180 w-3 h-3 text-always-white" />
              </div>
            </div>
          </div>
        )}

        <h4 className="text-sm font-bold text-slate-400 dark:text-white/40 uppercase tracking-wider mb-4 px-1 animate-slide-up" style={{ animationDelay: '0.1s' }}>职能部门</h4>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {otherDepts.map((dept, index) => (
            <DeptCard 
                key={dept.id} 
                dept={dept} 
                index={index}
                isActive={userProfile?.departmentId === dept.id} 
                onClick={() => { onSelectDept(dept.id); triggerHaptic('light'); }}
            />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div key={selectedDeptId} className="h-full w-full p-6 md:p-8 overflow-y-auto pb-32 animate-slide-up flex flex-col hide-scrollbar text-slate-800 dark:text-white">
      <div className="max-w-[1600px] mx-auto w-full flex-1 flex flex-col">
        
        {/* Navigation & Controls Bar */}
        <div className="flex items-center justify-between mb-4 shrink-0">
           <button onClick={() => { onSelectDept(null); triggerHaptic('light'); }} className="flex items-center gap-2 text-slate-500 dark:text-white/60 hover:text-slate-900 dark:hover:text-white transition-colors bg-white/50 dark:bg-white/10 px-4 py-2 rounded-full backdrop-blur-md border border-white/20 shadow-sm active:scale-95">
              <ArrowLeft size={18} />
              <span className="text-sm font-bold">返回</span>
           </button>
           
           <div className="flex gap-2">
                <button onClick={handleShareDept} className="p-2.5 bg-white/50 dark:bg-white/10 rounded-full backdrop-blur-md border border-white/20 text-slate-700 dark:text-white hover:bg-white/20 active:scale-95 transition-transform"><Share2 size={18} /></button>
                <button onClick={() => { setIsEditMode(!isEditMode); triggerHaptic('medium'); }} className={`px-4 py-2 rounded-full text-xs font-bold transition-colors flex items-center gap-1 backdrop-blur-md border border-white/20 active:scale-95 ${isEditMode ? 'bg-indigo-500 text-white' : 'bg-white/50 dark:bg-white/10 text-slate-700 dark:text-white'}`}>
                  {isEditMode ? <Check size={14} /> : <Edit2 size={14} />} {isEditMode ? '完成' : '管理'}
                </button>
             <button onClick={handleScanClick} className="p-2.5 bg-white/50 dark:bg-white/10 rounded-full backdrop-blur-md border border-white/20 text-slate-700 dark:text-white hover:bg-white/20 active:scale-95 transition-transform"><ScanLine size={18} /></button>
           </div>
        </div>

        {/* Department Header */}
        <div className="mb-8 shrink-0">
           <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-3 text-glow mb-3">
             <div className="p-3 bg-indigo-500/10 dark:bg-white/10 rounded-2xl text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 dark:border-white/10 shadow-sm">
                <Briefcase size={32} />
             </div>
             <div className="flex items-center gap-2">
                {selectedDept?.name}
                {isEditMode && <button onClick={openDeptInfoEdit} className="p-1 text-slate-400 dark:text-white/50 hover:text-slate-800 dark:hover:text-white"><PenLine size={18}/></button>}
             </div>
           </h2>
           <p className="text-slate-500 dark:text-white/60 text-sm md:text-base leading-relaxed pl-1 max-w-2xl">
             {selectedDept?.description}
           </p>
        </div>

        {/* Content Container */}
        <div className="space-y-8 flex-1 min-h-0">
          
          {/* Announcements Section */}
          <section className="glass-panel rounded-3xl p-5 animate-slide-up" style={{ animationDelay: '0.05s' }}>
            <div className="flex justify-between items-center mb-4 px-1 border-b border-gray-200 dark:border-white/10 pb-3">
               <h3 className="font-bold text-slate-700 dark:text-white/80 flex items-center gap-2 text-sm uppercase tracking-wide"><Megaphone size={16} className="text-indigo-500 dark:text-indigo-400"/> 部门公告</h3>
               {isEditMode && (
                 <button 
                   onClick={() => { setEditingAnnounce({ content: '', isPinned: false }); setActiveModal('announce'); triggerHaptic('medium'); }}
                   className="text-xs text-indigo-500 dark:text-indigo-300 font-medium active:scale-95"
                 >
                   + 发布
                 </button>
               )}
            </div>
            
            <div className="space-y-4">
              {selectedDept?.announcements.length === 0 && (
                 <div className="text-sm text-slate-400 dark:text-white/30 italic text-center py-6">
                    <div>暂无公告</div>
                 </div>
              )}
              {selectedDept?.announcements.map((ann, i) => (
                <div 
                   key={ann.id} 
                   style={{ animationDelay: `${0.1 + (i * 0.05)}s` }}
                   className={`relative overflow-hidden rounded-xl animate-slide-up opacity-0 transition-all duration-300 ${ann.isPinned ? 'bg-orange-50 dark:bg-orange-500/10 border border-orange-200 dark:border-orange-500/30' : 'bg-white/40 dark:bg-white/5 border border-white/20 dark:border-white/10'}`}
                >
                  <div className={`absolute left-0 top-0 bottom-0 w-1 ${ann.isPinned ? 'bg-orange-500' : 'bg-indigo-500'}`} />
                  <div className="p-3 pl-4">
                     <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-2">
                           {ann.isPinned && (
                              <span className="bg-orange-100 dark:bg-orange-500/20 text-orange-600 dark:text-orange-300 text-[10px] px-1.5 py-0.5 rounded font-bold flex items-center gap-1 border border-orange-200 dark:border-orange-500/30">
                                 <Pin size={10} fill="currentColor"/> 置顶
                              </span>
                           )}
                           {isRecent(ann.date) && !ann.isPinned && (
                              <span className="bg-red-500 text-white text-[10px] px-1.5 py-0.5 rounded font-bold shadow-lg shadow-red-500/30">NEW</span>
                           )}
                           {ann.publisherName && (
                              <span className="text-xs font-bold text-slate-500 dark:text-white/70">{ann.publisherName}</span>
                           )}
                        </div>
                        <div className="flex items-center gap-1 text-[10px] text-slate-400 dark:text-white/40">
                           <Clock size={10} />
                           {ann.date}
                        </div>
                     </div>
                     <p className="text-sm text-slate-700 dark:text-white/90 whitespace-pre-wrap leading-relaxed">
                        {ann.content}
                     </p>
                     {isEditMode && (
                       <div className="flex justify-end gap-3 mt-3 pt-3 border-t border-gray-200 dark:border-white/10">
                         <button onClick={() => { setEditingAnnounce(ann); setActiveModal('announce'); triggerHaptic('medium'); }} className="text-indigo-500 dark:text-indigo-300 hover:text-indigo-700 dark:hover:text-white text-xs flex items-center gap-1"><Edit size={12}/> 编辑</button>
                         <button onClick={() => handleDeleteAnnounce(selectedDept!.id, ann.id)} className="text-red-500 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 text-xs flex items-center gap-1"><Trash2 size={12}/> 删除</button>
                       </div>
                     )}
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Cards Section - Grouped */}
          <section className="animate-slide-up" style={{ animationDelay: '0.2s' }}>
            {categories.map((category) => {
               const cards = groupedCards[category];
               if (cards.length === 0 && !isEditMode) return null;
               
               return (
                 <div key={category} className="mb-6 last:mb-0">
                   <div className="flex justify-between items-center mb-3 px-1">
                      <h3 className="font-bold text-slate-700 dark:text-white/80 flex items-center gap-2 text-sm uppercase tracking-wide">
                          {category === '通用服务' ? <Layers size={16} className="text-blue-500 dark:text-blue-400"/> : <Zap size={16} className="text-indigo-500 dark:text-indigo-400"/>}
                          {category}
                      </h3>
                   </div>
                   <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {cards.map((card) => (
                        <AppCard
                            key={card.id}
                            card={card}
                            isEditMode={isEditMode}
                            isSelected={false}
                            onClick={() => {
                                if (isEditMode) {
                                    setEditingCard(card); setActiveModal('card'); triggerHaptic('medium');
                                } else if (card.url === '#settings') {
                                    triggerHaptic('light');
                                    window.location.hash = '#settings';
                                } else {
                                    triggerHaptic('light');
                                    window.open(card.url, '_blank');
                                }
                            }}
                            onTogglePin={(e) => handleTogglePinCard(selectedDept!.id, card.id, e)}
                            onDelete={(e) => promptDeleteCard(e, card.id)}
                        />
                      ))}
                   </div>
                 </div>
               );
            })}
            
            {isEditMode && (
               <div className="mt-6">
                  <button onClick={() => { setEditingCard({ title:'', url:'', iconName:'Link', category: '业务功能' }); setActiveModal('card'); triggerHaptic('medium'); }} className="w-full flex flex-col items-center justify-center h-32 glass-card border-dashed border-slate-300 dark:border-white/20 rounded-xl text-slate-400 dark:text-white/40 hover:border-indigo-400 hover:text-indigo-500 dark:hover:text-indigo-300 hover:bg-white/50 dark:hover:bg-white/5 transition-all gap-1 active:scale-95">
                    <Plus size={24} />
                    <span className="text-xs font-medium">添加新应用</span>
                  </button>
               </div>
            )}

          </section>
        </div>
      </div>

      {/* --- MODALS (Mostly unchanged, included for completeness) --- */}
      
      {activeModal === 'deptInfo' && (
        <ModalPortal>
           <div className="fixed inset-0 bg-black/60 z-[999] flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in" onClick={() => setActiveModal(null)}>
             <div className="glass-panel rounded-2xl w-full max-w-sm p-6 shadow-2xl text-slate-800 dark:text-white bg-white/90 dark:bg-black/40 relative" onClick={e => e.stopPropagation()}>
                <button onClick={() => setActiveModal(null)} className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors active:scale-95">
                    <X size={20} />
                </button>
                <h3 className="text-lg font-bold mb-4">编辑部门信息</h3>
                <form onSubmit={handleSaveDeptInfo} className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-xs text-slate-500 dark:text-white/50">部门名称</label>
                    <input required value={editingDeptInfo?.name} onChange={e => setEditingDeptInfo(prev => prev ? {...prev, name: e.target.value} : null)} className="w-full glass-input rounded-lg p-2.5 text-sm focus:outline-none" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs text-slate-500 dark:text-white/50">部门简介</label>
                    <textarea required rows={3} value={editingDeptInfo?.desc} onChange={e => setEditingDeptInfo(prev => prev ? {...prev, desc: e.target.value} : null)} className="w-full glass-input rounded-lg p-2.5 text-sm focus:outline-none" />
                  </div>
                  <div className="flex justify-end gap-2 mt-6">
                    <button type="button" onClick={() => setActiveModal(null)} className="px-4 py-2 text-slate-500 dark:text-white/50 hover:text-slate-800 dark:hover:text-white text-sm">取消</button>
                    <button type="submit" className="px-6 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium shadow-lg hover:bg-indigo-700">保存</button>
                  </div>
                </form>
             </div>
           </div>
        </ModalPortal>
      )}

      {(activeModal === 'card' || activeModal === 'announce') && (
        <ModalPortal>
          <div className="fixed inset-0 bg-black/60 z-[999] flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in" onClick={() => setActiveModal(null)}>
            <div className="glass-panel rounded-2xl w-full max-w-sm p-6 shadow-2xl overflow-y-auto max-h-[90vh] hide-scrollbar text-slate-800 dark:text-white bg-white/90 dark:bg-black/40 relative" onClick={e => e.stopPropagation()}>
              <button onClick={() => setActiveModal(null)} className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors active:scale-95">
                  <X size={20} />
              </button>
              <h3 className="text-lg font-bold mb-4">{activeModal === 'card' ? '编辑应用卡片' : (editingAnnounce?.id ? '编辑公告' : '发布新公告')}</h3>
              
              {activeModal === 'card' ? (
                <form onSubmit={handleSaveCard} className="space-y-4">
                   <div className="space-y-1">
                     <label className="text-xs text-slate-500 dark:text-white/50">名称</label>
                     <input required value={editingCard?.title} onChange={e => setEditingCard({...editingCard, title: e.target.value})} className="w-full glass-input rounded-lg p-2.5 text-sm focus:outline-none" placeholder="例如：宿舍报修" />
                   </div>
                   <div className="space-y-1">
                     <label className="text-xs text-slate-500 dark:text-white/50">描述</label>
                     <input value={editingCard?.description} onChange={e => setEditingCard({...editingCard, description: e.target.value})} className="w-full glass-input rounded-lg p-2.5 text-sm focus:outline-none" placeholder="简短说明功能" />
                   </div>
                   
                   <div className="space-y-1">
                     <label className="text-xs text-slate-500 dark:text-white/50">分类</label>
                     <input 
                       list="category-options" 
                       value={editingCard?.category || ''} 
                       onChange={e => setEditingCard({...editingCard, category: e.target.value})} 
                       className="w-full glass-input rounded-lg p-2.5 text-sm focus:outline-none" 
                       placeholder="例如：业务功能" 
                     />
                     <datalist id="category-options">
                        <option value="通用服务"/>
                        <option value="业务功能"/>
                        <option value="外部链接"/>
                     </datalist>
                     {existingCategories.length > 0 && (
                       <div className="flex flex-wrap gap-2 mt-2">
                         {existingCategories.map(cat => (
                           <button 
                             type="button" 
                             key={cat} 
                             onClick={() => { setEditingCard({...editingCard, category: cat}); triggerHaptic('light'); }}
                             className={`text-[10px] px-2 py-1 rounded-md border transition-colors ${editingCard?.category === cat ? 'bg-indigo-100 dark:bg-indigo-500/30 border-indigo-400 text-indigo-600 dark:text-indigo-200' : 'bg-black/5 dark:bg-white/5 border-black/10 dark:border-white/10 text-slate-500 dark:text-white/50 hover:bg-black/10 dark:hover:bg-white/10'}`}
                           >
                             {cat}
                           </button>
                         ))}
                       </div>
                     )}
                   </div>

                   <div className="space-y-1">
                     <label className="text-xs text-slate-500 dark:text-white/50">跳转链接</label>
                     <input required type="text" value={editingCard?.url} onChange={e => setEditingCard({...editingCard, url: e.target.value})} className="w-full glass-input rounded-lg p-2.5 text-sm focus:outline-none" placeholder="https://..." />
                   </div>
                   
                   <div className="space-y-2">
                     <label className="text-xs text-slate-500 dark:text-white/50">选择图标</label>
                     <div className="grid grid-cols-6 gap-2 bg-black/5 dark:bg-black/20 p-3 rounded-xl border border-black/5 dark:border-white/10">
                        {iconList.map(icon => (
                          <button 
                            key={icon} 
                            type="button" 
                            onClick={() => { setEditingCard({...editingCard, iconName: icon as any}); triggerHaptic('light'); }}
                            className={`p-2 rounded-lg flex items-center justify-center transition-all ${editingCard?.iconName === icon ? 'bg-white text-indigo-600 shadow-md scale-110' : 'text-slate-400 dark:text-white/40 hover:text-slate-800 dark:hover:text-white hover:bg-black/5 dark:hover:bg-white/10'}`}
                            title={icon}
                          >
                            <RenderIcon name={icon} size={18}/>
                          </button>
                        ))}
                     </div>
                   </div>

                   <div className="flex justify-end gap-2 mt-6"><button type="button" onClick={() => setActiveModal(null)} className="px-4 py-2 text-slate-500 dark:text-white/50 hover:text-slate-800 dark:hover:text-white text-sm">取消</button><button type="submit" className="px-6 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium shadow-lg hover:bg-indigo-700">保存</button></div>
                </form>
              ) : (
                <form onSubmit={handleSaveAnnounce} className="space-y-4">
                   <textarea required rows={5} value={editingAnnounce?.content} onChange={e => setEditingAnnounce({...editingAnnounce, content: e.target.value})} className="w-full glass-input rounded-lg p-3 text-sm focus:outline-none" placeholder="请输入公告内容..." />
                   <div className="flex items-center gap-2 bg-black/5 dark:bg-black/20 p-2 rounded-lg border border-black/5 dark:border-white/10">
                     <input type="checkbox" id="pin" checked={editingAnnounce?.isPinned} onChange={e => setEditingAnnounce({...editingAnnounce, isPinned: e.target.checked})} className="rounded text-indigo-500 focus:ring-indigo-500 bg-transparent border-gray-300 dark:border-white/30" />
                     <label htmlFor="pin" className="text-sm text-slate-700 dark:text-white/80 font-medium">置顶此公告</label>
                   </div>
                   <div className="flex justify-end gap-2 mt-4"><button type="button" onClick={() => setActiveModal(null)} className="px-4 py-2 text-slate-500 dark:text-white/50 hover:text-slate-800 dark:hover:text-white text-sm">取消</button><button type="submit" className="px-6 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium shadow-lg hover:bg-indigo-700">发布</button></div>
                </form>
              )}
            </div>
          </div>
        </ModalPortal>
      )}

      {activeModal === 'share' && (
        <ModalPortal>
          <div className="fixed inset-0 bg-black/80 z-[999] flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in" onClick={() => setActiveModal(null)}>
            <div className="glass-panel rounded-2xl p-8 max-w-sm w-full text-center shadow-2xl bg-white/95 dark:bg-black/60 relative" onClick={e => e.stopPropagation()}>
               <button onClick={() => setActiveModal(null)} className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors active:scale-95">
                   <X size={20} />
               </button>
               <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">{selectedDept?.name}</h3>
               <p className="text-slate-500 dark:text-white/50 text-sm mb-6">扫码即可同步该部门的最新配置</p>
               <div className="bg-white p-2 rounded-xl border border-gray-200 dark:border-white/20 shadow-inner inline-block mb-6 overflow-hidden">
                  {qrCodeUrl ? (
                    <img src={qrCodeUrl} alt="Dept Config QR" className="max-h-[40vh] w-auto object-contain" style={{ imageRendering: 'pixelated' }} />
                  ) : (
                    <div className="w-48 h-48 flex items-center justify-center text-gray-400 text-sm">
                        {isGeneratingQr ? '正在生成...' : '加载中'}
                    </div>
                  )}
               </div>
               <p className="text-xs text-slate-400 dark:text-white/30">包含 {selectedDept?.cards.length} 个卡片和 {selectedDept?.announcements.length} 条公告</p>
               
               <div className="flex gap-3 mt-6">
                 <button onClick={handleSaveQrImage} className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-sm active:scale-95 transition-transform flex items-center justify-center gap-2 shadow-lg shadow-indigo-500/30">
                   <Download size={18} /> 保存图片
                 </button>
                 <button onClick={() => setActiveModal(null)} className="flex-1 py-3 bg-gray-100 dark:bg-white/10 hover:bg-gray-200 dark:hover:bg-white/20 text-slate-600 dark:text-white/70 rounded-xl font-medium text-sm active:scale-95 transition-transform">
                   关闭
                 </button>
               </div>
            </div>
          </div>
        </ModalPortal>
      )}

      {activeModal === 'scan' && (
        <ModalPortal>
           <div className="fixed inset-0 bg-black/80 z-[1000] flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in" onClick={() => setActiveModal(null)}>
              <div 
                  className="glass-panel rounded-3xl p-6 md:p-8 w-full max-w-sm shadow-2xl relative bg-white/95 dark:bg-black/60 text-center flex flex-col items-center" 
                  onClick={e => e.stopPropagation()}
              >
                  <button onClick={() => setActiveModal(null)} className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors active:scale-95">
                      <X size={20} />
                  </button>
                  <div className="w-16 h-16 bg-indigo-50 dark:bg-indigo-500/20 rounded-full flex items-center justify-center mb-4 border border-indigo-100 dark:border-indigo-500/30">
                    <Layers size={32} className="text-indigo-600 dark:text-indigo-400"/>
                  </div>
                  
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                     配置同步
                  </h3>
                  <p className="text-sm text-slate-500 dark:text-white/60 mb-6 leading-relaxed">
                     支持高密度彩色配置码 (CIMBAR)<br/>请上传相册中保存的配置图片
                  </p>
                  
                  {scanError && (
                    <div className="w-full bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 rounded-xl p-3 mb-4 text-xs font-bold text-red-600 dark:text-red-300 flex items-center gap-2 justify-center">
                       <AlertTriangle size={14} /> {scanError}
                    </div>
                  )}

                  <div className="w-full space-y-3">
                      <label className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-500/30 hover:bg-indigo-700 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer">
                          <ImageIcon size={20} />
                          <span>从相册选择图片</span>
                          <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                      </label>
                      <button onClick={handlePasteImport} className="w-full py-4 bg-white dark:bg-white/10 border border-indigo-200 dark:border-white/20 text-indigo-600 dark:text-white rounded-xl font-bold hover:bg-indigo-50 dark:hover:bg-white/20 active:scale-95 transition-all flex items-center justify-center gap-2">
                          <Copy size={20} />
                          <span>粘贴文本配置</span>
                      </button>
                      <button onClick={() => setActiveModal(null)} className="w-full py-3 bg-gray-100 dark:bg-white/10 text-slate-600 dark:text-white/80 rounded-xl font-bold hover:bg-gray-200 dark:hover:bg-white/20 active:scale-95 transition-all">
                          取消
                      </button>
                  </div>
              </div>
           </div>
        </ModalPortal>
      )}

      {cardToDelete && (
        <ModalPortal>
           <div 
             className="fixed inset-0 z-[1000] flex items-center justify-center bg-black/80 backdrop-blur-sm p-6"
             onClick={() => setCardToDelete(null)}
           >
              <div 
                className="glass-panel w-full max-w-xs rounded-2xl p-6 shadow-2xl animate-slide-up transform transition-all flex flex-col items-center text-center bg-white/95 dark:bg-black/60"
                onClick={e => e.stopPropagation()}
              >
                 <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mb-4 text-red-500 animate-bounce">
                    <AlertTriangle size={32} />
                 </div>
                 <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">确认删除?</h3>
                 <p className="text-slate-500 dark:text-white/50 text-sm mb-6">此操作无法撤销，该卡片将被永久移除。</p>
                 
                 <div className="flex gap-3 w-full">
                    <button 
                      onClick={() => setCardToDelete(null)}
                      className="flex-1 py-3 bg-gray-100 dark:bg-white/10 text-slate-600 dark:text-white/70 rounded-xl font-bold active:scale-95 transition-transform hover:bg-gray-200 dark:hover:bg-white/20"
                    >
                      取消
                    </button>
                    <button 
                      onClick={confirmDeleteCard}
                      className="flex-1 py-3 bg-red-600 text-white rounded-xl font-bold shadow-lg shadow-red-500/30 active:scale-95 transition-transform"
                    >
                      删除
                    </button>
                 </div>
              </div>
           </div>
        </ModalPortal>
      )}

      {/* Export Selection Modal */}
      {activeModal === 'export_selector' && (
            <ModalPortal>
                <div className="fixed inset-0 z-[999] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setActiveModal(null)}>
                    <div className="glass-panel rounded-3xl p-6 w-full max-w-sm bg-white/95 dark:bg-black/60 shadow-2xl relative" onClick={e => e.stopPropagation()}>
                        <button onClick={() => setActiveModal(null)} className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors active:scale-95">
                            <X size={20} />
                        </button>
                        <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2 text-center">选择导出方式</h3>
                       <p className="text-sm text-slate-500 dark:text-white/60 mb-6 text-center">请根据当前设备环境选择最合适的传输方式</p>
                       
                       <div className="space-y-4">
                           {/* PC Export Option */}
                           <div className="p-4 rounded-2xl bg-indigo-50 dark:bg-indigo-500/10 border border-indigo-100 dark:border-indigo-500/20 hover:bg-indigo-100 dark:hover:bg-indigo-500/20 transition-colors cursor-pointer group"
                                onClick={() => {
                                    const link = document.createElement('a');
                                    link.href = qrCodeUrl;
                                    link.download = `${selectedDept?.name}_配置彩色码_${new Date().toLocaleDateString()}.png`;
                                    document.body.appendChild(link);
                                    link.click();
                                    document.body.removeChild(link);
                                    triggerHaptic('success');
                                }}
                           >
                               <div className="flex items-center gap-4">
                                   <div className="w-12 h-12 rounded-full bg-indigo-500 text-white flex items-center justify-center shrink-0 shadow-lg shadow-indigo-500/30 group-hover:scale-110 transition-transform">
                                       <Monitor size={24} />
                                   </div>
                                   <div className="flex-1">
                                       <h4 className="font-bold text-slate-900 dark:text-white text-base mb-1">电脑端导出</h4>
                                       <p className="text-xs text-slate-500 dark:text-white/60">下载配置码图片 (PNG)</p>
                                   </div>
                                   <div className="w-8 h-8 rounded-full bg-white dark:bg-white/10 flex items-center justify-center text-slate-400">
                                       <Download size={16}/>
                                   </div>
                               </div>
                           </div>
 
                           {/* Mobile Export Option */}
                           <div className="p-4 rounded-2xl bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 hover:border-indigo-500 dark:hover:border-indigo-400 transition-colors cursor-pointer group"
                                onClick={() => {}}
                           >
                               <details className="group">
                                   <summary className="flex items-center gap-4 list-none cursor-pointer" onClick={() => triggerHaptic('selection')}>
                                       <div className="w-12 h-12 rounded-full bg-green-500 text-white flex items-center justify-center shrink-0 shadow-lg shadow-green-500/30 group-hover:scale-110 transition-transform">
                                           <Smartphone size={24} />
                                       </div>
                                       <div className="flex-1">
                                           <h4 className="font-bold text-slate-900 dark:text-white text-base mb-1">移动端导出</h4>
                                           <p className="text-xs text-slate-500 dark:text-white/60">复制文本配置</p>
                                       </div>
                                       <div className="w-8 h-8 rounded-full bg-white dark:bg-white/10 flex items-center justify-center text-slate-400 group-open:rotate-90 transition-transform">
                                           <ArrowRight size={16}/>
                                       </div>
                                   </summary>
                                   <div className="mt-4 pt-4 border-t border-gray-100 dark:border-white/10 animate-fade-in">
                                       <p className="text-xs text-slate-500 dark:text-white/50 mb-2">请复制以下内容发送到移动设备：</p>
                                       <textarea 
                                           readOnly 
                                           value={qrPayload} 
                                           className="w-full h-32 p-3 glass-input rounded-xl text-xs font-mono mb-3 focus:outline-none resize-none"
                                           onClick={(e) => (e.target as HTMLTextAreaElement).select()}
                                       />
                                       <button 
                                           onClick={() => { navigator.clipboard.writeText(qrPayload); triggerHaptic('success'); alert('已复制到剪贴板'); }}
                                           className="w-full py-2 bg-green-500 hover:bg-green-600 text-white rounded-xl font-bold text-sm shadow-lg shadow-green-500/30 active:scale-95 transition-all flex items-center justify-center gap-2"
                                       >
                                           <Copy size={16}/> 复制文本
                                       </button>
                                   </div>
                               </details>
                           </div>
                       </div>
 
                       <button onClick={() => setActiveModal(null)} className="w-full mt-6 py-3 bg-gray-100 dark:bg-white/10 text-slate-600 dark:text-white rounded-xl font-bold hover:bg-gray-200 dark:hover:bg-white/20 transition-colors">
                           关闭
                       </button>
                   </div>
               </div>
           </ModalPortal>
       )}

      {/* Manual Scan Modal */}
      {activeModal === 'manual_scan' && (
           <ModalPortal>
               <div className="fixed inset-0 z-[1000] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setActiveModal(null)}>
                   <div className="glass-panel rounded-3xl p-6 w-full max-w-sm bg-white/95 dark:bg-black/60 shadow-2xl relative" onClick={e => e.stopPropagation()}>
                       <button onClick={() => setActiveModal(null)} className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors active:scale-95">
                           <X size={20} />
                       </button>
                       <div className="w-16 h-16 bg-indigo-50 dark:bg-indigo-500/20 rounded-full flex items-center justify-center text-indigo-500 dark:text-indigo-400 mx-auto mb-4 border border-indigo-100 dark:border-indigo-500/30">
                           <Edit2 size={32}/>
                       </div>
                       <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2 text-center">手动输入配置</h3>
                      <p className="text-sm text-slate-500 dark:text-white/60 mb-6 text-center">无法读取剪贴板，请长按下方输入框粘贴</p>
                      
                      <textarea 
                          value={manualInputText}
                          onChange={e => setManualInputText(e.target.value)}
                          placeholder="在此处粘贴配置数据..."
                          className="w-full h-40 p-4 glass-input rounded-xl text-xs font-mono mb-4 focus:outline-none resize-none"
                          autoFocus
                      />
                      
                      <div className="flex gap-3">
                          <button onClick={() => setActiveModal('scan')} className="flex-1 py-3 bg-gray-100 dark:bg-white/10 text-slate-600 dark:text-white rounded-xl font-bold hover:bg-gray-200 dark:hover:bg-white/20 transition-colors">
                              取消
                          </button>
                          <button 
                              onClick={() => {
                                  if (manualInputText) {
                                      const success = processScannedData(manualInputText);
                                      if (success) {
                                          setActiveModal(null);
                                      }
                                  }
                              }}
                              disabled={!manualInputText}
                              className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                              确认导入
                          </button>
                      </div>
                  </div>
              </div>
          </ModalPortal>
      )}

    </div>
  );
};

export default WorkbenchView;
