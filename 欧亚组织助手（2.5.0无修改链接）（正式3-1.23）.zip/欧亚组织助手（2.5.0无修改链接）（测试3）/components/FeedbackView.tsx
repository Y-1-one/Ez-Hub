
import React, { useState, useEffect } from 'react';
import { MessageSquareHeart, Bug, Lightbulb, UserCircle, Phone, QrCode, Mail, ArrowRight, Sparkles, Github, Plus, Calendar, BookOpen, Globe, MessageCircle, Cloud, Link as LinkIcon, FileText, Monitor, Users, Image as ImageIcon, Briefcase, Zap, Coffee, Download, Clock, Book } from 'lucide-react';
import { getGlobalConfig } from '../services/storageService';
import { GlobalConfig } from '../types';

const FeedbackView: React.FC = () => {
  const [config, setConfig] = useState<GlobalConfig>(getGlobalConfig());

  useEffect(() => {
    setConfig(getGlobalConfig());
  }, []);
  
  const handleOpenForm = (specificUrl?: string) => {
    window.open(specificUrl || config.feedbackUrl, '_blank');
  };

  const handleOpenGithub = () => {
    window.open(config.githubUrl, '_blank');
  };

  const handleCall = () => {
    window.location.href = `tel:${config.contactPhone.replace(/\s+/g, '')}`; 
  };

  const renderIcon = (name: string, size: number = 20, className?: string) => {
    const props = { size, className };
    switch (name) {
      case 'Lightbulb': return <Lightbulb {...props} />;
      case 'Bug': return <Bug {...props} />;
      case 'Github': return <Github {...props} />;
      case 'MessageSquareHeart': return <MessageSquareHeart {...props} />;
      case 'Plus': return <Plus {...props} />;
      case 'Calendar': return <Calendar {...props} />;
      case 'Globe': return <Globe {...props} />;
      case 'Link': return <LinkIcon {...props} />;
      default: return <Lightbulb {...props} />;
    }
  };

  return (
    <div className="h-full w-full p-6 md:p-8 overflow-y-auto pb-24 animate-fade-in flex flex-col hide-scrollbar text-slate-800 dark:text-white">
      <div className="max-w-[1600px] mx-auto w-full flex-1 flex flex-col">
        
        {/* Header */}
        <div className="mb-6 shrink-0">
           <h2 className="text-4xl font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-3 text-glow">
             <div className="p-3 bg-indigo-500/10 dark:bg-white/10 rounded-2xl text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 dark:border-white/10">
                <MessageSquareHeart size={32} />
             </div>
             意见反馈
           </h2>
           <p className="text-slate-500 dark:text-white/60 mt-2 text-lg max-w-2xl">
             您的每一条建议都是我们进步的阶梯。无论是功能吐槽还是灵感迸发，欢迎随时告诉我们。
           </p>
        </div>

        {/* Main Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1 min-h-0">
          
          {/* Left Column: Actions (5 cols) */}
          <div className="lg:col-span-5 grid grid-cols-2 lg:flex lg:flex-col gap-4 lg:gap-4">
            {/* Feature Request */}
            <div 
              onClick={() => handleOpenForm(config.feedbackCard1.url)}
              className="glass-card flex-1 bg-gradient-to-br from-orange-50 dark:from-orange-500/20 to-white dark:to-orange-600/10 rounded-[2rem] p-5 lg:p-6 cursor-pointer group hover:shadow-xl hover:shadow-orange-500/20 transition-all duration-300 relative overflow-hidden min-h-[11rem] h-auto border-orange-200 dark:border-orange-500/30"
            >
               <div className="absolute top-0 right-0 p-4 lg:p-6 opacity-10 group-hover:scale-110 transition-transform duration-500">
                  {renderIcon(config.feedbackCard1.iconName || 'Lightbulb', 80, "text-orange-400 lg:w-[100px] lg:h-[100px]")}
               </div>
               <div className="relative z-10 h-full flex flex-col justify-between">
                  <div>
                    <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-2xl bg-orange-100 dark:bg-orange-500/20 text-orange-500 dark:text-orange-400 flex items-center justify-center shadow-sm mb-3 lg:mb-4 group-hover:rotate-12 transition-transform border border-orange-200 dark:border-orange-500/30">
                        {renderIcon(config.feedbackCard1.iconName || 'Lightbulb', 20, "lg:w-6 lg:h-6")}
                    </div>
                    <h3 className="text-lg lg:text-xl font-bold text-slate-900 dark:text-white mb-1">{config.feedbackCard1.title}</h3>
                    <p className="text-xs lg:text-sm text-slate-500 dark:text-white/60 line-clamp-2">{config.feedbackCard1.subtitle}</p>
                  </div>
                  <div className="flex items-center gap-1 lg:gap-2 text-orange-500 dark:text-orange-400 font-bold mt-4 lg:mt-6 text-xs lg:text-sm">
                     填写表单 <ArrowRight size={14} className="lg:w-4 lg:h-4 group-hover:translate-x-2 transition-transform"/>
                  </div>
               </div>
            </div>

            {/* Bug Report */}
            <div 
              onClick={() => handleOpenForm(config.feedbackCard2.url)}
              className="glass-card flex-1 bg-gradient-to-br from-red-50 dark:from-red-500/20 to-white dark:to-red-600/10 rounded-[2rem] p-5 lg:p-6 cursor-pointer group hover:shadow-xl hover:shadow-red-500/20 transition-all duration-300 relative overflow-hidden min-h-[11rem] h-auto border-red-200 dark:border-red-500/30"
            >
               <div className="absolute top-0 right-0 p-4 lg:p-6 opacity-10 group-hover:scale-110 transition-transform duration-500">
                  {renderIcon(config.feedbackCard2.iconName || 'Bug', 80, "text-red-400 lg:w-[100px] lg:h-[100px]")}
               </div>
               <div className="relative z-10 h-full flex flex-col justify-between">
                  <div>
                    <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-2xl bg-red-100 dark:bg-red-500/20 text-red-500 dark:text-red-400 flex items-center justify-center shadow-sm mb-3 lg:mb-4 group-hover:-rotate-12 transition-transform border border-red-200 dark:border-red-500/30">
                        {renderIcon(config.feedbackCard2.iconName || 'Bug', 20, "lg:w-6 lg:h-6")}
                    </div>
                    <h3 className="text-lg lg:text-xl font-bold text-slate-900 dark:text-white mb-1">{config.feedbackCard2.title}</h3>
                    <p className="text-xs lg:text-sm text-slate-500 dark:text-white/60 line-clamp-2">{config.feedbackCard2.subtitle}</p>
                  </div>
                  <div className="flex items-center gap-1 lg:gap-2 text-red-500 dark:text-red-400 font-bold mt-4 lg:mt-6 text-xs lg:text-sm">
                     立即反馈 <ArrowRight size={14} className="lg:w-4 lg:h-4 group-hover:translate-x-2 transition-transform"/>
                  </div>
               </div>
            </div>

            {/* GitHub Project - Adaptive Light/Dark Mode */}
            <div 
              onClick={handleOpenGithub}
              className="glass-card col-span-2 lg:col-span-1 flex-1 bg-gradient-to-br from-slate-100 to-slate-200 dark:from-gray-800/80 dark:to-black/80 rounded-[2rem] p-5 lg:p-6 cursor-pointer group hover:shadow-xl hover:shadow-slate-300/50 dark:hover:shadow-white/10 transition-all duration-300 relative overflow-hidden h-32 lg:h-auto border border-slate-200 dark:border-white/10"
            >
               <div className="absolute top-0 right-0 p-4 lg:p-6 opacity-5 dark:opacity-20 group-hover:scale-110 transition-transform duration-500">
                  {renderIcon(config.githubCard.iconName || 'Github', 80, "text-slate-900 dark:text-white lg:w-[100px] lg:h-[100px]")}
               </div>
               <div className="relative z-10 h-full flex flex-row lg:flex-col items-center lg:items-start justify-between">
                  <div className="flex items-center lg:block gap-4">
                    <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-2xl bg-white dark:bg-white/10 text-slate-900 dark:text-white flex items-center justify-center shadow-sm mb-0 lg:mb-4 border border-slate-200 dark:border-white/10">
                        {renderIcon(config.githubCard.iconName || 'Github', 20, "lg:w-6 lg:h-6")}
                    </div>
                    <div>
                        <h3 className="text-lg lg:text-xl font-bold text-slate-900 dark:text-white mb-1">{config.githubCard.title}</h3>
                        <p className="text-xs lg:text-sm text-slate-500 dark:text-gray-400">{config.githubCard.subtitle}</p>
                    </div>
                  </div>
                  <div className="text-right lg:text-left">
                     <div className="flex items-center justify-end lg:justify-start gap-1 lg:gap-2 text-slate-900 dark:text-white font-bold text-xs lg:text-sm">
                        查看代码 <ArrowRight size={14} className="lg:w-4 lg:h-4 group-hover:translate-x-2 transition-transform"/>
                     </div>
                     <p className="text-[10px] text-slate-400 dark:text-gray-500 mt-1">*需要科学上网</p>
                  </div>
               </div>
            </div>
          </div>

          {/* Right Column: Contact (7 cols) */}
          <div className="lg:col-span-7 h-full">
            <div className="glass-panel rounded-[2rem] p-6 md:p-8 h-full flex flex-col relative overflow-hidden bg-white/50 dark:bg-white/5">
               {/* Background decoration */}
               <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-indigo-500 rounded-full blur-3xl -mr-20 -mt-20 opacity-10 dark:opacity-20 pointer-events-none"></div>

               <div className="relative z-10">
                  <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-6 flex items-center gap-3">
                    <UserCircle className="text-indigo-500 dark:text-indigo-400" size={28}/> 
                    联系管理员
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                     <div className="space-y-6">
                        <p className="text-slate-600 dark:text-white/60 leading-relaxed text-sm">
                           如果您遇到紧急问题，或者希望与我们进行更深入的技术交流，可以通过以下方式直接联系欧亚学促会技术部。
                        </p>
                        
                        <div onClick={handleCall} className="flex items-center gap-4 p-4 rounded-2xl bg-white/60 dark:bg-white/5 hover:bg-white/80 dark:hover:bg-white/10 cursor-pointer active:scale-95 transition-all group border border-white/60 dark:border-white/10 hover:border-indigo-400/50">
                           <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-white/10 flex items-center justify-center shadow-sm text-green-600 dark:text-green-400 group-hover:scale-110 transition-transform">
                              <Phone size={20} />
                           </div>
                           <div>
                              <div className="text-xs text-slate-400 dark:text-white/40 mb-0.5 uppercase tracking-wider">Emergency Call</div>
                              <div className="font-bold text-slate-800 dark:text-white text-lg font-mono group-hover:text-indigo-600 dark:group-hover:text-indigo-300 transition-colors">{config.contactPhone}</div>
                           </div>
                        </div>
                     </div>

                     <div className="flex flex-col items-center justify-center bg-white/40 dark:bg-white/5 rounded-2xl p-6 border-2 border-dashed border-slate-300 dark:border-white/10 text-center overflow-hidden">
                        <div className="bg-white p-2 rounded-xl shadow-sm mb-3">
                           {config.contactQrCode ? (
                               <img src={config.contactQrCode} className="w-[100px] h-[100px] object-contain" />
                           ) : (
                               <QrCode size={100} className="text-black"/>
                           )}
                        </div>
                        <h4 className="font-bold text-slate-900 dark:text-white mb-1 text-sm">企业微信</h4>
                        <p className="text-xs text-slate-500 dark:text-white/50">扫码添加管理员，进行一对一沟通</p>
                     </div>
                  </div>
               </div>
               
               {/* Footer Decoration */}
               <div className="mt-auto pt-8 flex items-center gap-2 text-slate-400 dark:text-white/30 text-xs font-medium">
                  <Sparkles size={14}/>
                  <span>Powered by Eurasia Humanities Education School</span>
               </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default FeedbackView;
