
import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { User, Edit2, Camera, Download, Upload, LogOut, QrCode, ScanLine, X, Check, Shield, Image as ImageIcon, Database, ArrowRight, RefreshCw, Layers, Lock, Unlock, FileCheck, Eye, EyeOff, AlertCircle, Terminal, Heart, Calendar, Moon, Sun, Vibrate, Smartphone, Smile, ArrowDown, Cpu, Fingerprint, AlertTriangle, Command, Radio, Users, Siren, Key, Copy, Share2, Timer, Zap, History, Sparkles, HelpCircle, Globe, Phone, Code, BookOpen, Layout, Building2, CalendarPlus, ArrowUpRight, Lightbulb, Bug, Github, Link as LinkIcon, FileText, Monitor, Briefcase, Coffee, Clock, MessageCircle, Book, Cloud, Compass, Feather, Type, GitCommit, PlayCircle, Plus, Trash2 } from 'lucide-react';
import { AppSettings, UserProfile, Department, UserIdentity, GlobalConfig } from '../types';
import { getStoredSettings, saveStoredSettings, getUserProfile, saveUserProfile, getStoredDepartments, saveStoredDepartments, getAllData, importAllData, clearUserProfile, getGlobalConfig, saveGlobalConfig, getExportData, ACCOUNT_PREFIX, compressImage, switchAccount } from '../services/storageService';
import { generateColorCode, packageData, parseColorCode, unpackageData } from '../services/cimbarService';
import { triggerHaptic } from '../services/hapticService';
import { COLLEGES } from './OnboardingView';
import CryptoJS from 'crypto-js';

// Secret key for HMAC signature simulation
const APP_SECRET = "eurasia_growth_engine_v1_secret_salt";

const DEFAULT_LEGACY_MSG = "薪火相传，生生不息。愿你带领大家，奔赴更远的星辰大海。";

// Helper for Portals
const ModalPortal = ({ children }: { children?: React.ReactNode }) => {
  return createPortal(
    children,
    document.body
  );
};

interface SettingsViewProps {
  onThemeChange?: (mode: 'system' | 'light' | 'dark') => void;
}

const SettingsView: React.FC<SettingsViewProps> = ({ onThemeChange }) => {
  // Settings State
  const [settings, setSettings] = useState<AppSettings>(getStoredSettings());
  
  // Profile State
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [departments, setDepartments] = useState<Department[]>(getStoredDepartments());
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editName, setEditName] = useState('');
  const [editDeptId, setEditDeptId] = useState('');
  const [editPosition, setEditPosition] = useState('');
  const [editAvatar, setEditAvatar] = useState('');
  const [editBirthday, setEditBirthday] = useState('');
  
  // Expanded Org Fields
  const [editCollege, setEditCollege] = useState('');
  const [editOrgName, setEditOrgName] = useState('');
  const [useStandardOrgFormat, setUseStandardOrgFormat] = useState(true); // Toggle for naming convention
  
  // Global Config Edit State
  const [globalConfig, setGlobalConfig] = useState<GlobalConfig>(getGlobalConfig());
  const [editGlobalConfig, setEditGlobalConfig] = useState<GlobalConfig>(getGlobalConfig());
  const [globalConfigTab, setGlobalConfigTab] = useState<'basic' | 'cards' | 'guide'>('basic');

  // --- Admin Console States
  const [activeModal, setActiveModal] = useState<'export_cimbar' | 'import_cimbar' | 'export_file' | 'import_file_decrypt' | 'logout_joke' | 'admin_grant' | 'restore_identity' | 'version_info' | 'global_edit' | 'help_admin' | 'help_security' | 'export_selector' | 'manual_import' | 'dept_manage' | 'dept_edit' | null>(null);
  
  // Department Management State
  const [editDept, setEditDept] = useState<Department | null>(null);
  
  // Manual Input State
  const [manualInputText, setManualInputText] = useState('');

  // Loading States for Async Operations
  const [isCompressingAvatar, setIsCompressingAvatar] = useState(false);
  const [isCompressingQr, setIsCompressingQr] = useState(false);
  const [isProcessingImport, setIsProcessingImport] = useState(false);

  // Sync Global Config when Modal Opens
  useEffect(() => {
    if (activeModal === 'global_edit') {
        setEditGlobalConfig(globalConfig);
    }
  }, [activeModal, globalConfig]);
  
  // Permission Granting State
  const [grantTargetId, setGrantTargetId] = useState('');
  const [grantRole, setGrantRole] = useState<UserIdentity>('temp_admin');
  const [grantMessage, setGrantMessage] = useState(''); // Legacy Message
  const [authQrUrl, setAuthQrUrl] = useState('');
  const [authExpiry, setAuthExpiry] = useState<number>(0);
  const [isRitualAnim, setIsRitualAnim] = useState(false); // For the "Ceremony"
  const [ritualStep, setRitualStep] = useState(0);
  const [isIdError, setIsIdError] = useState(false); // For Shake Animation

  // Failure Recovery State
  const [failureCode, setFailureCode] = useState('');
  const [generatedFailureCode, setGeneratedFailureCode] = useState('');

  // Encryption State (Shared)
  const [exportPassword, setExportPassword] = useState('');
  const [useEncryption, setUseEncryption] = useState(false);
  
  // Export Selection State
  const [pendingExportData, setPendingExportData] = useState('');
  const [pendingExportImage, setPendingExportImage] = useState('');
  const [pendingExportFilename, setPendingExportFilename] = useState('');
  const [pendingExportType, setPendingExportType] = useState<'cimbar' | 'auth' | 'file' | 'recovery'>('cimbar');
  
  // CIMBAR Export State
  const [cimbarImage, setCimbarImage] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  // Refined Scope: 'full' (Everything) | 'profile_only' (User+Todos) | 'global_only' (Depts+GlobalConfig - User)
  const [exportScope, setExportScope] = useState<'full' | 'profile_only' | 'global_only'>('full');

  // Import State (Shared)
  const [importStep, setImportStep] = useState<'upload' | 'decrypt' | 'confirm' | 'auth_check' | 'legacy_reveal'>('upload');
  const [importFileUrl, setImportFileUrl] = useState<string>('');
  const [importPassword, setImportPassword] = useState('');
  const [pendingData, setPendingData] = useState<string>(''); 
  const [parsedData, setParsedData] = useState<any>(null); 
  const [importError, setImportError] = useState<string | null>(null);
  const [authVerifyStatus, setAuthVerifyStatus] = useState<string>('');

  const fileImportRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    saveStoredSettings(settings);
    if (onThemeChange) {
       onThemeChange(settings.themeMode);
    }
  }, [settings]);

  useEffect(() => {
    const p = getUserProfile();
    setProfile(p);
    if (p) {
      setEditName(p.name);
      setEditDeptId(p.departmentId);
      setEditPosition(p.position);
      setEditAvatar(p.avatar);
      setEditBirthday(p.birthday || '');
      setEditCollege(p.college || '人文教育学院');
      
      // Smart Org Name Parsing
      let currentOrg = p.organization || '西安欧亚学院人文教育学院学生成长促进会';
      const isStandard = currentOrg.startsWith('西安欧亚学院');
      setUseStandardOrgFormat(isStandard);

      if (isStandard) {
          // Attempt to strip school prefix
          currentOrg = currentOrg.replace('西安欧亚学院', '');
          // Attempt to strip college prefix if present
          if (p.college && currentOrg.startsWith(p.college)) {
              currentOrg = currentOrg.replace(p.college, '');
          }
      }
      setEditOrgName(currentOrg);
    }
  }, []);

  const changeTheme = (mode: 'system' | 'light' | 'dark') => {
    setSettings(prev => ({ ...prev, themeMode: mode }));
    triggerHaptic('selection');
  };

  const changeHapticIntensity = (level: number) => {
    setSettings(prev => ({ ...prev, hapticIntensity: level }));
    saveStoredSettings({ ...settings, hapticIntensity: level });
    setTimeout(() => {
        if (level > 0) triggerHaptic('medium');
    }, 100);
  };

  const handleCopyUserId = () => {
      if (profile?.userId) {
          navigator.clipboard.writeText(profile.userId);
          triggerHaptic('success');
          alert('个人编号已复制');
      }
  };

  // --- Profile Logic ---
  const handleProfileFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsCompressingAvatar(true);
      try {
          const compressed = await compressImage(file, 300, 0.7);
          setEditAvatar(compressed);
      } catch (err) {
          alert('图片处理失败');
      } finally {
          setIsCompressingAvatar(false);
      }
    }
  };

  const handleSaveProfile = () => {
    if (!editName || !editDeptId) return;
    
    // Construct Org Name based on format choice
    const fullOrgName = useStandardOrgFormat 
        ? `西安欧亚学院${editCollege}${editOrgName}`
        : editOrgName;

    const newProfile: UserProfile = { 
      ...profile,
      name: editName, 
      departmentId: editDeptId, 
      position: editPosition, 
      avatar: editAvatar,
      birthday: editBirthday,
      college: editCollege,
      organization: fullOrgName,
      registerDate: profile?.registerDate || new Date().toISOString().split('T')[0],
      identity: profile?.identity || 'user', 
      userId: profile?.userId
    };
    saveUserProfile(newProfile);
    setProfile(newProfile);
    setIsEditingProfile(false);
    triggerHaptic('success');
  };

  const handleLogout = () => {
    triggerHaptic('medium');
    setActiveModal('logout_joke');
  };

  const profileDeptName = departments.find(d => d.id === profile?.departmentId)?.name || '未设置';

  const getIdentityLabel = (id: UserIdentity) => {
    switch(id) {
      case 'permanent_admin': return '永久管理员';
      case 'long_term_admin': return '长期管理员';
      case 'temp_admin': return '临时管理员';
      default: return '普通成员';
    }
  };

  const getIdentityColor = (id: UserIdentity) => {
    switch(id) {
      case 'permanent_admin': return 'bg-amber-100 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-500/30'; 
      case 'long_term_admin': return 'bg-blue-100 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-500/30'; 
      case 'temp_admin': return 'bg-green-100 dark:bg-green-500/20 text-green-600 dark:text-green-400 border-green-200 dark:border-green-500/30'; 
      default: return 'bg-slate-500/10 text-slate-500 dark:text-slate-400 border-slate-500/20';
    }
  };

  const isAdmin = (id?: UserIdentity) => {
      return id === 'permanent_admin' || id === 'long_term_admin' || id === 'temp_admin';
  };

  // --- Admin Logic: Global Config ---
  const handleSaveGlobalConfig = () => {
      saveGlobalConfig(editGlobalConfig);
      setGlobalConfig(editGlobalConfig);
      setActiveModal(null);
      triggerHaptic('success');
      alert('全局配置已更新');
  };

  const handleQrUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          setIsCompressingQr(true);
          try {
              // QRs need higher quality than avatars
              const compressed = await compressImage(file, 600, 0.8);
              setEditGlobalConfig(prev => ({ ...prev, contactQrCode: compressed }));
          } catch (err) {
              alert('图片上传失败');
          } finally {
              setIsCompressingQr(false);
          }
      }
  };

  const renderIcon = (name: string, size: number = 16) => {
    const props = { size };
    switch (name) {
      case 'CalendarPlus': return <CalendarPlus {...props} />;
      case 'ArrowUpRight': return <ArrowUpRight {...props} />;
      case 'Lightbulb': return <Lightbulb {...props} />;
      case 'Bug': return <Bug {...props} />;
      case 'Github': return <Github {...props} />;
      case 'Calendar': return <Calendar {...props} />;
      case 'BookOpen': return <BookOpen {...props} />;
      case 'Globe': return <Globe {...props} />;
      case 'Link': return <LinkIcon {...props} />;
      case 'FileText': return <FileText {...props} />;
      case 'Monitor': return <Monitor {...props} />;
      case 'Users': return <Users {...props} />;
      case 'Image': return <ImageIcon {...props} />;
      case 'Briefcase': return <Briefcase {...props} />;
      case 'Zap': return <Zap {...props} />;
      case 'Coffee': return <Coffee {...props} />;
      case 'Download': return <Download {...props} />;
      case 'Clock': return <Clock {...props} />;
      case 'MessageCircle': return <MessageCircle {...props} />;
      case 'Book': return <Book {...props} />;
      case 'Cloud': return <Cloud {...props} />;
      case 'Plus': return <ArrowRight {...props} />; // Using Plus/Arrow for default
      default: return <LinkIcon {...props} />;
    }
  };

  const iconOptions = [
    'CalendarPlus', 'ArrowUpRight', 'Lightbulb', 'Bug', 'Github', 
    'Calendar', 'BookOpen', 'Globe', 'Link', 'FileText', 
    'Monitor', 'Users', 'Image', 'Briefcase', 'Zap', 
    'Coffee', 'Download', 'Clock', 'MessageCircle', 'Book', 'Cloud'
  ];

  // Component for picking icons in the global config
  // FIX: Use React Portal to prevent cutoff in overflow-y-auto modal
  const IconPicker = ({ value, onChange }: { value: string, onChange: (val: string) => void }) => {
      const [isOpen, setIsOpen] = useState(false);
      const triggerRef = useRef<HTMLButtonElement>(null);
      const [dropdownStyle, setDropdownStyle] = useState<React.CSSProperties>({});

      const toggleDropdown = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (!isOpen && triggerRef.current) {
            const rect = triggerRef.current.getBoundingClientRect();
            // Calculate position to show below button, accounting for scroll
            const top = rect.bottom + window.scrollY + 5;
            const left = rect.left + window.scrollX;
            
            // Check if it goes off screen bottom
            const windowHeight = window.innerHeight;
            const dropdownHeight = 220; // Approx height
            
            let finalTop = top;
            if (rect.bottom + dropdownHeight > windowHeight) {
                // Show above if not enough space
                finalTop = rect.top + window.scrollY - dropdownHeight - 5;
            }

            setDropdownStyle({
                position: 'fixed',
                top: finalTop,
                left: left,
                zIndex: 99999, // Ensure on top of everything
                width: '260px'
            });
        }
        setIsOpen(!isOpen);
      };

      // Close when clicking outside
      useEffect(() => {
          const handleClickOutside = () => setIsOpen(false);
          if (isOpen) {
              window.addEventListener('click', handleClickOutside);
          }
          return () => window.removeEventListener('click', handleClickOutside);
      }, [isOpen]);

      return (
          <>
              <button 
                ref={triggerRef}
                onClick={toggleDropdown}
                className="p-2 border border-slate-200 dark:border-white/10 rounded-lg flex items-center gap-2 bg-white dark:bg-white/5 hover:bg-slate-50 dark:hover:bg-white/10"
              >
                  {renderIcon(value)}
                  <span className="text-xs text-slate-500">{value}</span>
              </button>
              
              {isOpen && createPortal(
                  <div 
                    style={dropdownStyle}
                    className="bg-white dark:bg-gray-800 border border-slate-200 dark:border-white/10 rounded-xl shadow-2xl p-2 grid grid-cols-5 gap-1 animate-fade-in"
                    onClick={(e) => e.stopPropagation()}
                  >
                      {iconOptions.map(icon => (
                          <button 
                            key={icon}
                            onClick={() => { onChange(icon); setIsOpen(false); }}
                            className={`p-2 rounded-lg flex justify-center hover:bg-slate-100 dark:hover:bg-white/10 ${value === icon ? 'bg-indigo-50 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-300' : 'text-slate-500 dark:text-slate-400'}`}
                            title={icon}
                          >
                              {renderIcon(icon, 18)}
                          </button>
                      ))}
                  </div>,
                  document.body
              )}
          </>
      );
  };

  // --- Admin Logic: Department Management ---
  const handleSaveDept = () => {
      if (!editDept || !editDept.name) return;
      
      let newDepts = [...departments];
      if (editDept.id === 'NEW') {
          // Create New
          const newId = `dept_${Date.now()}`; // Simple ID generation
          const newDeptItem: Department = {
              ...editDept,
              id: newId,
              cards: [], // Default empty
              announcements: []
          };
          newDepts.push(newDeptItem);
      } else {
          // Update Existing
          const idx = newDepts.findIndex(d => d.id === editDept.id);
          if (idx !== -1) {
              newDepts[idx] = { ...newDepts[idx], ...editDept };
          }
      }
      
      saveStoredDepartments(newDepts);
      setDepartments(newDepts);
      setActiveModal('dept_manage'); // Go back to list
      triggerHaptic('success');
  };

  const handleDeleteDept = (id: string) => {
      if (confirm('确定要删除该部门吗？此操作不可逆，且会影响该部门下的所有成员。')) {
          const newDepts = departments.filter(d => d.id !== id);
          saveStoredDepartments(newDepts);
          setDepartments(newDepts);
          triggerHaptic('heavy');
      }
  };

  // --- Admin Logic: Permission Granting ---
  const handleOpenGrantModal = () => {
      setGrantTargetId('');
      setGrantRole('temp_admin');
      setGrantMessage('');
      setAuthQrUrl('');
      setIsIdError(false);
      setActiveModal('admin_grant');
      triggerHaptic('medium');
  };

  const handleGenerateAuthQr = async () => {
      // 1. Validation with Feedback
      const idRegex = /^[A-Za-z0-9+/=]{16}$/;
      if (!grantTargetId || !idRegex.test(grantTargetId)) {
          setIsIdError(true);
          triggerHaptic('error');
          setTimeout(() => setIsIdError(false), 500); // Reset shake animation
          return;
      }
      
      setIsRitualAnim(true);
      setRitualStep(0);
      triggerHaptic('heavy');

      // Ritual Animation Sequence
      setTimeout(() => { setRitualStep(1); triggerHaptic('light'); }, 1000); // "Connecting..."
      setTimeout(() => { setRitualStep(2); triggerHaptic('medium'); }, 2000); // "Encrypting..."
      setTimeout(() => { setRitualStep(3); triggerHaptic('heavy'); }, 3000); // "Forging Token..."
      
      setTimeout(async () => {
          setIsGenerating(true);
          const timestamp = Date.now();
          const isInheritance = grantRole === 'long_term_admin';
          
          const authPayload = {
              type: 'auth_token',
              sender_uid: profile?.userId, // Include sender ID for recovery
              target_uid: grantTargetId,
              role: grantRole,
              msg: grantMessage || DEFAULT_LEGACY_MSG, // Include message
              iat: timestamp,
              exp: timestamp + (10 * 60 * 1000), 
              inheriting: isInheritance
          };
          
          const signature = CryptoJS.HmacSHA256(JSON.stringify(authPayload), APP_SECRET).toString();
          const finalPayload = { ...authPayload, sig: signature };
          setPendingExportData(JSON.stringify(finalPayload));
          
          try {
              const qrUrl = await generateColorCode(JSON.stringify(finalPayload));
              setAuthQrUrl(qrUrl);
              setAuthExpiry(finalPayload.exp);
              triggerHaptic('success');
          } catch (e) {
              alert('生成凭证失败');
          } finally {
              setIsGenerating(false);
              setIsRitualAnim(false);
          }
      }, 3500);
  };

  const handleDownloadAuthQr = () => {
    if (!authQrUrl) return;
    setPendingExportImage(authQrUrl);
    setPendingExportFilename(`eurasia_auth_${grantRole}_${new Date().toISOString().split('T')[0]}.png`);
    setPendingExportType('auth');
    setActiveModal('export_selector');
    triggerHaptic('selection');
  };

  // --- Admin Logic: Downgrade after Inheritance ---
  const handleDowngradeAfterTransfer = () => {
      if (!profile) return;
      if (profile.identity === 'permanent_admin') {
          alert('永久管理员身份无法降级。');
          return;
      }
      if (confirm('确认交接完成？此操作将立即移除您的管理员权限。')) {
          const newProfile = { ...profile, identity: 'user' as UserIdentity };
          saveUserProfile(newProfile);
          setProfile(newProfile);
          setActiveModal(null);
          triggerHaptic('heavy');
          alert('卸任成功，感谢您的付出。');
          window.location.reload();
      }
  };

  // --- Backup Logic (File) ---
  const handleExportJSON = () => {
    try {
        triggerHaptic('selection');
        // Retrieve all data according to scope, including all accounts
        const data = getExportData(exportScope);

        const payloadStr = packageData(data, useEncryption ? exportPassword : undefined);
        
        setPendingExportData(payloadStr);
        setPendingExportFilename(`eurasia_backup_${exportScope}_${new Date().toISOString().split('T')[0]}.json`);
        setPendingExportType('file');
        setActiveModal('export_selector');
        triggerHaptic('selection');
    } catch (e) {
        alert('导出失败');
        console.error(e);
    }
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        try {
            const payload = JSON.parse(content);
            if (payload.h && payload.t) {
                setPendingData(content);
                if (payload.e) {
                   setImportPassword('');
                   setImportError(null);
                   setActiveModal('import_file_decrypt');
                } else {
                   try {
                     const finalData = unpackageData(content);
                     if (confirm('导入将覆盖当前所有数据，确定继续吗？')) {
                        importAllData(finalData);
                        alert('数据恢复成功，即将刷新页面');
                        window.location.reload();
                     }
                   } catch (err) {
                     alert('数据校验失败 (MD5 Mismatch)');
                   }
                }
            } else {
                if (confirm('检测到旧版备份格式，导入将覆盖当前所有数据，确定继续吗？')) {
                    importAllData(payload);
                    alert('数据恢复成功，即将刷新页面');
                    window.location.reload();
                }
            }
        } catch (err) {
            alert('文件格式错误');
        }
      } catch (err) {
        alert('读取文件失败');
      }
    };
    reader.readAsText(file);
    if (fileImportRef.current) fileImportRef.current.value = '';
  };

  const handleDecryptFile = () => {
      try {
          const finalData = unpackageData(pendingData, importPassword);
          if (confirm('密码正确！导入将覆盖当前所有数据，确定继续吗？')) {
             importAllData(finalData);
             alert('数据恢复成功，即将刷新页面');
             window.location.reload();
          }
      } catch (e: any) {
          triggerHaptic('error');
          setImportError('密码错误或数据损坏');
      }
  };

  // --- CIMBAR Export Logic ---
  const handleGenerateCimbar = async () => {
    setIsGenerating(true);
    triggerHaptic('medium');
    try {
        // Retrieve all data according to scope, including all accounts
        const data = getExportData(exportScope);

        const packageStr = packageData(data, useEncryption ? exportPassword : undefined);
        setPendingExportData(packageStr);
        const dataUrl = await generateColorCode(packageStr);
        setCimbarImage(dataUrl);
        triggerHaptic('success');
    } catch (e) {
        alert('生成失败');
        console.error(e);
    } finally {
        setIsGenerating(false);
    }
  };

  const handleDownloadCimbar = () => {
    if (!cimbarImage) return;
    setPendingExportImage(cimbarImage);
    setPendingExportFilename(`eurasia_${exportScope}_cimbar.png`);
    setPendingExportType('cimbar');
    setActiveModal('export_selector');
    triggerHaptic('selection');
  };

  // --- CIMBAR Import Logic ---
  const processImportText = (jsonStr: string) => {
      try {
         // Check if it's an Auth Token First
         try {
             const potentialAuth = JSON.parse(jsonStr);
             if (potentialAuth.type === 'auth_token') {
                 handleVerifyAuthToken(potentialAuth);
                 return;
             }
         } catch (e) {}

         setPendingData(jsonStr);
         triggerHaptic('success');
         
         const payload = JSON.parse(jsonStr);
         if (payload.e) {
             setImportStep('decrypt');
         } else {
             try {
                const finalData = unpackageData(jsonStr);
                setParsedData(finalData);
                setImportStep('confirm');
             } catch (err) {
                setImportError('数据完整性校验失败 (MD5 mismatch)');
                triggerHaptic('error');
             }
         }
         // Close manual modal if open
         if (activeModal === 'manual_import') {
             setActiveModal('import_cimbar'); 
         }
      } catch (e) {
         console.error(e);
         setImportError('无效的数据格式');
         triggerHaptic('error');
      }
  };

  const handlePasteImport = async () => {
      try {
          const text = await navigator.clipboard.readText();
          if (!text) throw new Error('Empty');
          processImportText(text);
      } catch (e) {
          // Fallback to manual input
          setManualInputText('');
          setActiveModal('manual_import');
          triggerHaptic('warning');
      }
  };

  const handleCimbarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      
      const url = URL.createObjectURL(file);
      setImportFileUrl(url);
      setImportError(null);
      setIsProcessingImport(true);

      const img = new Image();
      img.onload = async () => {
          try {
             const jsonStr = await parseColorCode(img);
             
             // Check if it's an Auth Token First
             try {
                 const potentialAuth = JSON.parse(jsonStr);
                 if (potentialAuth.type === 'auth_token') {
                     handleVerifyAuthToken(potentialAuth);
                     return;
                 }
             } catch (e) {}

             setPendingData(jsonStr);
             triggerHaptic('success');
             
             const payload = JSON.parse(jsonStr);
             if (payload.e) {
                 setImportStep('decrypt');
             } else {
                 try {
                    const finalData = unpackageData(jsonStr);
                    setParsedData(finalData);
                    setImportStep('confirm');
                 } catch (err) {
                    setImportError('数据完整性校验失败 (MD5 mismatch)');
                    triggerHaptic('error');
                 }
             }
          } catch (e) {
             console.error(e);
             setImportError('无法识别有效的彩色配置码，请确保图片清晰且未经压缩');
             triggerHaptic('error');
          } finally {
             setIsProcessingImport(false);
          }
      };
      img.src = url;
  };

  // --- Auth Token Verification & Failure Recovery ---
  const handleVerifyAuthToken = (token: any) => {
      setImportStep('auth_check');
      setAuthVerifyStatus('verifying');
      setGeneratedFailureCode(''); // Reset prev failure code
      
      setTimeout(() => {
          const { sig, ...data } = token;
          const expectedSig = CryptoJS.HmacSHA256(JSON.stringify(data), APP_SECRET).toString();
          
          let errorMsg = null;

          // 1. Verify Signature
          if (sig !== expectedSig) {
              errorMsg = '凭证签名无效，可能已被篡改';
          } 
          // 2. Verify User ID
          else if (token.target_uid !== profile?.userId) {
              errorMsg = '个人编号不匹配，无法激活此权限';
          }
          // 3. Verify Expiry
          else if (Date.now() > token.exp) {
              errorMsg = '凭证已过期，请重新生成';
          }
          // 4. Verify Role Conflict (NEW)
          // Prevents Long Term Admin or Permanent Admin from accepting a Long Term Admin token
          else if (token.role === 'long_term_admin' && (profile?.identity === 'long_term_admin' || profile?.identity === 'permanent_admin')) {
              errorMsg = '您已拥有长期管理员或更高身份，无法接受此传承';
          }
          // 5. SECURITY FIX: Prevent 'permanent_admin' from being granted via QR
          else if (token.role === 'permanent_admin') {
              errorMsg = '非法操作：永久管理员权限无法通过二维码授予';
          }

          if (errorMsg) {
              setImportError(errorMsg);
              setAuthVerifyStatus('error');
              triggerHaptic('error');
              
              // Generate Recovery Code if sender is available
              if (token.sender_uid && token.role && token.role !== 'permanent_admin') {
                 // Create a secure recovery payload
                 // Payload: { s: sender_uid, r: role_to_restore, t: timestamp }
                 // Encrypt this using APP_SECRET as key for symmetric recovery
                 const recoveryData = { s: token.sender_uid, r: 'long_term_admin', t: Date.now() }; // Always restore to long_term if legacy failed
                 const recoveryStr = CryptoJS.AES.encrypt(JSON.stringify(recoveryData), APP_SECRET).toString();
                 setGeneratedFailureCode(recoveryStr);
              }
              return;
          }

          // Success
          setParsedData(token); 
          setAuthVerifyStatus('success');
          triggerHaptic('success');
          
          // Check for inheritance ritual
          if (token.inheriting) {
              setTimeout(() => {
                  setImportStep('legacy_reveal');
                  triggerHaptic('medium');
              }, 1000);
          }
      }, 2000); // Ritual delay
  };

  const handleConfirmAuth = () => {
      if (!parsedData || !profile) return;
      
      const newIdentity = parsedData.role as UserIdentity;
      const newProfile = { ...profile, identity: newIdentity };
      saveUserProfile(newProfile);
      setProfile(newProfile);
      
      alert(`权限激活成功！当前身份：${getIdentityLabel(newIdentity)}`);
      triggerHaptic('heavy');
      window.location.reload();
  };

  const handleDecryptCimbar = () => {
      try {
          const finalData = unpackageData(pendingData, importPassword);
          setParsedData(finalData);
          setImportStep('confirm');
          setImportError(null);
          triggerHaptic('success');
      } catch (e: any) {
          triggerHaptic('error');
          if (e.message === 'DECRYPTION_FAILED') {
              setImportError('密码错误，解密失败');
          } else if (e.message === 'INTEGRITY_CHECK_FAILED') {
              setImportError('数据校验失败，文件可能已损坏');
          } else {
              setImportError('未知错误');
          }
      }
  };

  const handleConfirmImport = () => {
      if (parsedData) {
          const isV2 = parsedData.exportVersion === 2;
          const effectiveData = isV2 ? parsedData.active : parsedData;

          // Check if Global Config Only (No Profile/Todos)
          if (!effectiveData.profile && !effectiveData.todos && (effectiveData.settings || effectiveData.globalConfig || effectiveData.departments)) {
              // 1. Prepare Active Settings Merge (Preserve Local Prefs)
              if (effectiveData.settings) {
                  const currentSettings = getStoredSettings();
                  effectiveData.settings = {
                      ...effectiveData.settings,
                      darkMode: currentSettings.darkMode,
                      hapticIntensity: currentSettings.hapticIntensity
                  };
              }
              
              // 2. Use importAllData to handle everything (Active + Accounts)
              triggerHaptic('heavy');
              importAllData(parsedData); 
              
              alert('全局配置同步成功，个人设置/个人编号不受影响');
          } else {
              // Full Restore
              triggerHaptic('heavy');
              importAllData(parsedData);
              alert('数据恢复成功！');
          }
          window.location.reload();
      }
  };

  // --- Restore Logic ---
  const handleRestoreAuthority = () => {
      if (!failureCode) return;
      try {
          const bytes = CryptoJS.AES.decrypt(failureCode, APP_SECRET);
          const decrypted = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
          
          // Verify
          // { s: sender_uid, r: role, t: timestamp }
          if (decrypted.s === profile?.userId) {
              // Time limit check (e.g. 1 hour)
              if (Date.now() - decrypted.t > 3600000) {
                  alert('恢复代码已过期');
                  return;
              }
              
              const newProfile = { ...profile, identity: decrypted.r as UserIdentity };
              saveUserProfile(newProfile);
              setProfile(newProfile);
              setActiveModal(null);
              triggerHaptic('success');
              alert(`身份恢复成功！欢迎回来，${getIdentityLabel(decrypted.r)}`);
              window.location.reload();
          } else {
              alert('该代码不属于此账号，无法恢复');
          }
      } catch (e) {
          alert('无效的恢复代码');
      }
  };

  return (
    <div className="w-full h-full p-6 md:p-8 overflow-y-auto pb-24 animate-fade-in hide-scrollbar text-slate-800 dark:text-white">
      
      {/* Shake Animation Style */}
      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-5px); }
          75% { transform: translateX(5px); }
        }
        .animate-shake {
          animation: shake 0.3s ease-in-out;
        }
        .legacy-glow {
          text-shadow: 0 0 10px rgba(255,255,255,0.5);
        }
      `}</style>

      <div className="max-w-[1800px] mx-auto h-full flex flex-col">
        {/* Header */}
        <div className="flex flex-row items-end justify-between mb-6 gap-4 shrink-0">
          <div>
            <h2 className="text-4xl font-bold text-slate-900 dark:text-white tracking-tight text-glow">系统设置</h2>
            <p className="text-slate-500 dark:text-white/60 mt-1 text-base">个性化配置与数据管理中心</p>
          </div>
          <button 
            onClick={() => { setActiveModal('version_info'); triggerHaptic('light'); }}
            className="glass-card text-indigo-500 dark:text-indigo-300 border-indigo-200 dark:border-indigo-500/30 px-4 py-1.5 rounded-full text-xs font-mono tracking-wide active:scale-95 transition-transform hover:bg-white/50 dark:hover:bg-white/10 flex items-center gap-2 shadow-sm"
          >
            <Sparkles size={12} className="animate-pulse"/> v2.5.0
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1 min-h-0">
          
          {/* ... (Left Column Profile & Appearance) ... */}
          <div className="lg:col-span-4 flex flex-col gap-6 h-full">
            {/* Profile Card */}
            <div className="glass-panel rounded-[2rem] p-6 relative overflow-hidden group">
                <div className="absolute -top-20 -left-20 w-40 h-40 bg-indigo-500 rounded-full blur-[60px] opacity-20 group-hover:opacity-40 transition-opacity duration-700"></div>
                
                <div className="flex justify-between items-start relative z-10 mb-4">
                  <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-2 text-lg"><User className="text-indigo-500 dark:text-indigo-400"/> 个人档案</h3>
                  {!isEditingProfile && (
                    <button onClick={() => { setIsEditingProfile(true); triggerHaptic('selection'); }} className="p-3 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 text-indigo-500 dark:text-indigo-300 rounded-full transition-colors active:scale-95">
                      <Edit2 size={18} />
                    </button>
                  )}
                </div>

                <div className="flex flex-col items-center relative z-10">
                  <div className="relative mb-4">
                    <div className="w-24 h-24 rounded-full p-1.5 border border-white/20 shadow-2xl bg-white/5 backdrop-blur-md">
                      <div className="w-full h-full rounded-full overflow-hidden relative bg-black/5 dark:bg-black/20">
                          {isEditingProfile && editAvatar ? <img src={editAvatar} className="w-full h-full object-cover" /> : 
                            profile?.avatar ? <img src={profile.avatar} className="w-full h-full object-cover" /> :
                            <div className="w-full h-full flex items-center justify-center text-slate-400 dark:text-white/30"><User size={32}/></div>
                          }
                      </div>
                    </div>
                    {isEditingProfile && (
                      <label className={`absolute bottom-0 right-0 w-8 h-8 bg-indigo-500 text-white rounded-full flex items-center justify-center shadow-lg cursor-pointer hover:bg-indigo-600 transition-colors transform hover:scale-105 border border-white/20 ${isCompressingAvatar ? 'cursor-wait opacity-80' : ''}`}>
                        {isCompressingAvatar ? <RefreshCw size={14} className="animate-spin"/> : <Camera size={14} />}
                        <input type="file" accept="image/*" onChange={handleProfileFileChange} className="hidden" disabled={isCompressingAvatar} />
                      </label>
                    )}
                  </div>

                  {isEditingProfile ? (
                    <div className="w-full space-y-4 animate-fade-in">
                       <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-[10px] text-slate-500 dark:text-white/50 font-bold uppercase tracking-wider">姓名</label>
                            <input value={editName} onChange={e => setEditName(e.target.value)} className="w-full p-2.5 glass-input rounded-xl text-sm font-bold text-center focus:outline-none" />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] text-slate-500 dark:text-white/50 font-bold uppercase tracking-wider">职位</label>
                            <input value={editPosition} onChange={e => setEditPosition(e.target.value)} className="w-full p-2.5 glass-input rounded-xl text-sm text-center focus:outline-none" />
                          </div>
                      </div>
                      <div className="space-y-1">
                          <label className="text-[10px] text-slate-500 dark:text-white/50 font-bold uppercase tracking-wider">所属部门</label>
                          <select value={editDeptId} onChange={e => setEditDeptId(e.target.value)} className="w-full p-2.5 glass-input rounded-xl text-sm text-center focus:outline-none appearance-none">
                            {departments.map(d => <option key={d.id} value={d.id} className="text-black">{d.name}</option>)}
                          </select>
                      </div>
                      {/* Organization Editing - Enhanced for Custom Orgs */}
                      <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-white/10">
                          <div className="flex justify-between items-center">
                              <label className="text-[10px] text-slate-500 dark:text-white/50 font-bold uppercase tracking-wider">所属组织</label>
                              <button 
                                onClick={() => setUseStandardOrgFormat(!useStandardOrgFormat)}
                                className={`text-[10px] px-2 py-0.5 rounded border transition-colors ${useStandardOrgFormat ? 'bg-indigo-50 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-300 border-indigo-200 dark:border-indigo-500/30' : 'bg-slate-100 dark:bg-white/5 text-slate-500 dark:text-white/50 border-transparent'}`}
                              >
                                {useStandardOrgFormat ? '标准命名' : '自定义命名'}
                              </button>
                          </div>
                          
                          {useStandardOrgFormat ? (
                              <>
                                <div className="flex items-center gap-2">
                                    <div className="text-xs font-bold text-slate-400">西安欧亚学院</div>
                                    <select 
                                        value={editCollege} 
                                        onChange={e => setEditCollege(e.target.value)} 
                                        className="flex-1 p-2 glass-input rounded-lg text-xs font-bold text-center focus:outline-none appearance-none truncate"
                                    >
                                        {COLLEGES.map(c => <option key={c} value={c} className="text-black">{c}</option>)}
                                    </select>
                                </div>
                                <input 
                                    value={editOrgName} 
                                    onChange={e => setEditOrgName(e.target.value)} 
                                    className="w-full p-2.5 glass-input rounded-xl text-sm text-center focus:outline-none" 
                                    placeholder="学生成长促进会"
                                />
                              </>
                          ) : (
                              <input 
                                value={editOrgName} 
                                onChange={e => setEditOrgName(e.target.value)} 
                                className="w-full p-2.5 glass-input rounded-xl text-sm text-center focus:outline-none font-bold" 
                                placeholder="输入完整组织名称"
                              />
                          )}
                      </div>

                      <div className="space-y-1 pt-2">
                          <label className="text-[10px] text-slate-500 dark:text-white/50 font-bold uppercase tracking-wider">生日 (MM-DD)</label>
                          <input value={editBirthday} onChange={e => setEditBirthday(e.target.value)} className="w-full p-2.5 glass-input rounded-xl text-sm text-center focus:outline-none" placeholder="01-01" />
                      </div>

                      <div className="flex gap-3 pt-2">
                        <button onClick={() => setIsEditingProfile(false)} className="flex-1 py-2.5 rounded-xl text-sm font-bold text-slate-500 dark:text-white/50 hover:bg-black/5 dark:hover:bg-white/10 transition-colors">取消</button>
                        <button onClick={handleSaveProfile} className="flex-1 py-2.5 bg-indigo-600 text-white rounded-xl text-sm font-bold shadow-lg shadow-indigo-500/30 hover:bg-indigo-700 transition-colors active:scale-95">保存</button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center w-full">
                      <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2 text-glow">{profile?.name || '未命名'}</h3>
                      <div className="flex flex-wrap items-center justify-center gap-2 mb-3">
                          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 dark:bg-white/10 text-indigo-500 dark:text-indigo-300 text-xs font-bold border border-indigo-100 dark:border-white/10">
                            {profileDeptName}
                          </div>
                          <div className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold border ${getIdentityColor(profile?.identity || 'user')}`}>
                             {profile?.identity && profile.identity !== 'user' && <Shield size={10} fill="currentColor"/>}
                             {getIdentityLabel(profile?.identity || 'user')}
                          </div>
                      </div>
                      <div className="text-sm text-slate-500 dark:text-white/50 font-medium mb-3">{profile?.position || '成员'}</div>
                      <div className="text-xs text-slate-400 dark:text-white/40 mb-3 px-4 truncate max-w-full">
                         <Building2 size={12} className="inline mr-1"/>
                         {profile?.organization || '未设置组织'}
                      </div>
                      
                      {/* User ID Display with Copy */}
                      <button 
                        onClick={handleCopyUserId}
                        className="w-full bg-black/5 dark:bg-white/5 rounded-lg p-2 font-mono text-[10px] text-slate-500 dark:text-white/50 border border-black/5 dark:border-white/5 mb-3 flex items-center justify-center gap-2 active:scale-95 transition-transform hover:bg-black/10 dark:hover:bg-white/10"
                      >
                        ID: {profile?.userId || '--------'}
                        <Copy size={10} />
                      </button>

                      {profile?.registerDate && (
                         <div className="text-xs text-slate-400 dark:text-white/30 flex items-center justify-center gap-1">
                            <Calendar size={12}/> 注册于 {profile.registerDate}
                         </div>
                      )}
                    </div>
                  )}
                </div>
            </div>

            {/* Appearance & Haptic Card */}
            <div className="glass-panel rounded-2xl p-5 flex flex-col gap-4">
               {/* Theme Mode */}
               <div className="flex flex-col gap-3">
                  <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${settings.themeMode === 'dark' ? 'bg-indigo-500/30 text-indigo-300' : (settings.themeMode === 'light' ? 'bg-orange-500/20 text-orange-400' : 'bg-slate-500/20 text-slate-400')}`}>
                        {settings.themeMode === 'dark' ? <Moon size={16}/> : (settings.themeMode === 'light' ? <Sun size={16}/> : <Smartphone size={16}/>)}
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-900 dark:text-white text-sm">外观模式</h4>
                      </div>
                  </div>
                  <div className="flex p-1 bg-black/5 dark:bg-white/5 rounded-xl border border-black/5 dark:border-white/5">
                      <button onClick={() => changeTheme('system')} className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${settings.themeMode === 'system' ? 'bg-white dark:bg-white/20 text-slate-900 dark:text-white shadow-sm' : 'text-slate-500 dark:text-white/40'}`}>
                          <Smartphone size={12}/> 跟随系统
                      </button>
                      <button onClick={() => changeTheme('light')} className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${settings.themeMode === 'light' ? 'bg-white dark:bg-white/20 text-orange-500 dark:text-orange-300 shadow-sm' : 'text-slate-500 dark:text-white/40'}`}>
                          <Sun size={12}/> 浅色
                      </button>
                      <button onClick={() => changeTheme('dark')} className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${settings.themeMode === 'dark' ? 'bg-white dark:bg-white/20 text-indigo-500 dark:text-indigo-300 shadow-sm' : 'text-slate-500 dark:text-white/40'}`}>
                          <Moon size={12}/> 深色
                      </button>
                  </div>
               </div>
               <div className="h-px bg-gray-200 dark:bg-white/10 w-full"></div>
               <div className="flex flex-col gap-2">
                  <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center bg-purple-500/20 text-purple-400">
                         <Vibrate size={16}/>
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-slate-900 dark:text-white text-sm">触感反馈</h4>
                      </div>
                  </div>
                  <div className="flex gap-2 p-1 bg-black/5 dark:bg-white/5 rounded-xl border border-black/5 dark:border-white/5">
                      {['关闭', '轻柔', '适中', '强烈'].map((label, idx) => (
                        <button
                           key={idx}
                           onClick={() => changeHapticIntensity(idx)}
                           className={`flex-1 py-1.5 rounded-lg text-[10px] font-bold transition-all ${settings.hapticIntensity === idx ? 'bg-white dark:bg-white/20 text-purple-600 dark:text-purple-300 shadow-sm' : 'text-slate-400 dark:text-white/40 hover:text-slate-600 dark:hover:text-white/70'}`}
                        >
                           {label}
                        </button>
                      ))}
                  </div>
               </div>
            </div>
            
            {/* Desktop Logout Area (Only visible on lg) */}
            <div className="hidden lg:flex flex-col gap-2 mt-auto">
               <button onClick={() => setActiveModal('restore_identity')} className="w-full p-2 text-center text-[10px] text-slate-400 hover:text-indigo-500 transition-colors">
                  申请恢复管理员身份
               </button>
               <button 
                onClick={handleLogout}
                className="w-full glass-panel border border-red-500/20 text-red-500 dark:text-red-400 font-bold py-3.5 rounded-[2rem] hover:bg-red-500/10 hover:text-red-600 dark:hover:text-red-300 active:scale-[0.98] transition-all flex items-center justify-center gap-3 group shadow-sm"
              >
                <LogOut size={16} className="group-hover:-translate-x-1 transition-transform" />
                退出登录
              </button>
            </div>
          </div>

          {/* --- RIGHT COLUMN: Admin & Security (8 cols) --- */}
          <div className="lg:col-span-8 flex flex-col h-full gap-6">
            
            {/* ADMIN CONSOLE: Only Visible to Admins */}
            {isAdmin(profile?.identity) && (
              <div className="glass-panel rounded-[2rem] overflow-hidden bg-white/50 dark:bg-white/5 relative">
                <div className="absolute inset-0 bg-gradient-to-r from-amber-500/5 to-blue-500/5 pointer-events-none"></div>
                <div className="relative z-10 p-6 md:p-8">
                    <div className="flex items-center justify-between gap-4 mb-4">
                        <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl flex items-center justify-center text-white shadow-lg">
                                <Command size={24} />
                            </div>
                            <div>
                                <h3 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-3 tracking-tight">
                                    管理员控制台
                                </h3>
                                <p className="text-slate-500 dark:text-white/60 text-xs mt-1 font-medium">Administrator Console</p>
                            </div>
                        </div>
                        <button onClick={() => setActiveModal('help_admin')} className="p-2 text-slate-400 hover:text-indigo-500 transition-colors"><HelpCircle size={20} /></button>
                    </div>

                    {/* Temp Admin Warning Banner */}
                    {profile?.identity === 'temp_admin' && (
                        <div className="bg-amber-100 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/20 p-4 rounded-xl mb-6 flex items-start gap-3">
                            <div className="p-2 bg-amber-500 text-white rounded-lg shrink-0 animate-pulse">
                                <Timer size={16}/>
                            </div>
                            <div>
                                <h4 className="font-bold text-amber-700 dark:text-amber-400 text-sm mb-1">临时管理员权限提示</h4>
                                <p className="text-xs text-amber-600 dark:text-amber-300/80 leading-relaxed">
                                    您的临时管理权限有效期仅为 <span className="font-bold">12小时</span>。请抓紧时间完成配置更新与管理操作。过期后将自动降级为普通用户。
                                </p>
                            </div>
                        </div>
                    )}

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {/* 1. Inheritance / Distribution */}
                        {(profile?.identity === 'permanent_admin' || profile?.identity === 'long_term_admin') && (
                          <button onClick={() => { setGrantRole(profile.identity === 'permanent_admin' ? 'long_term_admin' : 'long_term_admin'); handleOpenGrantModal(); }} className="bg-white/60 dark:bg-white/5 border border-white/60 dark:border-white/10 p-4 rounded-xl flex flex-col items-center justify-center text-center gap-2 hover:bg-white/80 dark:hover:bg-white/10 transition-colors active:scale-95 group relative overflow-hidden">
                              <div className="w-10 h-10 rounded-full bg-amber-100 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                                  <Key size={20} />
                              </div>
                              <span className="font-bold text-slate-800 dark:text-white text-sm">权限传承 / 分配</span>
                              <span className="text-[10px] text-slate-400 dark:text-white/40">Grant Authority</span>
                          </button>
                        )}

                        {/* 2. Global Resource Edit (NEW) */}
                        <button onClick={() => { setEditGlobalConfig(globalConfig); setGlobalConfigTab('basic'); setActiveModal('global_edit'); triggerHaptic('selection'); }} className="bg-white/60 dark:bg-white/5 border border-white/60 dark:border-white/10 p-4 rounded-xl flex flex-col items-center justify-center text-center gap-2 hover:bg-white/80 dark:hover:bg-white/10 transition-colors active:scale-95 group">
                             <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                                  <Globe size={20} />
                             </div>
                             <span className="font-bold text-slate-800 dark:text-white text-sm">全局资源配置</span>
                             <span className="text-[10px] text-slate-400 dark:text-white/40">Manage Links & Info</span>
                        </button>

                        {/* 3. Department Management (NEW) */}
                        <button onClick={() => { setActiveModal('dept_manage'); triggerHaptic('selection'); }} className="bg-white/60 dark:bg-white/5 border border-white/60 dark:border-white/10 p-4 rounded-xl flex flex-col items-center justify-center text-center gap-2 hover:bg-white/80 dark:hover:bg-white/10 transition-colors active:scale-95 group">
                             <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-500/20 text-green-600 dark:text-green-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                                  <Users size={20} />
                             </div>
                             <span className="font-bold text-slate-800 dark:text-white text-sm">部门管理</span>
                             <span className="text-[10px] text-slate-400 dark:text-white/40">Add/Edit Depts</span>
                        </button>

                        {/* 4. Global Config Share (REVISED) */}
                        <button onClick={() => { 
                            setCimbarImage(''); 
                            setExportScope('global_only'); // Set to global_only to force locked UI
                            setUseEncryption(false);
                            setExportPassword('');
                            setActiveModal('export_cimbar'); 
                            triggerHaptic('selection');
                        }} className="bg-white/60 dark:bg-white/5 border border-white/60 dark:border-white/10 p-4 rounded-xl flex flex-col items-center justify-center text-center gap-2 hover:bg-white/80 dark:hover:bg-white/10 transition-colors active:scale-95 group">
                             <div className="w-10 h-10 rounded-full bg-purple-100 dark:bg-purple-500/20 text-purple-600 dark:text-purple-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                                  <Share2 size={20} />
                             </div>
                             <span className="font-bold text-slate-800 dark:text-white text-sm">分享全局配置</span>
                             <span className="text-[10px] text-slate-400 dark:text-white/40">不含个人数据 (Safe)</span>
                        </button>
                    </div>
                </div>
              </div>
            )}

            {/* Security Center */}
            <div className="glass-panel rounded-[2rem] flex flex-col overflow-hidden bg-white/50 dark:bg-white/5 flex-1 min-h-[400px]">
               {/* ... (Security Center Content - Same as before) ... */}
               <div className="relative shrink-0 border-b border-gray-200 dark:border-white/10 overflow-hidden bg-slate-50/50 dark:bg-[#0f172a]">
                  <div className="relative z-10 p-6 md:p-8">
                     <div className="flex items-center justify-between gap-4 mb-3">
                        <div className="flex items-center gap-4">
                            <div className="relative w-12 h-12 bg-white dark:bg-white/10 rounded-2xl flex items-center justify-center shadow-lg border border-white/50 dark:border-white/10 group overflow-hidden">
                                <Shield className="relative z-10 text-blue-600 dark:text-indigo-400" size={24} strokeWidth={2} />
                            </div>
                            <div>
                                <h3 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-3 tracking-tight">
                                    安全配置中心
                                </h3>
                                <p className="text-slate-500 dark:text-white/60 text-xs mt-1 font-medium">迁移设备 • 应用更新备份 • 数据传输</p>
                            </div>
                        </div>
                        <button onClick={() => setActiveModal('help_security')} className="p-2 text-slate-400 hover:text-indigo-500 transition-colors"><HelpCircle size={20} /></button>
                     </div>
                  </div>
               </div>

               <div className="flex-1 flex flex-col md:flex-row p-6 md:p-8 gap-8 overflow-y-auto hide-scrollbar">
                  {/* Standard File */}
                  <div className="flex-1 flex flex-col">
                     <div className="flex items-center gap-3 mb-4">
                        <div className="w-8 h-8 rounded-full bg-blue-500/10 dark:bg-blue-500/20 text-blue-500 dark:text-blue-400 flex items-center justify-center border border-blue-500/20 dark:border-blue-500/30">
                           <Database size={16}/>
                        </div>
                        <div>
                           <h4 className="font-bold text-slate-900 dark:text-white text-sm">标准归档</h4>
                           <p className="text-[10px] text-slate-500 dark:text-white/50">JSON 格式备份文件</p>
                        </div>
                     </div>
                     <div className="space-y-3">
                        <button onClick={() => { setUseEncryption(false); setExportPassword(''); setExportScope('full'); setActiveModal('export_file'); triggerHaptic('selection'); }} className="w-full py-3.5 glass-card hover:bg-black/5 dark:hover:bg-white/10 rounded-2xl flex items-center justify-between px-5 transition-all group active:scale-[0.98]">
                           <span className="font-bold text-slate-700 dark:text-white/80 flex items-center gap-2 text-sm"><Download size={16}/> 导出数据文件</span>
                        </button>
                        <label className="w-full py-3.5 glass-card hover:bg-black/5 dark:hover:bg-white/10 rounded-2xl flex items-center justify-between px-5 transition-all group active:scale-[0.98] cursor-pointer" onClick={() => triggerHaptic('selection')}>
                           <span className="font-bold text-slate-700 dark:text-white/80 flex items-center gap-2 text-sm"><Upload size={16}/> 恢复备份文件</span>
                           <input ref={fileImportRef} type="file" accept=".json" onChange={handleImportJSON} className="hidden" />
                        </label>
                     </div>
                  </div>

                  <div className="hidden md:block w-px bg-gray-200 dark:bg-white/10 self-stretch mx-2"></div>

                  {/* CIMBAR Transfer */}
                  <div className="flex-1 flex flex-col">
                     <div className="flex items-center gap-3 mb-4">
                        <div className="w-8 h-8 rounded-full bg-indigo-500/10 dark:bg-indigo-500/20 text-indigo-500 dark:text-indigo-400 flex items-center justify-center border border-indigo-500/20 dark:border-indigo-500/30">
                           <Layers size={16}/>
                        </div>
                        <div>
                           <h4 className="font-bold text-slate-900 dark:text-white text-sm">彩色码传输</h4>
                           <p className="text-[10px] text-slate-500 dark:text-white/50">支持备份恢复与权限激活</p>
                        </div>
                     </div>

                     <div className="space-y-3">
                        <div className="flex gap-2">
                           <button onClick={() => { 
                                 setCimbarImage(''); 
                                 setExportPassword(''); 
                                 setUseEncryption(false);
                                 setExportScope('full');
                                 setActiveModal('export_cimbar'); 
                                 triggerHaptic('selection');
                           }} className="flex-1 py-5 bg-indigo-500 hover:bg-indigo-600 dark:bg-indigo-600 dark:hover:bg-indigo-700 text-white rounded-2xl shadow-lg shadow-indigo-500/30 active:scale-[0.98] transition-all flex flex-col items-center justify-center gap-1.5 group border border-indigo-400/50">
                                 <QrCode size={24} className="group-hover:scale-110 transition-transform text-white text-always-white"/>
                                 <span className="font-bold text-xs text-white text-always-white">生成配置码</span>
                           </button>

                           <button onClick={() => {
                                 setImportStep('upload');
                                 setParsedData(null);
                                 setImportFileUrl('');
                                 setActiveModal('import_cimbar');
                                 triggerHaptic('selection');
                           }} className="flex-1 py-5 glass-card border border-dashed border-indigo-400/50 text-indigo-500 dark:text-indigo-300 rounded-2xl hover:bg-indigo-500/10 dark:hover:bg-indigo-500/20 transition-all active:scale-[0.98] flex flex-col items-center justify-center gap-1.5 font-bold text-xs">
                                 <ScanLine size={24}/>
                                 扫码获取配置 / 恢复数据
                           </button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
          </div>
        </div>
        
        {/* Mobile Logout - Positioned at bottom of page container (LG Hidden) */}
        <div className="mt-6 lg:hidden">
           <button onClick={() => setActiveModal('restore_identity')} className="w-full p-3 rounded-xl border border-dashed border-slate-300 dark:border-white/20 text-slate-500 dark:text-white/50 text-xs font-bold hover:bg-black/5 dark:hover:bg-white/5 mb-3">
              恢复管理员身份
           </button>
           <button 
            onClick={handleLogout}
            className="w-full glass-card border border-red-500/20 text-red-500 dark:text-red-400 font-bold py-3.5 rounded-[2rem] hover:bg-red-500/10 hover:text-red-600 dark:hover:text-red-300 flex items-center justify-center gap-3 group shadow-sm active:scale-[0.98] transition-all"
          >
            <LogOut size={16} /> 退出登录
          </button>
        </div>

      </div>

      {/* --- MODALS --- */}
      
      {activeModal === 'admin_grant' && (
         <ModalPortal>
            <div className="fixed inset-0 z-[999] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setActiveModal(null)}>
               <div className={`glass-panel rounded-3xl p-6 md:p-8 w-full max-w-sm shadow-2xl relative bg-white/95 dark:bg-black/60 flex flex-col items-center text-center transition-all ${isIdError ? 'animate-shake border-red-500' : ''}`} onClick={e => e.stopPropagation()}>
                   <button onClick={() => setActiveModal(null)} className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors active:scale-95">
                       <X size={20} />
                   </button>
                   {!authQrUrl ? (
                       <>
                           <div className="w-16 h-16 bg-amber-100 dark:bg-amber-500/20 rounded-full flex items-center justify-center text-amber-500 dark:text-amber-400 mb-4">
                               <Key size={32}/>
                           </div>
                           <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                               {grantRole === 'long_term_admin' ? '权限传承 (Inheritance)' : '权限分配 (Distribution)'}
                           </h3>
                           <p className="text-sm text-slate-500 dark:text-white/60 mb-6 leading-relaxed">
                               {grantRole === 'long_term_admin' 
                                 ? (profile?.identity === 'permanent_admin' 
                                     ? <>
                                         <span className="text-amber-600 dark:text-amber-400 font-bold block mb-1">你是第一批开拓者，传承后身份保留不会降级。</span>
                                         愿你审慎行使无限传承的权利，寻找真正眼中有光、心中有火的继任者，将这份温暖与秩序传递下去。
                                       </>
                                     : '生成长期管理员凭证。授予后请在确认对方接收成功后，手动点击卸任以完成交接。')
                                 : '生成临时管理员凭证，有效期12小时。'
                               }
                           </p>

                           <div className="w-full space-y-4 mb-6">
                               <div className="space-y-2 text-left">
                                   <label className="text-xs font-bold text-slate-500 dark:text-white/50 uppercase tracking-wider ml-1">目标用户 ID (16位)</label>
                                   <input 
                                      value={grantTargetId}
                                      onChange={e => setGrantTargetId(e.target.value.trim())}
                                      placeholder="请输入接收者的个人编号"
                                      className="w-full p-4 glass-input rounded-xl text-center font-mono tracking-widest focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
                                   />
                               </div>
                               
                               {/* Legacy Message Input */}
                               {grantRole === 'long_term_admin' && (
                                   <div className="space-y-2 text-left animate-fade-in">
                                       <label className="text-xs font-bold text-slate-500 dark:text-white/50 uppercase tracking-wider ml-1">传承寄语 (可选)</label>
                                       <textarea 
                                          value={grantMessage}
                                          onChange={e => setGrantMessage(e.target.value)}
                                          placeholder={DEFAULT_LEGACY_MSG}
                                          rows={3}
                                          className="w-full p-3 glass-input rounded-xl text-sm leading-relaxed focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all resize-none"
                                       />
                                   </div>
                               )}
                               
                               <div className="flex p-1 bg-black/5 dark:bg-white/5 rounded-xl">
                                   <button onClick={() => setGrantRole('temp_admin')} className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${grantRole === 'temp_admin' ? 'bg-white dark:bg-white/20 shadow-sm text-indigo-600 dark:text-white' : 'text-slate-500 dark:text-white/50'}`}>临时权限</button>
                                   {(profile?.identity === 'permanent_admin' || profile?.identity === 'long_term_admin') && (
                                      <button onClick={() => setGrantRole('long_term_admin')} className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${grantRole === 'long_term_admin' ? 'bg-white dark:bg-white/20 shadow-sm text-amber-600 dark:text-amber-400' : 'text-slate-500 dark:text-white/50'}`}>长期传承</button>
                                   )}
                               </div>
                           </div>

                           {isRitualAnim ? (
                               <div className="space-y-3">
                                   <RefreshCw className="animate-spin mx-auto text-indigo-500" size={24}/>
                                   <p className="text-xs font-mono text-indigo-500">
                                       {ritualStep === 0 && 'INITIALIZING SECURE CHANNEL...'}
                                       {ritualStep === 1 && 'VERIFYING BIOMETRICS...'}
                                       {ritualStep === 2 && 'ENCRYPTING PAYLOAD...'}
                                       {ritualStep === 3 && 'SIGNING TOKEN...'}
                                   </p>
                               </div>
                           ) : (
                               <button 
                                 onClick={handleGenerateAuthQr}
                                 className={`w-full py-4 rounded-xl font-bold text-white shadow-lg transition-all active:scale-95 ${grantRole === 'long_term_admin' ? 'bg-gradient-to-r from-amber-500 to-orange-600 shadow-orange-500/30' : 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-500/30'}`}
                               >
                                 生成授权凭证
                               </button>
                           )}
                       </>
                   ) : (
                       <>
                           <div className="bg-white p-2 rounded-2xl shadow-inner border border-gray-200 mb-6">
                               <img src={authQrUrl} className="w-48 h-48 object-contain" style={{ imageRendering: 'pixelated' }} />
                           </div>
                           <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">凭证已生成</h3>
                           <p className="text-xs text-slate-500 mb-6">
                               请接收者在“安全配置中心”扫描此码<br/>
                               有效期至: {new Date(authExpiry).toLocaleTimeString()}
                           </p>
                           <div className="flex gap-2 w-full">
                               <button onClick={() => { setAuthQrUrl(''); setGrantTargetId(''); }} className="px-4 py-3 rounded-xl font-bold bg-gray-100 dark:bg-white/10 text-slate-600 dark:text-white">返回</button>
                               
                               {grantRole === 'long_term_admin' && profile?.identity !== 'permanent_admin' ? (
                                   <>
                                     <button onClick={handleDownloadAuthQr} className="px-4 py-3 rounded-xl font-bold bg-indigo-50 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-300">保存</button>
                                     <button onClick={handleDowngradeAfterTransfer} className="flex-1 py-3 rounded-xl font-bold bg-red-600 text-white shadow-lg hover:bg-red-700">交接并卸任</button>
                                   </>
                               ) : (
                                   <button onClick={handleDownloadAuthQr} className="flex-1 py-3 rounded-xl font-bold bg-indigo-600 text-white shadow-lg hover:bg-indigo-700">保存凭证</button>
                               )}
                           </div>
                       </>
                   )}
               </div>
            </div>
         </ModalPortal>
      )}

      {activeModal === 'logout_joke' && (
        <ModalPortal>
          <div className="fixed inset-0 z-[999] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setActiveModal(null)}>
            <div className="glass-panel rounded-3xl p-6 w-full max-w-sm text-center bg-white/95 dark:bg-black/60 relative" onClick={e => e.stopPropagation()}>
               <button onClick={() => setActiveModal(null)} className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors active:scale-95">
                   <X size={20} />
               </button>
               <div className="w-16 h-16 bg-red-100 dark:bg-red-500/20 rounded-full flex items-center justify-center text-red-500 mx-auto mb-4"><LogOut size={32}/></div>
               <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">确认退出?</h3>
               <p className="text-sm text-slate-500 dark:text-white/60 mb-6">退出后需重新登录或通过恢复码找回身份。</p>
               <div className="flex gap-3">
                 <button onClick={() => setActiveModal(null)} className="flex-1 py-3 bg-gray-100 dark:bg-white/10 rounded-xl font-bold text-slate-600 dark:text-white/80">取消</button>
                 <button onClick={() => { 
                    switchAccount('NEW_ACCOUNT'); 
                 }} className="flex-1 py-3 bg-red-600 text-white rounded-xl font-bold shadow-lg">确认退出</button>
               </div>
            </div>
          </div>
        </ModalPortal>
      )}

      {activeModal === 'restore_identity' && (
         <ModalPortal>
            <div className="fixed inset-0 z-[999] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setActiveModal(null)}>
               <div className="glass-panel rounded-3xl p-6 w-full max-w-sm text-center bg-white/95 dark:bg-black/60 relative" onClick={e => e.stopPropagation()}>
                  <button onClick={() => setActiveModal(null)} className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors active:scale-95">
                      <X size={20} />
                  </button>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-4">恢复身份</h3>
                  <textarea 
                    value={failureCode}
                    onChange={e => setFailureCode(e.target.value)}
                    placeholder="在此输入恢复代码..."
                    className="w-full h-24 p-3 glass-input rounded-xl text-xs font-mono mb-4 focus:outline-none"
                  />
                  <button onClick={handleRestoreAuthority} className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg">提交恢复</button>
               </div>
            </div>
         </ModalPortal>
      )}

      {/* VERSION INFO MODAL - REENGINEERED */}
      {activeModal === 'version_info' && (
         <ModalPortal>
            <div className="fixed inset-0 z-[999] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setActiveModal(null)}>
               <div className="glass-panel rounded-[2rem] w-full max-w-md bg-white/95 dark:bg-gray-900/90 h-[75vh] flex flex-col relative overflow-hidden" onClick={e => e.stopPropagation()}>
                  <button onClick={() => setActiveModal(null)} className="absolute top-4 right-4 z-50 p-2 text-white/50 hover:text-white transition-colors active:scale-95 bg-black/10 rounded-full backdrop-blur-md">
                      <X size={20} />
                  </button>
                  
                  {/* Decorative Background Glows */}
                  <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none"></div>
                  <div className="absolute bottom-0 left-0 w-40 h-40 bg-purple-500/10 rounded-full blur-2xl -ml-10 -mb-10 pointer-events-none"></div>

                  {/* Header Area */}
                  <div className="p-6 pb-2 shrink-0">
                      <div className="relative overflow-hidden bg-gradient-to-br from-indigo-500 to-purple-600 p-6 text-white rounded-3xl mb-6 shadow-xl shadow-indigo-500/20">
                          <div className="absolute top-0 right-0 p-4 opacity-20">
                              <Sparkles size={60} />
                          </div>
                          <div className="relative z-10">
                              <div className="inline-flex items-center gap-1 bg-white/20 backdrop-blur-sm px-2 py-0.5 rounded-full text-[10px] font-bold mb-2 border border-white/20">
                                  <Zap size={10} fill="currentColor"/> MAJOR UPDATE
                              </div>
                              <h1 className="text-4xl font-bold tracking-tight mb-1">v2.5.0</h1>
                              <p className="text-white/80 text-sm font-medium">CIMBAR Protocol & Safety Core</p>
                          </div>
                      </div>
                  </div>

                  <div className="flex-1 overflow-y-auto space-y-6 px-6 pb-6 custom-scrollbar">

                     {/* Feature Highlights Grid */}
                     <div className="grid grid-cols-2 gap-3">
                         <div className="bg-gray-50 dark:bg-white/5 p-4 rounded-2xl border border-gray-100 dark:border-white/5 flex flex-col items-center text-center gap-2">
                             <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-500/20 text-blue-500 dark:text-blue-300 flex items-center justify-center mb-1">
                                 <ScanLine size={20}/>
                             </div>
                             <div className="font-bold text-xs text-slate-700 dark:text-white/90">CIMBAR 传输</div>
                             <div className="text-[10px] text-slate-400 dark:text-white/50 leading-tight">高密度彩色码配置同步</div>
                         </div>
                         <div className="bg-gray-50 dark:bg-white/5 p-4 rounded-2xl border border-gray-100 dark:border-white/5 flex flex-col items-center text-center gap-2">
                             <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-500/20 text-green-500 dark:text-green-300 flex items-center justify-center mb-1">
                                 <Shield size={20}/>
                             </div>
                             <div className="font-bold text-xs text-slate-700 dark:text-white/90">灾难恢复</div>
                             <div className="text-[10px] text-slate-400 dark:text-white/50 leading-tight">权限熔断与身份找回</div>
                         </div>
                         <div className="bg-gray-50 dark:bg-white/5 p-4 rounded-2xl border border-gray-100 dark:border-white/5 flex flex-col items-center text-center gap-2">
                             <div className="w-10 h-10 rounded-full bg-purple-100 dark:bg-purple-500/20 text-purple-500 dark:text-purple-300 flex items-center justify-center mb-1">
                                 <Smartphone size={20}/>
                             </div>
                             <div className="font-bold text-xs text-slate-700 dark:text-white/90">视觉升级</div>
                             <div className="text-[10px] text-slate-400 dark:text-white/50 leading-tight">全新流体与玻璃拟态UI</div>
                         </div>
                         <div className="bg-gray-50 dark:bg-white/5 p-4 rounded-2xl border border-gray-100 dark:border-white/5 flex flex-col items-center text-center gap-2">
                             <div className="w-10 h-10 rounded-full bg-amber-100 dark:bg-amber-500/20 text-amber-500 dark:text-amber-300 flex items-center justify-center mb-1">
                                 <Heart size={20}/>
                             </div>
                             <div className="font-bold text-xs text-slate-700 dark:text-white/90">身份传承</div>
                             <div className="text-[10px] text-slate-400 dark:text-white/50 leading-tight">加密寄语与权限交接</div>
                         </div>
                     </div>

                     {/* Timeline Changelog */}
                     <div>
                        <h4 className="font-bold text-sm text-slate-800 dark:text-white flex items-center gap-2 mb-4">
                            <GitCommit size={16} className="text-slate-400"/> 更新日志
                        </h4>
                        <div className="relative pl-4 border-l-2 border-gray-100 dark:border-white/10 space-y-6">
                            <div className="relative">
                                <div className="absolute -left-[21px] top-0 w-3 h-3 bg-indigo-500 rounded-full border-2 border-white dark:border-gray-900"></div>
                                <div className="text-xs font-bold text-indigo-500 mb-1">Feature</div>
                                <p className="text-xs text-slate-600 dark:text-white/70">新增 CIMBAR (Color Icon Matrix Barcode) 协议，支持离线环境下的复杂配置传输。</p>
                            </div>
                            <div className="relative">
                                <div className="absolute -left-[21px] top-0 w-3 h-3 bg-indigo-500 rounded-full border-2 border-white dark:border-gray-900"></div>
                                <div className="text-xs font-bold text-indigo-500 mb-1">Improvement</div>
                                <p className="text-xs text-slate-600 dark:text-white/70">重构安全中心，增加身份恢复代码 (Recovery Code) 机制，防止误操作导致权限丢失。</p>
                            </div>
                            <div className="relative">
                                <div className="absolute -left-[21px] top-0 w-3 h-3 bg-indigo-500 rounded-full border-2 border-white dark:border-gray-900"></div>
                                <div className="text-xs font-bold text-indigo-500 mb-1">UI/UX</div>
                                <p className="text-xs text-slate-600 dark:text-white/70">优化深色模式下的对比度；新增触感反馈引擎；优化移动端手势操作。</p>
                            </div>
                        </div>
                     </div>

                     {/* Update Warning */}
                     <div className="p-3 bg-blue-50 dark:bg-blue-500/10 border border-blue-100 dark:border-blue-500/20 rounded-xl text-xs text-slate-600 dark:text-white/80 flex items-start gap-3">
                         <AlertCircle size={16} className="text-blue-500 shrink-0 mt-0.5"/>
                         <div className="leading-relaxed">
                             <span className="font-bold block text-blue-700 dark:text-blue-400 mb-1">如何更新?</span>
                             由于采用 PWA 离线架构，请先在安全中心导出全量备份，卸载旧版应用后重新安装，最后导入备份即可。
                         </div>
                     </div>

                     {/* Legacy Note */}
                     <div className="p-6 bg-amber-50/50 dark:bg-amber-900/5 border border-amber-100 dark:border-amber-500/10 rounded-2xl relative overflow-hidden">
                        <div className="absolute top-0 left-0 text-6xl text-amber-200 dark:text-amber-500/10 font-serif -mt-2 -ml-2 select-none">“</div>
                        <p className="relative z-10 text-xs text-amber-900/80 dark:text-amber-100/60 font-serif leading-relaxed italic text-center px-4">
                            这个项目起源于人文教育学院 2306 班的一名学子对“数字化秩序”的探索。代码或许是冰冷的逻辑，但传承是温热的脉搏。
                        </p>
                        <div className="text-center mt-3 text-[10px] text-amber-800/40 dark:text-amber-100/30 font-bold uppercase tracking-widest">
                             — To Successors
                        </div>
                     </div>

                  </div>

                  <div className="p-6 pt-2 shrink-0">
                      <button onClick={() => setActiveModal(null)} className="w-full py-3 bg-gray-100 dark:bg-white/10 rounded-xl font-bold text-slate-600 dark:text-white/80 hover:bg-gray-200 dark:hover:bg-white/20 transition-colors">关闭</button>
                  </div>
               </div>
            </div>
         </ModalPortal>
      )}

      {/* Department Management Modal */}
      {activeModal === 'dept_manage' && (
         <ModalPortal>
            <div className="fixed inset-0 z-[999] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setActiveModal(null)}>
               <div className="glass-panel rounded-3xl p-6 w-full max-w-lg bg-white/95 dark:bg-black/60 max-h-[85vh] flex flex-col relative" onClick={e => e.stopPropagation()}>
                  <button onClick={() => setActiveModal(null)} className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors active:scale-95">
                      <X size={20} />
                  </button>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-4 shrink-0">部门管理</h3>
                  
                  <div className="flex-1 overflow-y-auto space-y-3 custom-scrollbar">
                      {departments.map((dept) => (
                          <div key={dept.id} className="p-4 bg-gray-50 dark:bg-white/5 rounded-xl border border-gray-100 dark:border-white/10 flex items-center justify-between">
                              <div>
                                  <div className="font-bold text-slate-900 dark:text-white text-sm">{dept.name}</div>
                                  <div className="text-xs text-slate-500 dark:text-white/50">{dept.description || '无描述'}</div>
                              </div>
                              <div className="flex gap-2">
                                  <button 
                                    onClick={() => { setEditDept(dept); setActiveModal('dept_edit'); }}
                                    className="p-2 bg-indigo-50 dark:bg-indigo-500/20 text-indigo-500 dark:text-indigo-300 rounded-lg hover:bg-indigo-100 dark:hover:bg-indigo-500/30 transition-colors"
                                  >
                                      <Edit2 size={16}/>
                                  </button>
                                  <button 
                                    onClick={() => handleDeleteDept(dept.id)}
                                    className="p-2 bg-red-50 dark:bg-red-500/20 text-red-500 dark:text-red-300 rounded-lg hover:bg-red-100 dark:hover:bg-red-500/30 transition-colors"
                                  >
                                      <Trash2 size={16}/>
                                  </button>
                              </div>
                          </div>
                      ))}
                  </div>
                  
                  <div className="pt-4 mt-2 border-t border-gray-200 dark:border-white/10 shrink-0">
                      <button 
                        onClick={() => { setEditDept({ id: 'NEW', name: '', description: '', cards: [], announcements: [] }); setActiveModal('dept_edit'); }}
                        className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg flex items-center justify-center gap-2"
                      >
                          <Plus size={18}/> 新增部门
                      </button>
                  </div>
               </div>
            </div>
         </ModalPortal>
      )}

      {/* Department Edit Modal */}
      {activeModal === 'dept_edit' && editDept && (
         <ModalPortal>
            <div className="fixed inset-0 z-[999] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setActiveModal('dept_manage')}>
               <div className="glass-panel rounded-3xl p-6 w-full max-w-sm bg-white/95 dark:bg-black/60 relative" onClick={e => e.stopPropagation()}>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-4">{editDept.id === 'NEW' ? '新增部门' : '编辑部门'}</h3>
                  
                  <div className="space-y-4 mb-6">
                      <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-500 dark:text-white/50 uppercase">部门名称</label>
                          <input 
                            value={editDept.name} 
                            onChange={e => setEditDept({...editDept, name: e.target.value})}
                            className="w-full p-3 glass-input rounded-xl text-sm"
                            placeholder="例如：宣传部"
                          />
                      </div>
                      <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-500 dark:text-white/50 uppercase">描述</label>
                          <textarea 
                            value={editDept.description} 
                            onChange={e => setEditDept({...editDept, description: e.target.value})}
                            className="w-full p-3 glass-input rounded-xl text-sm resize-none h-24"
                            placeholder="部门职责简述..."
                          />
                      </div>
                  </div>

                  <div className="flex gap-3">
                      <button onClick={() => setActiveModal('dept_manage')} className="flex-1 py-3 bg-gray-100 dark:bg-white/10 rounded-xl font-bold text-slate-600 dark:text-white/80">取消</button>
                      <button onClick={handleSaveDept} className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg">保存</button>
                  </div>
               </div>
            </div>
         </ModalPortal>
      )}

      {activeModal === 'global_edit' && (
         <ModalPortal>
            <div className="fixed inset-0 z-[999] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setActiveModal(null)}>
               <div className="glass-panel rounded-3xl p-6 w-full max-w-lg bg-white/95 dark:bg-black/60 max-h-[85vh] flex flex-col relative" onClick={e => e.stopPropagation()}>
                  <button onClick={() => setActiveModal(null)} className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors active:scale-95">
                      <X size={20} />
                  </button>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-4 shrink-0">全局资源配置</h3>
                  <div className="flex-1 overflow-y-auto space-y-4 hide-scrollbar">
                      {/* Tabs */}
                      <div className="flex gap-2 mb-2">
                          <button onClick={() => setGlobalConfigTab('basic')} className={`flex-1 py-2 rounded-lg text-xs font-bold ${globalConfigTab === 'basic' ? 'bg-indigo-500 text-white' : 'bg-gray-100 dark:bg-white/10'}`}>基础信息</button>
                          <button onClick={() => setGlobalConfigTab('cards')} className={`flex-1 py-2 rounded-lg text-xs font-bold ${globalConfigTab === 'cards' ? 'bg-indigo-500 text-white' : 'bg-gray-100 dark:bg-white/10'}`}>首页卡片</button>
                          <button onClick={() => setGlobalConfigTab('guide')} className={`flex-1 py-2 rounded-lg text-xs font-bold ${globalConfigTab === 'guide' ? 'bg-indigo-500 text-white' : 'bg-gray-100 dark:bg-white/10'}`}>教程文档</button>
                      </div>

                      {globalConfigTab === 'basic' && (
                          <div className="space-y-3">
                              <div className="space-y-1">
                                  <label className="text-xs font-bold text-slate-500">反馈链接 (Feedback URL)</label>
                                  <input value={editGlobalConfig.feedbackUrl} onChange={e => setEditGlobalConfig({...editGlobalConfig, feedbackUrl: e.target.value})} className="w-full p-2 glass-input rounded-lg text-sm" />
                              </div>
                              <div className="space-y-1">
                                  <label className="text-xs font-bold text-slate-500">开源地址 (GitHub URL)</label>
                                  <input value={editGlobalConfig.githubUrl} onChange={e => setEditGlobalConfig({...editGlobalConfig, githubUrl: e.target.value})} className="w-full p-2 glass-input rounded-lg text-sm" />
                              </div>
                              <div className="space-y-1">
                                  <label className="text-xs font-bold text-slate-500">联系电话</label>
                                  <input value={editGlobalConfig.contactPhone} onChange={e => setEditGlobalConfig({...editGlobalConfig, contactPhone: e.target.value})} className="w-full p-2 glass-input rounded-lg text-sm" />
                              </div>
                              <div className="space-y-1">
                                  <label className="text-xs font-bold text-slate-500">联系二维码 (企业微信)</label>
                                  <div className="flex items-center gap-4">
                                      {editGlobalConfig.contactQrCode && <img src={editGlobalConfig.contactQrCode} className="w-16 h-16 object-contain border rounded-lg" />}
                                      <label className={`px-4 py-2 bg-gray-100 dark:bg-white/10 rounded-lg text-xs font-bold cursor-pointer flex items-center gap-2 ${isCompressingQr ? 'opacity-70 cursor-wait' : ''}`}>
                                      {isCompressingQr ? <RefreshCw size={12} className="animate-spin"/> : '上传图片'}
                                      <input type="file" accept="image/*" className="hidden" onChange={handleQrUpload} disabled={isCompressingQr} />
                                  </label>
                                  </div>
                              </div>
                          </div>
                      )}
                      
                      {globalConfigTab === 'cards' && (
                          <div className="space-y-4">
                              {['todoCard1', 'todoCard2', 'feedbackCard1', 'feedbackCard2', 'githubCard'].map((key) => {
                                  const cardConfig = (editGlobalConfig as any)[key] || {};
                                  return (
                                      <div key={key} className="p-3 border border-gray-100 dark:border-white/10 rounded-xl bg-gray-50 dark:bg-white/5">
                                          <div className="text-xs font-bold text-indigo-500 mb-2 uppercase">{key}</div>
                                          <div className="grid grid-cols-2 gap-2 mb-2">
                                              <input value={cardConfig.title || ''} onChange={e => setEditGlobalConfig({...editGlobalConfig, [key]: {...cardConfig, title: e.target.value}})} placeholder="标题" className="p-2 glass-input rounded-lg text-xs" />
                                              <input value={cardConfig.subtitle || ''} onChange={e => setEditGlobalConfig({...editGlobalConfig, [key]: {...cardConfig, subtitle: e.target.value}})} placeholder="副标题" className="p-2 glass-input rounded-lg text-xs" />
                                          </div>
                                          <input value={cardConfig.url || ''} onChange={e => setEditGlobalConfig({...editGlobalConfig, [key]: {...cardConfig, url: e.target.value}})} placeholder="URL (可选)" className="w-full p-2 glass-input rounded-lg text-xs mb-2" />
                                          <div className="flex items-center gap-2">
                                              <span className="text-xs text-slate-500">图标:</span>
                                              <IconPicker value={cardConfig.iconName || 'Link'} onChange={(val) => setEditGlobalConfig({...editGlobalConfig, [key]: {...cardConfig, iconName: val}})} />
                                          </div>
                                      </div>
                                  );
                              })}
                          </div>
                      )}

                      {globalConfigTab === 'guide' && (
                          <div className="space-y-2 h-full flex flex-col">
                              <label className="text-xs font-bold text-slate-500">日历同步教程 (HTML 支持)</label>
                              <textarea 
                                  value={editGlobalConfig.calendarGuideHtml || ''} 
                                  onChange={e => setEditGlobalConfig({...editGlobalConfig, calendarGuideHtml: e.target.value})} 
                                  className="w-full flex-1 p-3 glass-input rounded-lg text-xs font-mono resize-none focus:outline-none"
                                  placeholder="<div>输入自定义 HTML 内容...</div>"
                              />
                          </div>
                      )}
                  </div>
                  <div className="flex gap-3 mt-4 shrink-0">
                      <button onClick={() => setActiveModal(null)} className="flex-1 py-3 bg-gray-100 dark:bg-white/10 rounded-xl font-bold text-slate-600 dark:text-white/80">取消</button>
                      <button onClick={handleSaveGlobalConfig} className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg">保存配置</button>
                  </div>
               </div>
            </div>
         </ModalPortal>
      )}

      {/* Export/Import Modals from previous snippets... */}
      {(activeModal === 'export_cimbar' || activeModal === 'export_file') && (
         <ModalPortal>
            <div className="fixed inset-0 z-[999] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setActiveModal(null)}>
               <div className="glass-panel rounded-3xl p-6 w-full max-w-sm text-center bg-white/95 dark:bg-black/60 relative" onClick={e => e.stopPropagation()}>
                  <button onClick={() => setActiveModal(null)} className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors active:scale-95">
                      <X size={20} />
                  </button>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">{activeModal === 'export_cimbar' ? '生成彩色配置码' : '导出备份文件'}</h3>
                  
                  {isGenerating ? (
                      <div className="py-12 flex flex-col items-center gap-4">
                          <RefreshCw className="animate-spin text-indigo-500" size={32}/>
                          <p className="text-sm text-slate-500 dark:text-white/60">正在加密打包数据...</p>
                      </div>
                  ) : cimbarImage ? (
                      <div className="animate-fade-in">
                          <div className="bg-white p-2 rounded-xl border border-gray-200 mb-6">
                              <img src={cimbarImage} className="w-full h-auto object-contain" style={{ imageRendering: 'pixelated' }} />
                          </div>
                          <p className="text-xs text-slate-500 mb-6">请使用另一台设备在“安全中心”扫描恢复</p>
                          <button onClick={handleDownloadCimbar} className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg flex items-center justify-center gap-2">
                             <Download size={18}/> 保存图片
                          </button>
                      </div>
                  ) : (
                      <div className="space-y-4">
                          <div className="p-4 bg-indigo-50 dark:bg-indigo-500/10 rounded-xl text-left border border-indigo-100 dark:border-indigo-500/20">
                             <h4 className="font-bold text-indigo-700 dark:text-indigo-300 text-sm mb-1 flex items-center gap-2"><Lock size={14}/> 安全加密 (可选)</h4>
                             <div className="flex items-center gap-3 mt-3">
                                <label className="relative inline-flex items-center cursor-pointer">
                                    <input type="checkbox" className="sr-only peer" checked={useEncryption} onChange={e => setUseEncryption(e.target.checked)} />
                                    <div className="w-9 h-5 bg-gray-200 dark:bg-white/20 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                                </label>
                                <span className="text-xs text-slate-500 dark:text-white/60">{useEncryption ? '已启用' : '未启用'}</span>
                             </div>
                             {useEncryption && (
                                 <input 
                                   type="password" 
                                   placeholder="设置密码"
                                   value={exportPassword}
                                   onChange={e => setExportPassword(e.target.value)}
                                   className="w-full mt-3 p-2 glass-input rounded-lg text-sm"
                                 />
                             )}
                          </div>
                          
                          {/* Export Scope Selection (Only for File Export usually, but good to have) */}
                          {activeModal === 'export_file' && (
                             <div className="flex p-1 bg-black/5 dark:bg-white/5 rounded-xl">
                                <button onClick={() => setExportScope('full')} className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${exportScope === 'full' ? 'bg-white dark:bg-white/20 shadow-sm text-indigo-600 dark:text-indigo-400' : 'text-slate-500 dark:text-white/50'}`}>全部数据</button>
                                <button onClick={() => setExportScope('profile_only')} className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${exportScope === 'profile_only' ? 'bg-white dark:bg-white/20 shadow-sm text-indigo-600 dark:text-indigo-400' : 'text-slate-500 dark:text-white/50'}`}>仅个人</button>
                             </div>
                          )}

                          <button 
                            onClick={activeModal === 'export_cimbar' ? handleGenerateCimbar : handleExportJSON} 
                            disabled={useEncryption && !exportPassword}
                            className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                             {activeModal === 'export_cimbar' ? '生成彩色码' : '导出文件'}
                          </button>
                      </div>
                  )}
               </div>
            </div>
         </ModalPortal>
      )}

      {(activeModal === 'import_cimbar' || activeModal === 'import_file_decrypt') && (
         <ModalPortal>
            <div className="fixed inset-0 z-[999] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setActiveModal(null)}>
               <div className="glass-panel rounded-3xl p-6 w-full max-w-sm text-center bg-white/95 dark:bg-black/60 relative" onClick={e => e.stopPropagation()}>
                  <button onClick={() => setActiveModal(null)} className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors active:scale-95">
                      <X size={20} />
                  </button>
                  {importStep === 'upload' && (
                      <div className="animate-fade-in">
                          <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-6">扫描配置码</h3>
                          <label className={`w-full h-32 border-2 border-dashed border-slate-300 dark:border-white/20 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:bg-black/5 dark:hover:bg-white/5 transition-colors mb-3 ${isProcessingImport ? 'opacity-70 cursor-wait' : ''}`}>
                              {isProcessingImport ? (
                                  <>
                                      <RefreshCw size={24} className="animate-spin text-indigo-500 mb-2"/>
                                      <span className="text-sm font-bold text-slate-600 dark:text-white/80">正在解析配置码...</span>
                                  </>
                              ) : (
                                  <>
                                      <div className="w-10 h-10 rounded-full bg-indigo-50 dark:bg-white/10 flex items-center justify-center mb-2 text-indigo-500 dark:text-white"><ScanLine size={20}/></div>
                                      <span className="text-sm font-bold text-slate-600 dark:text-white/80">上传二维码图片</span>
                                  </>
                              )}
                              <input type="file" accept="image/*" className="hidden" onChange={handleCimbarUpload} disabled={isProcessingImport} />
                          </label>
                          <div className="relative flex items-center gap-2 mb-4">
                              <div className="h-px bg-gray-200 dark:bg-white/10 flex-1"></div>
                              <span className="text-[10px] text-slate-400 dark:text-white/40 font-bold uppercase">OR</span>
                              <div className="h-px bg-gray-200 dark:bg-white/10 flex-1"></div>
                          </div>
                          <button onClick={handlePasteImport} className="w-full py-3 bg-gray-100 dark:bg-white/10 rounded-xl font-bold text-slate-600 dark:text-white/80 flex items-center justify-center gap-2 hover:bg-gray-200 dark:hover:bg-white/20 active:scale-95 transition-all">
                              <Copy size={16}/> 粘贴文本数据
                          </button>
                          {importError && <p className="text-red-500 text-xs mt-4 mb-2">{importError}</p>}
                      </div>
                  )}

                  {(importStep === 'decrypt' || activeModal === 'import_file_decrypt') && (
                      <div className="animate-fade-in">
                          <div className="w-16 h-16 bg-amber-100 dark:bg-amber-500/20 rounded-full flex items-center justify-center text-amber-500 dark:text-amber-400 mx-auto mb-4"><Lock size={32}/></div>
                          <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">输入密码</h3>
                          <p className="text-xs text-slate-500 dark:text-white/60 mb-6">该备份已加密，请输入密码解锁</p>
                          <input 
                            type="password"
                            value={importPassword}
                            onChange={e => setImportPassword(e.target.value)}
                            className="w-full p-3 glass-input rounded-xl text-center text-lg mb-4"
                            placeholder="******"
                            autoFocus
                          />
                          {importError && <p className="text-red-500 text-xs mb-4">{importError}</p>}
                          <button onClick={activeModal === 'import_file_decrypt' ? handleDecryptFile : handleDecryptCimbar} className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg">解密</button>
                      </div>
                  )}

                  {importStep === 'confirm' && parsedData && (
                      <div className="animate-fade-in">
                          <div className="w-16 h-16 bg-green-100 dark:bg-green-500/20 rounded-full flex items-center justify-center text-green-500 dark:text-green-400 mx-auto mb-4"><FileCheck size={32}/></div>
                          <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">数据就绪</h3>
                          <div className="bg-gray-50 dark:bg-white/5 rounded-xl p-4 mb-6 text-left border border-gray-100 dark:border-white/10">
                              <p className="text-xs text-slate-500 dark:text-white/60 mb-1">包含内容:</p>
                              {parsedData.profile ? (
                                  <div className="font-bold text-slate-800 dark:text-white text-sm">个人档案: {parsedData.profile.name}</div>
                              ) : parsedData.active?.profile ? (
                                  <div className="font-bold text-slate-800 dark:text-white text-sm">个人档案: {parsedData.active.profile.name} (及其他账号)</div>
                              ) : (
                                  <div className="font-bold text-slate-800 dark:text-white text-sm">仅配置数据 (无个人档案)</div>
                              )}
                              <div className="text-xs text-slate-400 mt-2">恢复将覆盖当前同名数据</div>
                          </div>
                          <button onClick={handleConfirmImport} className="w-full py-3 bg-green-600 text-white rounded-xl font-bold shadow-lg">确认恢复</button>
                      </div>
                  )}

                  {importStep === 'auth_check' && (
                      <div className="animate-fade-in">
                          {authVerifyStatus === 'verifying' ? (
                              <div className="py-12">
                                  <RefreshCw className="animate-spin text-indigo-500 mx-auto mb-4" size={32}/>
                                  <p className="text-sm font-bold text-slate-600 dark:text-white/80">正在验证凭证签名...</p>
                              </div>
                          ) : authVerifyStatus === 'error' ? (
                              <div className="py-6">
                                  <div className="w-16 h-16 bg-red-100 dark:bg-red-500/20 rounded-full flex items-center justify-center text-red-500 dark:text-red-400 mx-auto mb-4"><AlertTriangle size={32}/></div>
                                  <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">验证失败</h3>
                                  <p className="text-sm text-red-500 mb-6">{importError}</p>
                                  
                                  {generatedFailureCode && (
                                      <div className="mb-6 animate-fade-in">
                                          <div className="p-3 bg-amber-50 dark:bg-amber-500/10 rounded-xl border border-amber-200 dark:border-amber-500/20 text-left mb-2">
                                              <p className="text-xs text-amber-600 dark:text-amber-400 font-bold mb-1">恢复代码 (Recovery Code)</p>
                                              <p className="text-[10px] text-amber-600/80 dark:text-amber-400/80 leading-tight mb-2">
                                                  请将此代码发送给授权人以恢复身份。
                                              </p>
                                              <div className="flex gap-2">
                                                  <input readOnly value={generatedFailureCode} className="flex-1 p-2 bg-white dark:bg-black/20 rounded-lg text-xs font-mono border border-amber-200 dark:border-amber-500/20 text-slate-600 dark:text-white/80" />
                                                  <button onClick={() => { navigator.clipboard.writeText(generatedFailureCode); triggerHaptic('success'); alert('恢复代码已复制'); }} className="p-2 bg-amber-100 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 rounded-lg">
                                                      <Copy size={14}/>
                                                  </button>
                                              </div>
                                          </div>
                                      </div>
                                  )}
                                  
                                  <button onClick={() => { setActiveModal(null); setImportStep('upload'); }} className="w-full py-3 bg-gray-100 dark:bg-white/10 text-slate-600 dark:text-white rounded-xl font-bold">关闭</button>
                              </div>
                          ) : (
                              <div className="py-6">
                                  <div className="w-16 h-16 bg-green-100 dark:bg-green-500/20 rounded-full flex items-center justify-center text-green-500 dark:text-green-400 mx-auto mb-4"><Shield size={32}/></div>
                                  <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">权限验证通过</h3>
                                  <p className="text-sm text-slate-500 dark:text-white/60 mb-6">即将激活: <span className="font-bold text-indigo-500">{getIdentityLabel(parsedData?.role)}</span></p>
                                  <button onClick={handleConfirmAuth} className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg">激活权限</button>
                              </div>
                          )}
                      </div>
                  )}

                  {importStep === 'legacy_reveal' && parsedData && (
                      <div className="animate-fade-in text-left">
                          <h3 className="text-2xl font-serif font-bold text-slate-900 dark:text-white mb-6 text-center">传承寄语</h3>
                          <div className="relative p-6 bg-amber-50 dark:bg-amber-900/10 rounded-2xl border border-amber-100 dark:border-amber-500/20 mb-8">
                              <div className="absolute top-0 left-0 text-6xl text-amber-200 dark:text-amber-500/20 font-serif -mt-4 -ml-2">“</div>
                              <p className="relative z-10 text-amber-900 dark:text-amber-100/90 text-lg font-serif italic leading-relaxed text-center">
                                  {parsedData.msg}
                              </p>
                              <div className="absolute bottom-0 right-0 text-6xl text-amber-200 dark:text-amber-500/20 font-serif -mb-8 -mr-2">”</div>
                          </div>
                          <button onClick={handleConfirmAuth} className="w-full py-3 bg-gradient-to-r from-amber-500 to-orange-600 text-white rounded-xl font-bold shadow-lg shadow-amber-500/30">接受传承</button>
                      </div>
                  )}
               </div>
            </div>
         </ModalPortal>
      )}

      {/* Simple Modals for Help */}
      {(activeModal === 'help_admin' || activeModal === 'help_security') && (
          <ModalPortal>
              <div className="fixed inset-0 z-[999] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setActiveModal(null)}>
                  <div className="glass-panel rounded-3xl p-6 w-full max-w-sm bg-white/95 dark:bg-black/60 relative" onClick={e => e.stopPropagation()}>
                      <button onClick={() => setActiveModal(null)} className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors active:scale-95">
                          <X size={20} />
                      </button>
                      <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">帮助说明</h3>
                      <p className="text-sm text-slate-500 dark:text-white/60 mb-6 leading-relaxed">
                          {activeModal === 'help_admin' 
                            ? "管理员控制台允许您修改全局配置（如首页卡片链接）、分配权限给其他成员。长期管理员可生成包含寄语的传承码，将权限移交给继任者。" 
                            : "安全中心用于数据的备份与恢复。支持生成加密的 JSON 文件或 CIMBAR 彩色码。CIMBAR 是一种高密度二维码，可直接通过扫描图片在不同设备间传输大量数据。"}
                      </p>
                      <button onClick={() => setActiveModal(null)} className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold">了解</button>
                  </div>
              </div>
          </ModalPortal>
      )}

      {/* Export Selection Modal */}
       {activeModal === 'export_selector' && (
           <ModalPortal>
               <div className="fixed inset-0 z-[999] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setActiveModal(null)}>
                   <div className="glass-panel rounded-3xl p-6 w-full max-w-sm bg-white/95 dark:bg-black/60 shadow-2xl relative" onClick={e => e.stopPropagation()}>
                       <button onClick={() => setActiveModal(null)} className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors active:scale-95">
                           <X size={20} />
                       </button>
                       <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2 text-center">选择导出方式</h3>
                      <p className="text-sm text-slate-500 dark:text-white/60 mb-6 text-center">请根据当前设备环境选择最合适的传输方式</p>
                      
                      <div className="space-y-4">
                          {/* PC Export Option */}
                          <div className="p-4 rounded-2xl bg-indigo-50 dark:bg-indigo-500/10 border border-indigo-100 dark:border-indigo-500/20 hover:bg-indigo-100 dark:hover:bg-indigo-500/20 transition-colors cursor-pointer group"
                               onClick={() => {
                                   // Perform original download logic
                                   if (pendingExportType === 'file') {
                                       const blob = new Blob([pendingExportData], { type: 'application/json' });
                                       const url = URL.createObjectURL(blob);
                                       const link = document.createElement('a');
                                       link.href = url;
                                       link.download = pendingExportFilename;
                                       document.body.appendChild(link);
                                       link.click();
                                       document.body.removeChild(link);
                                       URL.revokeObjectURL(url);
                                   } else {
                                       const link = document.createElement('a');
                                       link.href = pendingExportImage;
                                       link.download = pendingExportFilename;
                                       document.body.appendChild(link);
                                       link.click();
                                       document.body.removeChild(link);
                                   }
                                   triggerHaptic('success');
                               }}
                          >
                              <div className="flex items-center gap-4">
                                  <div className="w-12 h-12 rounded-full bg-indigo-500 text-white flex items-center justify-center shrink-0 shadow-lg shadow-indigo-500/30 group-hover:scale-110 transition-transform">
                                      <Monitor size={24} />
                                  </div>
                                  <div className="flex-1">
                                      <h4 className="font-bold text-slate-900 dark:text-white text-base mb-1">电脑端导出</h4>
                                      <p className="text-xs text-slate-500 dark:text-white/60">
                                          {pendingExportType === 'file' ? '下载 JSON 文件' : '下载 PNG 图片'}
                                      </p>
                                  </div>
                                  <div className="w-8 h-8 rounded-full bg-white dark:bg-white/10 flex items-center justify-center text-slate-400">
                                      <Download size={16}/>
                                  </div>
                              </div>
                          </div>

                          {/* Mobile Export Option */}
                          <div className="p-4 rounded-2xl bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 hover:border-indigo-500 dark:hover:border-indigo-400 transition-colors cursor-pointer group"
                               onClick={() => {
                                   // Show text payload
                                   // We can reuse the current modal or show a sub-view
                                   // Let's just expand inline or replace content?
                                   // Simpler to just use a local state in this component if it was a component.
                                   // Since it's inside the main component, I can't easily add local state without re-rendering everything.
                                   // But I can switch the view by using a different activeModal or a sub-state.
                                   // Let's just use the 'recovery' type or similar hack? No.
                                   // I will just add a 'showText' state variable? 
                                   // No, I'll just Render the text view here if I click it?
                                   // Actually, I'll just change the modal content dynamically.
                                   // But I can't change 'activeModal' to something else easily without closing this one.
                                   // I'll make this modal have two steps: 'select' and 'text'.
                                   // I'll add 'pendingExportStep' state? 
                                   // No, I'll just implement it as a toggle in the UI.
                                   // OR better: Just show the text area collapsed by default?
                                   // "Mobile Export" -> Expands the text area.
                               }}
                          >
                              <details className="group">
                                  <summary className="flex items-center gap-4 list-none cursor-pointer" onClick={() => triggerHaptic('selection')}>
                                      <div className="w-12 h-12 rounded-full bg-green-500 text-white flex items-center justify-center shrink-0 shadow-lg shadow-green-500/30 group-hover:scale-110 transition-transform">
                                          <Smartphone size={24} />
                                      </div>
                                      <div className="flex-1">
                                          <h4 className="font-bold text-slate-900 dark:text-white text-base mb-1">移动端导出</h4>
                                          <p className="text-xs text-slate-500 dark:text-white/60">复制加密文本数据</p>
                                      </div>
                                      <div className="w-8 h-8 rounded-full bg-white dark:bg-white/10 flex items-center justify-center text-slate-400 group-open:rotate-90 transition-transform">
                                          <ArrowRight size={16}/>
                                      </div>
                                  </summary>
                                  <div className="mt-4 pt-4 border-t border-gray-100 dark:border-white/10 animate-fade-in">
                                      <p className="text-xs text-slate-500 dark:text-white/50 mb-2">请复制以下内容发送到移动设备：</p>
                                      <textarea 
                                          readOnly 
                                          value={pendingExportData} 
                                          className="w-full h-32 p-3 glass-input rounded-xl text-xs font-mono mb-3 focus:outline-none resize-none"
                                          onClick={(e) => (e.target as HTMLTextAreaElement).select()}
                                      />
                                      <button 
                                          onClick={() => { navigator.clipboard.writeText(pendingExportData); triggerHaptic('success'); alert('已复制到剪贴板'); }}
                                          className="w-full py-2 bg-green-500 hover:bg-green-600 text-white rounded-xl font-bold text-sm shadow-lg shadow-green-500/30 active:scale-95 transition-all flex items-center justify-center gap-2"
                                      >
                                          <Copy size={16}/> 复制文本
                                      </button>
                                  </div>
                              </details>
                          </div>
                      </div>

                      <button onClick={() => setActiveModal(null)} className="w-full mt-6 py-3 bg-gray-100 dark:bg-white/10 text-slate-600 dark:text-white rounded-xl font-bold hover:bg-gray-200 dark:hover:bg-white/20 transition-colors">
                          关闭
                      </button>
                  </div>
              </div>
          </ModalPortal>
      )}

      {/* Manual Import Modal */}
       {activeModal === 'manual_import' && (
           <ModalPortal>
               <div className="fixed inset-0 z-[1000] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setActiveModal(null)}>
                   <div className="glass-panel rounded-3xl p-6 w-full max-w-sm bg-white/95 dark:bg-black/60 shadow-2xl relative" onClick={e => e.stopPropagation()}>
                       <button onClick={() => setActiveModal(null)} className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors active:scale-95">
                           <X size={20} />
                       </button>
                       <div className="w-16 h-16 bg-indigo-50 dark:bg-indigo-500/20 rounded-full flex items-center justify-center text-indigo-500 dark:text-indigo-400 mx-auto mb-4 border border-indigo-100 dark:border-indigo-500/30">
                           <Edit2 size={32}/>
                       </div>
                       <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2 text-center">手动输入数据</h3>
                      <p className="text-sm text-slate-500 dark:text-white/60 mb-6 text-center">无法读取剪贴板，请长按下方输入框粘贴</p>
                      
                      <textarea 
                          value={manualInputText}
                          onChange={e => setManualInputText(e.target.value)}
                          placeholder="在此处粘贴配置数据..."
                          className="w-full h-40 p-4 glass-input rounded-xl text-xs font-mono mb-4 focus:outline-none resize-none"
                          autoFocus
                      />
                      
                      <div className="flex gap-3">
                          <button onClick={() => setActiveModal('import_cimbar')} className="flex-1 py-3 bg-gray-100 dark:bg-white/10 text-slate-600 dark:text-white rounded-xl font-bold hover:bg-gray-200 dark:hover:bg-white/20 transition-colors">
                              取消
                          </button>
                          <button 
                              onClick={() => processImportText(manualInputText)}
                              disabled={!manualInputText}
                              className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                              确认导入
                          </button>
                      </div>
                  </div>
              </div>
          </ModalPortal>
      )}

      {/* Department Management Modal */}
      {activeModal === 'dept_manage' && (
         <ModalPortal>
            <div className="fixed inset-0 z-[999] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setActiveModal(null)}>
               <div className="glass-panel rounded-3xl p-6 w-full max-w-md bg-white/95 dark:bg-black/60 max-h-[85vh] flex flex-col relative" onClick={e => e.stopPropagation()}>
                  <button onClick={() => setActiveModal(null)} className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors active:scale-95">
                      <X size={20} />
                  </button>
                  <div className="mb-4 shrink-0">
                      <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-1">部门管理</h3>
                      <p className="text-xs text-slate-500 dark:text-white/50">管理组织架构与部门列表</p>
                  </div>
                  
                  <div className="flex-1 overflow-y-auto space-y-3 hide-scrollbar mb-4">
                      {departments.map(dept => (
                          <div key={dept.id} className="p-3 bg-white dark:bg-white/5 rounded-xl border border-gray-100 dark:border-white/10 flex items-center justify-between group">
                              <div>
                                  <div className="font-bold text-sm text-slate-800 dark:text-white flex items-center gap-2">
                                      {dept.name}
                                      {dept.isTopLevel && <span className="text-[10px] px-1.5 py-0.5 bg-indigo-100 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-300 rounded">顶级</span>}
                                  </div>
                                  <div className="text-xs text-slate-500 dark:text-white/50 line-clamp-1">{dept.description}</div>
                              </div>
                              <div className="flex items-center gap-1">
                                  <button onClick={() => { setEditDept(dept); setActiveModal('dept_edit'); triggerHaptic('selection'); }} className="p-2 text-slate-400 hover:text-indigo-500 transition-colors">
                                      <Edit2 size={16}/>
                                  </button>
                                  <button onClick={() => handleDeleteDept(dept.id)} className="p-2 text-slate-400 hover:text-red-500 transition-colors">
                                      <Trash2 size={16}/>
                                  </button>
                              </div>
                          </div>
                      ))}
                  </div>
                  
                  <button onClick={() => { setEditDept({ id: 'NEW', name: '', description: '', cards: [], announcements: [] }); setActiveModal('dept_edit'); triggerHaptic('selection'); }} className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg flex items-center justify-center gap-2">
                      <Plus size={18}/> 新增部门
                  </button>
               </div>
            </div>
         </ModalPortal>
      )}

      {/* Department Edit Modal */}
      {activeModal === 'dept_edit' && editDept && (
         <ModalPortal>
            <div className="fixed inset-0 z-[1000] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setActiveModal('dept_manage')}>
               <div className="glass-panel rounded-3xl p-6 w-full max-w-sm bg-white/95 dark:bg-black/60 shadow-2xl relative" onClick={e => e.stopPropagation()}>
                   <button onClick={() => setActiveModal('dept_manage')} className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors active:scale-95">
                       <X size={20} />
                   </button>
                   <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-6 text-center">{editDept.id === 'NEW' ? '新增部门' : '编辑部门'}</h3>
                   
                   <div className="space-y-4 mb-6">
                       <div className="space-y-1">
                           <label className="text-xs font-bold text-slate-500 dark:text-white/50 uppercase tracking-wider ml-1">部门名称</label>
                           <input 
                              value={editDept.name}
                              onChange={e => setEditDept({...editDept, name: e.target.value})}
                              placeholder="例如：技术部"
                              className="w-full p-3 glass-input rounded-xl text-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                              autoFocus
                           />
                       </div>
                       <div className="space-y-1">
                           <label className="text-xs font-bold text-slate-500 dark:text-white/50 uppercase tracking-wider ml-1">部门描述</label>
                           <textarea 
                              value={editDept.description}
                              onChange={e => setEditDept({...editDept, description: e.target.value})}
                              placeholder="简要描述部门职责..."
                              rows={3}
                              className="w-full p-3 glass-input rounded-xl text-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 resize-none"
                           />
                       </div>
                   </div>
                   
                   <div className="flex gap-3">
                       <button onClick={() => setActiveModal('dept_manage')} className="flex-1 py-3 bg-gray-100 dark:bg-white/10 text-slate-600 dark:text-white rounded-xl font-bold hover:bg-gray-200 dark:hover:bg-white/20 transition-colors">
                           取消
                       </button>
                       <button 
                           onClick={handleSaveDept}
                           disabled={!editDept.name}
                           className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg disabled:opacity-50"
                       >
                           保存
                       </button>
                   </div>
               </div>
            </div>
         </ModalPortal>
      )}

    </div>
  );
};

export default SettingsView;
